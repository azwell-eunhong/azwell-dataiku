from importlib.metadata import version

__version__ = version("ragas_experimental")
