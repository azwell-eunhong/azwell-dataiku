"""Chain that carries on a conversation from a prompt plus history."""
