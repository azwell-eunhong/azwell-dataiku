from traces_explorer.backend.routes import api

app.register_blueprint(api)
