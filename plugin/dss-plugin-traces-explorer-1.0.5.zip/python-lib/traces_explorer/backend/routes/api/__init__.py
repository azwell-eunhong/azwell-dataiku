from flask import Blueprint

from .traces import traces_blueprint

api = Blueprint("api", __name__, url_prefix="/api")

api.register_blueprint(traces_blueprint)
