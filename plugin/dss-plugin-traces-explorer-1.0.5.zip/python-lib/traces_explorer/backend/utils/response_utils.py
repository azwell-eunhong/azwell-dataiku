import json


def return_ok(data={}) -> str:
    return json.dumps({"status": "ok", "data": data})


def return_ko(message="") -> str:
    return json.dumps({"status": "ko", "message": message})
