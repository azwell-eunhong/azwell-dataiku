/* eslint-disable @typescript-eslint/no-explicit-any */

import axios_ from 'axios'

function getBackendProdUrl() {
  const getWebappBackendUrlFn =
    (window as any)['getWebAppBackendUrl'] || (parent as any)['getWebAppBackendUrl']
  if (typeof getWebappBackendUrlFn === 'function') {
    return getWebappBackendUrlFn('')
  }
  return null
}

// @ts-expect-error - import.meta is not defined in the browser
let baseURLVite = import.meta.env.BASE_URL

const backendProdBase = getBackendProdUrl()
// @ts-expect-error - import.meta is not defined in the browser
const localBackendPort = import.meta.env.VITE_API_PORT
// @ts-expect-error - import.meta is not defined in the browser
const localClientPort = import.meta.env.VITE_CLIENT_PORT

baseURLVite = baseURLVite.replace(localClientPort, localBackendPort)

const baseURL = backendProdBase != null ? backendProdBase : baseURLVite

const axios = axios_.create({ baseURL })

axios.interceptors.response.use(
  (response) => {
    return response
  },
  (error) => {
    APIErrors.push(error.response)
    return Promise.reject(error)
  }
)

export const APIErrors: any[] = []

export default axios
export { baseURL }
