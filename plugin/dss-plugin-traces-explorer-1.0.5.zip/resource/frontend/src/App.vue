<template>
  <BsLayoutDefault :left-panel-width="270" default-layout-tab-name="Traces">
    <BsHeader>
      <template #content>
        <div class="header-container">
          <div class="bs-font-medium-4-semi-bold title">Explore Dataiku LLM Mesh Traces</div>
          <div class="view-mode-buttons row items-center q-gutter-sm">
            <BsButton
              :flat="true"
              :outline="true"
              :unelevated="true"
              :class="{ active: viewMode === ViewMode.Tree }"
              @click="onViewModeChange(ViewMode.Tree)"
            >
              Tree
            </BsButton>
            <BsButton
              :flat="true"
              :outline="true"
              :unelevated="true"
              :class="{ active: viewMode === ViewMode.Timeline }"
              @click="onViewModeChange(ViewMode.Timeline)"
            >
              Timeline
            </BsButton>
            <BsButton
              :flat="true"
              :outline="true"
              :unelevated="true"
              :class="{ active: viewMode === ViewMode.Explorer }"
              @click="onViewModeChange(ViewMode.Explorer)"
            >
              Explorer
            </BsButton>
          </div>
        </div>
      </template>
    </BsHeader>

    <BsDrawer>
      <TracesList />
    </BsDrawer>

    <BsContent>
      <TracesViewer :view-mode="viewMode" />
    </BsContent>
  </BsLayoutDefault>
</template>

<script lang="ts" setup>
import { ref } from 'vue'

import TracesList from '@/components/TracesList.vue'
import TracesViewer from '@/components/TracesViewer.vue'
import { ViewMode } from '@/common/views'
import { WT1iser } from '@/common/wt1'

const viewMode = ref<ViewMode>(ViewMode.Tree)

function onViewModeChange(newViewMode: ViewMode) {
  viewMode.value = newViewMode
  WT1iser.tabChange(viewMode.value)
}

WT1iser.init()
</script>

<style scoped>
.q-layout {
  background: #f9f9f9;
}

.title {
  text-align: left;
  margin-top: -5px;
}

.header-container {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.view-mode-buttons .active {
  background-color: #d6e1fe !important;
}

.view-mode-buttons {
  border: solid #e0e0e0 1px;
  border-radius: 8px;
  padding: 0;
  margin: 0;
}

.view-mode-buttons button {
  padding: 0 4px;
  margin: 0;
  text-transform: none;
  min-width: 80px;
}

:deep(.q-btn) {
  min-height: initial !important;
}

:deep(.bs-font-medium-3-normal) {
  font-size: 14px !important;
}

/* Only two buttons now: Tree and Timeline */
.view-mode-buttons > button {
  border-radius: 0px;
}

.view-mode-buttons > button:first-child {
  border-radius: 6px 0 0 6px;
  border-right: solid #e0e0e0 1px;
}

.view-mode-buttons > button:last-child {
  border-left: solid #e0e0e0 1px;
  border-radius: 0 6px 6px 0;
}
</style>
