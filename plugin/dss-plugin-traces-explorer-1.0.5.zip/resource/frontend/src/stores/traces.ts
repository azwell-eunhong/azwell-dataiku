import { defineStore } from 'pinia'
import { computed, ref } from 'vue'

import { NodesFilters } from '@/common/interface/filters/nodes'
import { TracesFilters } from '@/common/interface/filters/traces'
import { Trace } from '@/common/interface/trace'
import { filterTraceNode } from '@/utils/traceFilter'

export const useTracesStore = defineStore('traces', () => {
  // Traces
  const datasetTraces = ref<Trace[]>([])
  const localTrace = ref<Trace | null>(null)
  const exploreTrace = ref<Trace | null>(null)

  // Filters
  const nodesFilters = ref<NodesFilters>({ name: '', group: null })
  const tracesFilters = ref<TracesFilters>({ name: '', duration: [0, 10000] })
  // TODO: tracesFilters are currently not used, this need a refacto on the component side

  // UI state
  const selectedTraceId = ref<string | null>(null)
  const isLoadingList = ref<boolean>(true)
  const isLoadingTrace = ref<boolean>(true)
  // TODO: `isLoadingTrace` is currently not used, we might need to add a loading state

  const traces = computed(() => {
    return [exploreTrace.value, localTrace.value, ...datasetTraces.value].filter(
      (trace): trace is Trace => trace !== null
    )
  })

  const selectedTrace = computed(() => {
    let trace = traces.value.find((trace) => trace.id == selectedTraceId.value)

    if (!trace || !trace.parentNode) return null

    trace = {
      ...trace,
      parentNode: filterTraceNode(trace.parentNode, nodesFilters.value)
    }

    return trace
  })

  function updateDatasetTrace(trace: Trace) {
    datasetTraces.value = datasetTraces.value.map((currTrace) => {
      if (currTrace.id == trace.id) {
        return trace
      }

      return currTrace
    })
  }

  function setNodesFilters(fieldsToUpdate: Partial<NodesFilters>) {
    nodesFilters.value = { ...nodesFilters.value, ...fieldsToUpdate }
  }

  function setTracesFilters(fieldsToUpdate: Partial<TracesFilters>) {
    tracesFilters.value = { ...tracesFilters.value, ...fieldsToUpdate }
  }

  return {
    datasetTraces,
    localTrace,
    exploreTrace,
    selectedTraceId,
    updateDatasetTrace,
    nodesFilters,
    setNodesFilters,
    tracesFilters,
    setTracesFilters,
    isLoadingList,
    isLoadingTrace,
    traces,
    selectedTrace
  }
})
