<template>
  <div>
    <div v-if="!closed" ref="panelRef" class="trace-node-panel" :style="panelStyle as any">
      <CustomCollapsiblePanel
        v-model:expanded="expanded"
        :title="nodeLabel"
        :collapsable="true"
        :collapsed="collapsed"
        :header-bg-color="nodeBgColor"
        :closable="true"
        :maximizable="true"
        class="inner-panel"
        @close="closePanel"
        @update:collapsed="onPanelCollapsed"
      >
        <div class="node-meta">
          <div v-if="node.duration !== undefined">
            <q-icon name="timer" size="16px" class="node-duration" />
            <span>Duration: {{ (node.duration / 1000).toFixed(2) }} s</span>
          </div>
          <div v-if="node.begin && node.end">
            <q-icon name="event" size="16px" class="time-event" />
            <span class="node-time">
              {{ formattedBegin.slice(0, -4) }}
              <span class="milliseconds">{{ formattedBegin.slice(-4) }}</span>
            </span>
            <BsIcon name="arrow-right" :size="16" class="time-to" />
            <span class="node-time">
              {{ formattedEnd.slice(0, -4) }}
              <span class="milliseconds">{{ formattedEnd.slice(-4) }}</span>
            </span>
          </div>
        </div>

        <div class="trace-node-content" :class="{ expanded: expanded }">
          <div class="info-section" :style="{ height: infoSectionHeights.attributes + 'px' }">
            <div class="info-title">Attributes</div>
            <div class="boxed-info">
              <vue-json-pretty
                v-if="hasKeys(parsedAttributes)"
                :data="parsedAttributes"
                :deep="2"
                show-icon
                show-length
              />
            </div>
            <div
              v-if="sectionExists('inputs')"
              class="resize-handle"
              @mousedown.prevent="startResizing('attributes', 'inputs', $event)"
            ></div>
          </div>

          <div class="info-section" :style="{ height: infoSectionHeights.inputs + 'px' }">
            <div class="info-title">Inputs</div>
            <div class="boxed-info">
              <vue-json-pretty
                v-if="hasKeys(parsedInputs)"
                :data="parsedInputs"
                :deep="2"
                show-icon
                show-length
              />
            </div>
            <div
              v-if="sectionExists('outputs')"
              class="resize-handle"
              @mousedown.prevent="startResizing('inputs', 'outputs', $event)"
            ></div>
          </div>

          <div class="info-section" :style="{ height: infoSectionHeights.outputs + 'px' }">
            <div class="info-title">Outputs</div>
            <div class="boxed-info">
              <vue-json-pretty
                v-if="hasKeys(parsedOutputs)"
                :data="parsedOutputs"
                :deep="2"
                show-icon
                show-length
              />
            </div>
            <div
              v-if="hasKeys(parsedUsageMetadata)"
              class="resize-handle"
              @mousedown.prevent="startResizing('outputs', 'usage', $event)"
            ></div>
          </div>

          <div
            v-if="hasKeys(parsedUsageMetadata)"
            class="info-section"
            :style="{ height: infoSectionHeights.usage + 'px' }"
          >
            <div class="info-title">Usage Metadata</div>
            <div class="boxed-info">
              <vue-json-pretty :data="parsedUsageMetadata" :deep="2" show-icon show-length />
            </div>
          </div>
        </div>
      </CustomCollapsiblePanel>
    </div>
  </div>
</template>

<script lang="ts">
import 'vue-json-pretty/lib/styles.css'

import type { Interactable } from '@interactjs/types'
import interact from 'interactjs'
import { QIcon } from 'quasar'
import { ref, watch, onMounted, onBeforeUnmount, computed, nextTick } from 'vue'
import VueJsonPretty from 'vue-json-pretty'

import CustomCollapsiblePanel from './CustomCollapsiblePanel.vue'
import { classifyNodeGroup } from '@/utils/classifyNodeGroup'
import { formatNodeTime } from '@/utils/formatDate'
import { getGroupColor } from '@/utils/nodeGroupsConfig'

export default {
  name: 'TraceNodeView',
  components: {
    CustomCollapsiblePanel,
    VueJsonPretty,
    QIcon
  },
  props: {
    node: {
      type: Object,
      required: true
    },
    initialCollapsed: {
      type: Boolean,
      default: false
    }
  },
  setup(props) {
    const closed = ref(false)
    const collapsed = ref(props.initialCollapsed)

    const offsetX = ref(0)
    const offsetY = ref(0)

    const panelRef = ref<HTMLDivElement | null>(null)
    let dragInstance: Interactable | null = null

    const expanded = ref(false)

    const infoSectionHeights = ref<Record<string, number>>({
      attributes: 200,
      inputs: 150,
      outputs: 150,
      usage: 120
    })

    const normalModeHeights = ref<Record<string, number>>({})

    const resizingSections = ref<{ top: string; bottom: string } | null>(null)
    const startY = ref(0)
    const startHeightTop = ref(0)
    const startHeightBottom = ref(0)

    function initDraggable() {
      if (dragInstance) {
        dragInstance.unset()
        dragInstance = null
      }
      const headerEl: HTMLElement | null | undefined = panelRef.value?.querySelector(
        '.bs-collapsable-panel-title-container'
      )
      if (headerEl) {
        dragInstance = interact(headerEl).draggable({
          ignoreFrom: '.arrow-icon, .close-btn, .expand-btn',
          listeners: {
            move(event) {
              if (!expanded.value) {
                offsetX.value += event.dx
                offsetY.value += event.dy
              }
            }
          }
        })
      }
    }

    onMounted(() => {
      initDraggable()
      window.addEventListener('mousemove', handleMouseMove)
      window.addEventListener('mouseup', handleMouseUp)
    })

    onBeforeUnmount(() => {
      if (dragInstance) {
        dragInstance.unset()
        dragInstance = null
      }
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    })

    watch(
      () => props.node && props.node.id,
      async () => {
        closed.value = false
        offsetX.value = 0
        offsetY.value = 0
        expanded.value = false
        await nextTick()
        initDraggable()
      }
    )

    const nodeLabel = computed(() => props.node.name || props.node.type || '(no name)')
    const nodeBgColor = computed(() => {
      const group = classifyNodeGroup(props.node)
      return getGroupColor(group)
    })

    function parseDeep(value: any): any {
      if (typeof value === 'string') {
        try {
          return parseDeep(JSON.parse(value))
        } catch {
          return value
        }
      }
      if (Array.isArray(value)) {
        return value.map(parseDeep)
      }
      if (value && typeof value === 'object') {
        const newObj: Record<string, any> = {}
        for (const [k, v] of Object.entries(value) as [string, any][]) {
          newObj[k] = parseDeep(v)
        }
        return newObj
      }
      return value
    }

    const parsedAttributes = computed(() => parseDeep(props.node.attributes || {}))
    const parsedInputs = computed(() => parseDeep(props.node.inputs || {}))
    const parsedOutputs = computed(() => parseDeep(props.node.outputs || {}))
    const parsedUsageMetadata = computed(() => parseDeep(props.node.usageMetadata || {}))
    const formattedBegin = computed(() => {
      const formatted = formatNodeTime(props.node.begin)
      return formatted.value || ''
    })
    const formattedEnd = computed(() => {
      const formatted = formatNodeTime(props.node.end)
      return formatted.value || ''
    })

    function hasKeys(obj: any): boolean {
      return obj && typeof obj === 'object' && Object.keys(obj).length > 0
    }

    function closePanel() {
      expanded.value = false
      closed.value = true
    }
    function onPanelCollapsed(val: boolean) {
      collapsed.value = val
    }

    function sectionExists(key: string): boolean {
      return key in infoSectionHeights.value
    }

    const panelStyle = computed(() => {
      if (expanded.value) {
        return {
          position: 'fixed',
          top: '0',
          left: '0',
          right: '0',
          bottom: '0',
          zIndex: 9999,
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden'
        }
      } else {
        return {
          position: 'absolute',
          top: '105px',
          right: '15px',
          width: '450px',
          maxHeight: 'calc(100vh - 180px)',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'auto',
          transform: `translate(${offsetX.value}px, ${offsetY.value}px)`,
          zIndex: 9999
        }
      }
    })

    function startResizing(topKey: string, bottomKey: string, e: MouseEvent) {
      resizingSections.value = { top: topKey, bottom: bottomKey }
      startY.value = e.clientY
      startHeightTop.value = infoSectionHeights.value[topKey]
      startHeightBottom.value = infoSectionHeights.value[bottomKey]
    }

    function handleMouseMove(e: MouseEvent) {
      if (!resizingSections.value) return
      const delta = e.clientY - startY.value

      let newTop = startHeightTop.value + delta
      let newBottom = startHeightBottom.value - delta

      const minH = 50
      if (newTop < minH) {
        newBottom -= minH - newTop
        newTop = minH
      }
      if (newBottom < minH) {
        newTop -= minH - newBottom
        newBottom = minH
      }

      infoSectionHeights.value[resizingSections.value.top] = newTop
      infoSectionHeights.value[resizingSections.value.bottom] = newBottom
    }

    function handleMouseUp() {
      if (resizingSections.value) {
        resizingSections.value = null
      }
    }

    watch(expanded, async (newVal) => {
      if (newVal === true) {
        normalModeHeights.value = { ...infoSectionHeights.value }
        await nextTick()
        const contentEl = panelRef.value?.querySelector('.trace-node-content')
        if (contentEl) {
          const totalH = contentEl.clientHeight
          const visibleSections: string[] = []
          if (hasKeys(parsedAttributes.value)) visibleSections.push('attributes')
          if (hasKeys(parsedInputs.value)) visibleSections.push('inputs')
          if (hasKeys(parsedOutputs.value)) visibleSections.push('outputs')
          if (hasKeys(parsedUsageMetadata.value)) visibleSections.push('usage')

          if (visibleSections.length > 0) {
            const perSection = Math.floor(totalH / visibleSections.length)
            visibleSections.forEach((sec: string) => {
              infoSectionHeights.value[sec] = perSection
            })
          }
        }
      } else {
        infoSectionHeights.value = { ...normalModeHeights.value }
      }
    })

    return {
      closed,
      collapsed,
      closePanel,
      onPanelCollapsed,
      nodeLabel,
      nodeBgColor,
      parsedAttributes,
      parsedInputs,
      parsedOutputs,
      parsedUsageMetadata,
      formattedBegin,
      formattedEnd,
      hasKeys,
      panelRef,
      panelStyle,
      offsetX,
      offsetY,
      expanded,
      infoSectionHeights,
      startResizing,
      sectionExists
    }
  }
}
</script>

<style scoped>
.trace-node-panel {
  background-color: #fff;
  border: 1px solid #ddd;
  border-radius: 4px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
}

.inner-panel {
  flex: 1;
  display: flex;
  flex-direction: column;
  background-color: #fff;
}

.node-meta {
  font-size: 12px;
  padding: 4px 0 0 6px;
  color: #333e48;
}

.node-meta .time-event {
  vertical-align: middle;
  margin: -2px 3px 0 0;
}

.node-meta .time-to {
  vertical-align: middle;
  margin: 0 8px;
}

.node-meta .node-duration {
  vertical-align: middle;
  margin: -2px 3px 0 0;
}

.milliseconds {
  font-size: 0.8em;
  color: gray;
}

.trace-node-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  position: relative;
  margin-top: 4px;
  overflow: auto;
}

.trace-node-content.expanded {
  overflow: auto;
}

.info-section {
  background-color: #e6e6e6;
  border-radius: 3px;
  border: 1px solid #eee;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  position: relative;
  margin-bottom: 8px;
}

.info-title {
  color: #808080;
  font-size: 12px;
  line-height: 1.5;
  padding: 2px 8px;
  background-color: #f8f8f8;
  font-weight: 500;
}

.boxed-info {
  flex-grow: 1;
  overflow: auto;
  background-color: #fff;
  padding: 4px;
}

.resize-handle {
  height: 6px;
  background: #ccc;
  cursor: row-resize;
  border-top: 1px solid #aaa;
  border-bottom: 1px solid #aaa;
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
}

:deep(.vjs-tree) {
  font-size: 10px !important;
}
</style>
