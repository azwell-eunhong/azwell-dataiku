<template>
  <div class="q-pa-md traces-viewer-root">
    <div
      v-if="!tracesStore.selectedTraceId && !tracesStore.isLoadingList"
      class="q-my-lg text-grey"
    >
      No traces available
    </div>

    <div v-else class="content-area">
      <div class="sticky-top">
        <div class="top-level-usage-metrics">
          <div class="usage-item">
            <strong>Prompt Tokens (total):</strong>
            {{ tracesStore.selectedTrace?.overallTotalPromptTokens || 0 }}
          </div>
          <div class="usage-item">
            <strong>Completion Tokens (total):</strong>
            {{ tracesStore.selectedTrace?.overallTotalCompletionTokens || 0 }}
          </div>
          <div class="usage-item">
            <strong>Total Tokens:</strong>
            {{ tracesStore.selectedTrace?.overallTotalTokens || 0 }}
          </div>
          <div class="usage-item">
            <strong>Estimated Cost:</strong>
            ${{ formattedOverallEstimatedCost || 0 }}
            <span v-if="showPerThousand">
              <strong>/ 1K Tokens</strong>: ${{ costPerThousand }}
            </span>
            <span v-if="showPerMillion"> <strong>/ 1M Tokens</strong>: ${{ costPerMillion }} </span>
          </div>
        </div>

        <div class="q-mb-md row items-center q-gutter-sm trace-header">
          <BsTextField
            v-model="localNameQuery"
            placeholder="Search trace nodes..."
            style="width: 300px"
          />

          <div class="legend row items-center q-gutter-sm">
            <template v-for="(cfg, key) in groupLegend" :key="key">
              <div
                v-if="key !== 'span'"
                class="legend-item"
                :class="{ 'legend-item-active': tracesStore.nodesFilters.group === key }"
                @click="toggleGroupFilter(key)"
              >
                <span class="legend-color" :style="{ backgroundColor: cfg.color }"></span>
                {{ cfg.label }}
              </div>
            </template>
          </div>
        </div>
      </div>

      <div class="scrollable-body">
        <div v-if="!tracesStore.selectedTrace?.parentNode">
          <p class="text-grey-7">No matching nodes found.</p>
        </div>
        <div v-else>
          <div v-if="viewMode === 'tree'" class="trace-viewer">
            <TreeView :selected-node-id="selectedNodeId" @node-selected="onNodeSelected" />
          </div>

          <div v-else-if="viewMode === 'timeline'" class="trace-viewer">
            <TimelineView :selected-node-id="selectedNodeId" @node-selected="onNodeSelected" />
          </div>

          <div v-else-if="viewMode === 'explorer'" class="trace-viewer">
            <ExplorerView :selected-node-id="selectedNodeId" @node-selected="onNodeSelected" />
          </div>

          <TraceNodeView v-if="selectedNode" :node="selectedNode" />
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { ref, computed, watch } from 'vue'
import { GROUPS_CONFIG } from '@/utils/nodeGroupsConfig'
import TraceNodeView from './TraceNodeView.vue'
import TimelineView from './TimelineView.vue'
import TreeView from './TreeView.vue'
import ExplorerView from './ExplorerView.vue'
import { BsTextField, BsSpinner } from 'quasar-ui-bs'
import { debounce } from 'lodash'
import { WT1iser } from '@/common/wt1'
import { Trace, TraceNode } from '@/common/interface/trace'
import { useTracesStore } from '@/stores/traces'

function findNodeById(node: TraceNode, id: string): TraceNode | null {
  if (!node || !id) return null
  if (node.id === id) return node as TraceNode
  if (node.children) {
    for (const c of node.children) {
      const found = findNodeById(c, id)
      if (found) return found
    }
  }
  return null
}

export default {
  name: 'TracesViewer',
  components: {
    TraceNodeView,
    TimelineView,
    TreeView,
    ExplorerView,
    BsTextField,
    BsSpinner
  },
  props: {
    viewMode: {
      type: String,
      default: 'tree'
    }
  },
  setup() {
    const tracesStore = useTracesStore()
    const filters = { nameQuery: '' }
    const selectedNodeId = ref<string | undefined>(undefined)
    const localNameQuery = ref(filters.nameQuery)
    const activeGroupFilter = ref<string | null>(null)

    const sendSearchEvent = debounce((query: string) => {
      if (!query || query.trim() === '') {
        return
      }

      WT1iser.searchNodes(query)
    }, 1000)

    watch(
      () => localNameQuery.value,
      (query) => {
        sendSearchEvent(query)
        tracesStore.setNodesFilters({ name: query })
      }
    )

    const selectedNode = computed(() => {
      if (
        !selectedNodeId.value ||
        !tracesStore.selectedTrace ||
        !tracesStore.selectedTrace.parentNode
      )
        return null
      return findNodeById(tracesStore.selectedTrace.parentNode, selectedNodeId.value)
    })

    function onNodeSelected(nodeId: string) {
      if (selectedNodeId.value === nodeId) {
        selectedNodeId.value = undefined
        setTimeout(() => {
          selectedNodeId.value = nodeId
        }, 0)
      } else {
        WT1iser.openNodeDetails(nodeId)
        selectedNodeId.value = nodeId
      }
    }

    function toggleGroupFilter(gKey: string) {
      if (tracesStore.nodesFilters.group === gKey) {
        tracesStore.setNodesFilters({ group: null })
      } else {
        WT1iser.highlightNodes(gKey)
        tracesStore.setNodesFilters({ group: gKey })
      }
    }

    const formattedOverallEstimatedCost = computed(() => {
      if (!tracesStore.selectedTrace || !tracesStore.selectedTrace.overallEstimatedCost == null) {
        return 0
      }
      return Number(tracesStore.selectedTrace.overallEstimatedCost).toPrecision(4)
    })

    const costPerThousand = computed(() => {
      if (!tracesStore.selectedTrace) return 0
      const cost = tracesStore.selectedTrace.overallEstimatedCost || 0
      const tokens = tracesStore.selectedTrace.overallTotalTokens || 0
      if (tokens === 0) return 0
      const cpt = (cost / tokens) * 1000
      return Number(cpt).toPrecision(4)
    })

    const costPerMillion = computed(() => {
      if (!tracesStore.selectedTrace) return 0
      const cost = tracesStore.selectedTrace.overallEstimatedCost || 0
      const tokens = tracesStore.selectedTrace.overallTotalTokens || 0
      if (tokens === 0) return 0
      const cpm = (cost / tokens) * 1000000
      return Number(cpm).toPrecision(4)
    })

    const showPerThousand = computed(() => {
      return (
        (tracesStore.selectedTrace?.overallTotalTokens || 0) > 0 &&
        (tracesStore.selectedTrace?.overallEstimatedCost || 0) > 0
      )
    })

    const showPerMillion = computed(() => {
      return (
        (tracesStore.selectedTrace?.overallTotalTokens || 0) > 0 &&
        (tracesStore.selectedTrace?.overallEstimatedCost || 0) > 0
      )
    })

    const groupLegend = computed(() => GROUPS_CONFIG)

    return {
      tracesStore,
      selectedNodeId,
      localNameQuery,
      activeGroupFilter,

      selectedNode,
      groupLegend,
      formattedOverallEstimatedCost,
      costPerThousand,
      costPerMillion,
      showPerThousand,
      showPerMillion,

      onNodeSelected,
      toggleGroupFilter
    }
  }
}
</script>

<style scoped>
.traces-viewer-root {
  height: 100%;
  min-height: inherit;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.content-area {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: inherit;
}

.sticky-top {
  position: sticky;
  top: 0;
  z-index: 100;
  background-color: #fff;
  padding-bottom: 8px;
}

.trace-viewer {
  height: calc(100vh - 160px);
}

.scrollable-body {
  flex: 1;
  overflow-y: auto;
  padding-right: 2px;
  height: 100%;
}

.top-level-usage-metrics {
  display: flex;
  gap: 20px;
  font-size: 13px;
  margin-bottom: 8px;
}

.usage-item {
  background-color: #d6e1fe;
  color: #333e48;
  border-radius: 16px;
  padding: 4px 6px;
}

.trace-header {
  margin-bottom: 2px;
  width: 100%;
}

.legend {
  margin-left: auto;
  font-size: 13px;
  color: #333e48;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 5px;
  cursor: pointer;
  user-select: none;
  padding: 4px 6px;
  border-radius: 4px;
  transition: background-color 0.2s;
}

.legend-item:hover {
  background-color: #d6e1fe;
  font-weight: 500;
}

.legend-color {
  display: inline-block;
  width: 14px;
  height: 14px;
  border-radius: 2px;
}

.legend-item-active {
  background-color: #d6e1fe !important;
  font-weight: 500;
  box-shadow: 0 0 6px rgba(33, 74, 181, 0.3) !important;
}
</style>
