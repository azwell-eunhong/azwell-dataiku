<template>
  <div class="timeline-outer-container">
    <div class="timeline-header-container">
      <div class="timeline-meta">
        Earliest start: {{ formattedEarliest }} | Total Duration:
        {{ formattedDuration }}
      </div>
      <div class="timeline-toolbar">
        <BsButton
          class="bs-secondary-button"
          @click="(redrawAndFit(), WT1iser.resetView(ViewMode.Timeline))"
        >
          Reset view
        </BsButton>
      </div>
    </div>

    <div class="timeline-section">
      <div v-show="loadingTimeline" class="overlay-spinner">
        <BsSpinner color="primary" size="2em" />
      </div>
      <div ref="timelineEl" class="timeline-graph"></div>

      <div v-if="tooltip.visible" :style="tooltipAnchorStyle as any">
        <q-tooltip v-model="tooltip.visible" no-parent-event anchor="bottom left" self="top left">
          <div v-html="tooltip.html"></div>
        </q-tooltip>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import 'vis-timeline/styles/vis-timeline-graph2d.css'

import dayjs from 'dayjs'
import { QTooltip } from 'quasar'
import { BsButton, BsSpinner } from 'quasar-ui-bs'
import { Timeline, DataSet, TimelineOptions } from 'vis-timeline/standalone'
import { ref, onMounted, watch, computed, defineComponent, nextTick } from 'vue'

import { WT1iser } from '@/common/wt1'
import { ViewMode } from '@/common/views'
import { classifyNodeGroup } from '@/utils/classifyNodeGroup'
import { gatherTimedNodes } from '@/utils/traceToGraph'
import { useTracesStore } from '@/stores/traces'
import { TraceNode } from '@/common/interface/trace'

export default defineComponent({
  name: 'TimelineView',
  components: {
    BsButton,
    BsSpinner,
    QTooltip
  },
  props: {
    selectedNodeId: {
      type: String,
      default: null
    }
  },
  emits: ['nodeSelected'],
  setup(props, { emit }) {
    let timeline: Timeline | null = null
    const tracesStore = useTracesStore()
    const timelineEl = ref<HTMLElement | null>(null)
    const itemsDS = new DataSet([])
    const groupsDS = new DataSet([])
    const loadingTimeline = ref(true)

    const tooltip = ref({
      visible: false,
      html: '',
      x: 0,
      y: 0
    })

    const tooltipAnchorStyle = computed(() => ({
      position: 'fixed',
      left: tooltip.value.x + 'px',
      top: tooltip.value.y + 'px',
      width: '0px',
      height: '0px'
    }))

    const allTimedNodes = computed(() => {
      return tracesStore.selectedTrace && tracesStore.selectedTrace.parentNode
        ? (gatherTimedNodes(tracesStore.selectedTrace.parentNode, []) as TraceNode[])
        : []
    })

    const itemsData = computed(() => {
      const sortedNodes = [...allTimedNodes.value].sort(
        (a, b) => new Date(a.begin || 0).getTime() - new Date(b.begin || 0).getTime()
      )

      return sortedNodes.map((node, index) => {
        const start = new Date(node.begin || 0)
        const end = node.end ? new Date(node.end) : start
        const duration = node.duration || 0
        const group = classifyNodeGroup(node)

        return {
          id: index,
          group: index,
          content: node.name || '(no name)',
          start,
          end: duration > 0 ? end : start,
          type: duration > 50 ? 'range' : 'point',
          className:
            duration > 50 ? `my-range-item group-${group}` : `my-point-item group-${group}`,
          data: {
            actualNodeId: node.id,
            name: node.name,
            startTime: start,
            endTime: end,
            duration,
            group
          }
        }
      })
    })

    const earliestBegin = computed(() => {
      const times = allTimedNodes.value.map((n) => new Date(n.begin || 0).getTime())
      const valid = times.filter((t) => !isNaN(t))
      return valid.length ? Math.min(...valid) : 0
    })

    const totalDuration = computed(() => {
      const ends = allTimedNodes.value.map((n) => new Date(n.end || 0).getTime())
      const valid = ends.filter((t) => !isNaN(t))
      return valid.length ? Math.max(...valid) - earliestBegin.value : 0
    })

    const formattedEarliest = computed(() =>
      earliestBegin.value ? dayjs(earliestBegin.value).format('YYYY-MM-DD HH:mm:ss') : 'N/A'
    )

    const formattedDuration = computed(() => {
      const ms = totalDuration.value
      const s = (ms / 1000).toFixed(2)
      return `${ms} ms (${s} s)`
    })

    onMounted(() => {
      if (!timelineEl.value) {
        loadingTimeline.value = false
        return
      }

      const earliest = earliestBegin.value
      const latest = earliest + totalDuration.value
      const buffer = 0.1 * totalDuration.value
      const options: TimelineOptions = {
        orientation: 'top',
        stack: false,
        autoResize: false,
        verticalScroll: true,
        horizontalScroll: true,
        height: 'calc(100vh - 200px)',
        min: isNaN(earliest) ? undefined : new Date(earliest - buffer),
        max: isNaN(latest) ? undefined : new Date(latest + buffer),
        groupOrder: (g1: any, g2: any) => g1.id - g2.id,
        order: (a: any, b: any) => new Date(a.start).getTime() - new Date(b.start).getTime(),
        zoomKey: 'shiftKey',
        showCurrentTime: true,
        moveable: true
      }

      timeline = new Timeline(timelineEl.value, itemsDS, groupsDS, options)

      timeline.on('changed', () => {
        loadingTimeline.value = false
      })

      timeline.on('itemover', (eventProps) => {
        const it = itemsDS.get(eventProps.item)
        if (it) showTooltip(eventProps.event, it)
      })

      timeline.on('itemout', hideTooltip)
      timeline.on('rangechange', hideTooltip)

      timeline.on('select', (props) => {
        if (!props.items || !props.items.length) return
        const selectedItem: any = itemsDS.get(props.items[0])
        if (selectedItem) {
          emit('nodeSelected', selectedItem.data.actualNodeId)
        }
      })

      refreshTimelineItems()
    })

    watch(
      () => tracesStore.selectedTrace,
      () => {
        refreshTimelineItems()
        redrawAndFit()
      },
      { deep: true }
    )

    watch(
      () => props.selectedNodeId,
      (newVal) => {
        if (!timeline) return
        const found: any = itemsDS.get().find((it: any) => it.data.actualNodeId === newVal)
        if (found) {
          timeline.setSelection([found.id])
        } else {
          timeline.setSelection([])
        }
      },
      { immediate: true }
    )

    function refreshTimelineItems() {
      if (!timeline) return
      loadingTimeline.value = true

      itemsDS.clear()
      groupsDS.clear()

      const newItems = itemsData.value
      itemsDS.add(newItems as any)
      const newGroups = newItems.map((it: any) => ({ id: it.id, content: '' }))
      groupsDS.add(newGroups as any)

      nextTick(() => {
        timeline?.redraw()

        const visContentEl = timelineEl.value?.querySelector('.vis-content') as HTMLElement
        const currentScrollTop = visContentEl?.scrollTop ?? 0

        timeline?.fit({ animation: false })

        if (visContentEl) {
          visContentEl.scrollTop = currentScrollTop
        }

        if (props.selectedNodeId) {
          const found: any = itemsDS
            .get()
            .find((it: any) => it.data.actualNodeId === props.selectedNodeId)
          if (found) {
            timeline?.setSelection([found.id])
          } else {
            timeline?.setSelection([])
          }
        }

        loadingTimeline.value = false
      })
    }

    function redrawAndFit() {
      if (!timeline) return

      nextTick(() => {
        const earliest = earliestBegin.value
        const latest = earliest + totalDuration.value
        const buffer = 0.1 * totalDuration.value
        const options: TimelineOptions = {
          min: isNaN(earliest) ? undefined : new Date(earliest - buffer),
          max: isNaN(latest) ? undefined : new Date(latest + buffer)
        }

        timeline?.redraw()
        timeline?.setOptions(options)

        const visContentEl = timelineEl.value?.querySelector('.vis-content') as HTMLElement
        const currentScrollTop = visContentEl?.scrollTop ?? 0

        timeline?.fit({ animation: false })

        if (visContentEl) {
          visContentEl.scrollTop = currentScrollTop
        }
      })
    }

    function showTooltip(domEvent: any, item: any) {
      tooltip.value = {
        visible: true,
        x: domEvent.clientX + 10,
        y: domEvent.clientY + 10,
        html: buildTooltipHTML(item)
      }
    }

    function hideTooltip() {
      tooltip.value.visible = false
    }

    function buildTooltipHTML(item: any) {
      const d = item.data
      if (!d) return '(no data)'
      const startStr = dayjs(d.startTime).format('HH:mm:ss.SSS')
      const endStr = d.duration > 0 ? dayjs(d.endTime).format('HH:mm:ss.SSS') : startStr
      return `
        <div>${d.name || '(no name)'}</div>
        <div>
          <strong>Start:</strong> ${startStr}<br>
          <strong>End:</strong> ${endStr}<br>
          <strong>Duration:</strong> ${d.duration} ms
        </div>
      `
    }

    return {
      timelineEl,
      loadingTimeline,
      formattedEarliest,
      formattedDuration,
      redrawAndFit,
      tooltip,
      tooltipAnchorStyle,
      ViewMode,
      WT1iser
    }
  }
})
</script>

<style lang="scss">
.timeline-header-container {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.vis-item.vis-range {
  background-color: transparent;
  border-color: transparent;
}

.vis-item-visible-frame {
  position: relative;
  top: -5px;
}

.vis-item-overflow {
  background-color: transparent;
}

.my-range-item.group-span .vis-item-visible-frame {
  background-color: #bbb6b6;
}

.my-range-item.group-guard .vis-item-visible-frame {
  background-color: #64afd0;
}

.my-range-item.group-agent .vis-item-visible-frame {
  background-color: #d66f9e;
}

.my-range-item.group-tool .vis-item-visible-frame {
  background-color: #53c081;
}

.my-range-item.group-llm .vis-item-visible-frame {
  background-color: #4285f4;
}

.my-range-item.group-event .vis-item-visible-frame {
  background-color: #ff832b;
}

.my-point-item.vis-dot {
  border: 4px solid #bbb6b6;
}

.my-point-item.vis-dot.group-span {
  border: 4px solid #bbb6b6;
}

.my-point-item.vis-dot.group-guard {
  border: 4px solid #64afd0;
}

.my-point-item.vis-dot.group-agent {
  border: 4px solid #d66f9e;
}

.my-point-item.vis-dot.group-tool {
  border: 4px solid #53c081;
}

.my-point-item.vis-dot.group-llm {
  border: 4px solid#4285f4;
}

.my-point-item.vis-dot.group-event {
  border: 4px solid #ff832b;
}

.vis-item.my-range-item {
  .vis-item-visible-frame {
    height: 4px;
    border-radius: 2px;
  }

  .vis-item-content {
    position: relative;
    top: -5px;
    left: 0;
    background: transparent !important;
    color: #333e48;
    padding: 2px 4px;
  }
}

.vis-item-content {
  font-size: 13px;
  font-weight: 500;
}

.vis-item.vis-range.vis-selected {
  background-color: #d6e1fe;
  border-color: transparent !important;
}

.vis-item.vis-point.vis-selected {
  background-color: #d6e1fe !important;
  border-color: transparent !important;
}
</style>
