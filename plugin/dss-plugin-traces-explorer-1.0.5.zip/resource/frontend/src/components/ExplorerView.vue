<template>
  <div class="explorer-container">
    <div v-if="!tracesStore.selectedTrace || !tracesStore.selectedTrace?.id" class="no-trace-msg">
      No data to explore
    </div>

    <div v-else class="explorer-table">
      <div ref="tabulatorRef" class="explorer-tabulator"></div>
    </div>
  </div>
</template>

<script lang="ts">
import dayjs from 'dayjs'
import { debounce } from 'lodash'
import {
  SorterFromTable,
  TabulatorFull as Tabulator,
  CellComponent,
  RowComponent,
  ColumnDefinition
} from 'tabulator-tables'
import { defineComponent, ref, onMounted, watch, computed, nextTick } from 'vue'

import { TraceNode, UsageMetadata } from '@/common/interface/trace'
import { WT1iser } from '@/common/wt1'
import { classifyNodeGroup } from '@/utils/classifyNodeGroup'
import { getGroupColor } from '@/utils/nodeGroupsConfig'
import { useTracesStore } from '@/stores/traces'

function buildTabulatorData(root: TraceNode | undefined): any[] {
  if (!root) return []

  function usageToLine(usage: UsageMetadata | undefined): any {
    if (!usage) return ''
    const parts = []
    if (usage.promptTokens != null) parts.push(`Prompt: ${usage.promptTokens}`)
    if (usage.completionTokens != null) parts.push(`Completion: ${usage.completionTokens}`)
    if (usage.totalTokens != null) parts.push(`Total: ${usage.totalTokens}`)
    if (usage.estimatedCost != null) parts.push(`Cost: ${usage.estimatedCost}`)
    return parts.join(', ')
  }

  function buildRow(n: TraceNode): any {
    const childRows =
      Array.isArray(n.children) && n.children.length > 0 ? n.children.map(buildRow) : null

    return {
      id: n.id,
      name: n.name || n.type || '(no name)',
      duration: n.duration,
      begin: n.begin ? dayjs(n.begin).format('HH:mm:ss.SSS') : '',
      end: n.end ? dayjs(n.end).format('HH:mm:ss.SSS') : '',
      usageLine: usageToLine(n.usageMetadata),
      group: classifyNodeGroup(n),
      ...(childRows ? { children: childRows } : {})
    }
  }

  return [buildRow(root)]
}

export default defineComponent({
  name: 'ExplorerView',
  props: {
    selectedNodeId: {
      type: String,
      default: null
    }
  },
  emits: ['nodeSelected'],
  setup(props, { emit }) {
    const tabulatorRef = ref(null)
    const tracesStore = useTracesStore()
    let tableInstance: Tabulator | null = null

    const tableIsBuilt = ref(false)

    const tableData = computed(() => {
      if (!tracesStore.selectedTrace || !tracesStore.selectedTrace.id) return []
      return buildTabulatorData(tracesStore.selectedTrace.parentNode)
    })

    async function reselectCurrentNode(scroll = false) {
      if (!tableIsBuilt.value || !props.selectedNodeId || !tableInstance) {
        tableInstance?.deselectRow()
        return
      }

      function findRowById(table: Tabulator, id: string) {
        function searchRows(rows: RowComponent[]): RowComponent | null {
          for (const row of rows) {
            if (row.getData().id === id) {
              return row
            }
            const children = row.getTreeChildren()
            if (children?.length) {
              const result = searchRows(children)
              if (result) return result
            }
          }
          return null
        }
        return searchRows(table.getRows('all'))
      }

      try {
        const row = findRowById(tableInstance, props.selectedNodeId)
        if (row) {
          const parentRow = row.getTreeParent()
          if (parentRow) {
            parentRow.treeExpand()
          }
          tableInstance.deselectRow()
          row.select()
          if (scroll) {
            // Scroll?
          }
        } else {
          tableInstance.deselectRow()
        }
      } catch (err) {
        console.error('[ExplorerView] error selecting row:', err)
      }
    }

    watch(
      () => tableData.value,
      async (newVal) => {
        if (!tableInstance) return

        if (!tableIsBuilt.value) {
          return
        }

        await tableInstance.setData(newVal)
        tableInstance.getRows().forEach((r) => r.treeExpand())
        await nextTick()
        reselectCurrentNode()
      },
      { immediate: true }
    )

    watch(
      () => props.selectedNodeId,
      async () => {
        if (!tableIsBuilt.value || !tableInstance) {
          return
        }
        await nextTick()
        reselectCurrentNode(true)
      },
      { immediate: true }
    )

    onMounted(() => {
      if (!tabulatorRef.value) {
        console.error('[ExplorerView] No tabulatorRef!')
        return
      }

      const columns = [
        {
          title: 'Name',
          field: 'name',
          minWidth: 150,
          formatter: (cell: CellComponent) => {
            const row = cell.getRow()
            const data = row.getData()
            const color = getGroupColor(data.group || 'span')
            const val = cell.getValue() || ''
            return `
             
                <div class="name-block">
                  <div class="name-inline">
                    <div class="node_col_badge" style="background-color:${color};"></div>
                    <div>${val}</div>
                  </div>
                  </div>
            `
          }
        },
        {
          title: 'Duration',
          field: 'duration',
          width: 80,
          hozAlign: 'left',
          sorter: 'number',
          formatter: (cell: CellComponent) => {
            const dur = cell.getValue()
            return dur ? (dur / 1000).toFixed(2) + ' s' : ''
          }
        },
        { title: 'Begin', field: 'begin', width: 120 },
        { title: 'End', field: 'end', width: 120 },
        { title: 'Usage', field: 'usageLine', minWidth: 120 }
      ]

      tableInstance = new Tabulator(tabulatorRef.value, {
        data: tableData.value,
        layout: 'fitColumns',
        height: '100%',
        dataTree: true,
        dataTreeChildField: 'children',
        dataTreeStartExpanded: true,
        columns: columns as ColumnDefinition[],
        placeholder: 'No data available'
      })

      tableInstance.on('tableBuilt', () => {
        tableIsBuilt.value = true
        tableInstance?.getRows().forEach((r) => r.treeExpand())

        reselectCurrentNode()
      })

      tableInstance.on('rowClick', (e, row) => {
        if (!tableIsBuilt.value) return

        tableInstance?.deselectRow()
        row.select()
        emit('nodeSelected', row.getData().id)
      })

      const sendSortEvent = debounce((sorters: SorterFromTable[]) => {
        // if no sorters (default state after table is built or tab switch), don't send an event
        if (sorters.length === 0) {
          return
        }

        WT1iser.sortExplorerNodes(
          sorters.map((s) => ({
            field: s.field,
            dir: s.dir
          }))
        )
      }, 1000)

      tableInstance.on('dataSorting', (sorters: SorterFromTable[]) => {
        sendSortEvent(sorters)
      })
    })

    return {
      tabulatorRef,
      tracesStore
    }
  }
})
</script>

<style scoped lang="scss">
.explorer-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  background-color: #fff;
  color: #333e48;
  font-size: 13px;
}

.no-trace-msg {
  padding: 16px;
  text-align: center;
  color: #999;
}

.explorer-table {
  display: flex;
  flex-direction: column;
  height: 100%;
  border: 1px solid #ddd;
  border-radius: 4px;
  overflow: hidden;
}

.explorer-tabulator {
  flex: 1;
  height: 100%;
}

.explorer-tabulator .tabulator-header {
  position: sticky;
  top: 0;
  z-index: 10;
}

.tabulator {
  background-color: #fff;
  margin: 0;
}

::v-deep .tabulator-row.tabulator-selected {
  background-color: #d6e1fe !important;
  box-shadow: 0 0 6px rgba(33, 74, 181, 0.3) !important;
  font-weight: 500;
}

::v-deep .explorer-tabulator .tabulator-row:hover {
  background-color: #d6e1fe !important;
  box-shadow: 0 0 6px rgba(33, 74, 181, 0.3) !important;
  font-weight: 500;
}

::v-deep .node_col_badge {
  width: 14px;
  height: 14px;
  border-radius: 2px;
  margin-right: 6px;
}

::v-deep .name-block {
  display: inline-block;
}

::v-deep .name-inline {
  display: inline-flex;
  align-items: center;
}

::v-deep .name-inline .node_col_badge,
::v-deep .name-inline div {
  position: relative;
  top: 4px;
}
</style>
