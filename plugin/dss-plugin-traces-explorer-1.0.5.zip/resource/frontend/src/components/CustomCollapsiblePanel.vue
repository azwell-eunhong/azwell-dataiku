<template>
  <!-- A parent wrapper so we can insert an overlay at the same level as the panel -->
  <div class="bs-panel-wrapper">
    <!-- If expanded, show a modal overlay behind the panel. Clicking it toggles expanded off -->
    <div v-if="internalExpanded" class="bs-panel-overlay" @click.stop="toggleExpand"></div>

    <div class="bs-collapsable-panel" :class="{ maximized: internalExpanded }" :style="panelStyle">
      <!-- Header area -->
      <div
        class="bs-collapsable-panel-title-container"
        :class="{ collapsable: collapsable && !disabled }"
        :style="{ backgroundColor: headerBgColor }"
      >
        <div class="bs-collapsable-panel-title" :style="{ color: titleTextColor }">
          {{ title }}
        </div>

        <!-- Hide the collapse arrow if expanded -->
        <i
          v-if="collapsable && !internalExpanded"
          class="arrow-icon"
          :class="`dku-icon-chevron-${internalCollapsed ? 'down' : 'up'}-16`"
          :style="{ color: titleTextColor }"
          @click.stop="toggleSection"
        ></i>

        <div class="header-right-icons">
          <!-- Show expand icon(s) if maximizable -->
          <template v-if="maximizable">
            <i
              v-if="!internalExpanded"
              class="material-icons expand-btn"
              :style="{ color: titleTextColor }"
              title="Expand to full screen"
              @click.stop="toggleExpand"
            >
              zoom_out_map
            </i>
            <i
              v-else
              class="material-icons expand-btn"
              :style="{ color: titleTextColor }"
              title="Exit full screen"
              @click.stop="toggleExpand"
            >
              fullscreen_exit
            </i>
          </template>

          <!-- Close button if closable -->
          <div
            v-if="closable"
            class="close-btn"
            :style="{ color: titleTextColor }"
            @click.stop="closePanel"
          >
            ×
          </div>
        </div>
      </div>

      <!-- Content area (collapsible) -->
      <div v-if="!internalCollapsed" class="bs-collapsable-panel-content">
        <div class="collapsible-content">
          <div v-if="selectorLabel" class="bs-selection-section-title">
            {{ selectorLabel }}
          </div>
          <!-- Slot for whatever content is inside -->
          <slot></slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'CustomCollapsiblePanel',
  props: {
    title: {
      type: String,
      required: true
    },
    selectorLabel: {
      type: String,
      default: ''
    },
    collapsable: {
      type: Boolean,
      default: false
    },
    infoText: {
      type: String,
      default: ''
    },
    disabled: {
      type: Boolean,
      default: false
    },
    collapsed: {
      type: Boolean,
      default: false
    },
    closable: {
      type: Boolean,
      default: false
    },
    headerBgColor: {
      type: String,
      default: '#FFFFFF'
    },
    /**
     * If true, show the expand button next to the close button.
     */
    maximizable: {
      type: Boolean,
      default: false
    },
    /**
     * If used with v-model, indicates the "expanded" (fullscreen) state
     */
    expanded: {
      type: Boolean,
      default: false
    }
  },
  emits: ['update:collapsed', 'update:expanded', 'close'],
  data() {
    return {
      // Track local collapsed state
      internalCollapsed: this.collapsed,
      // Track local expanded (fullscreen) state
      internalExpanded: this.expanded
    }
  },
  computed: {
    titleTextColor(): string {
      const darkishColors = ['#53c081', '#d66f9e', '#4285f4', '#ff832b', '#bbb6b6']
      if (darkishColors.includes(this.headerBgColor.toLowerCase())) {
        return '#ffffff'
      }
      return '#333333'
    },
    // If expanded, position/fill screen
    panelStyle(): Record<string, string> {
      if (this.internalExpanded) {
        return {
          position: 'fixed',
          top: '0',
          left: '0',
          right: '0',
          bottom: '0',
          zIndex: '9999'
        }
      }
      return {}
    }
  },
  watch: {
    collapsed(newVal) {
      this.internalCollapsed = newVal
    },
    expanded(newVal) {
      this.internalExpanded = newVal
    },
    internalExpanded(newVal) {
      this.$emit('update:expanded', newVal)
    },
    internalCollapsed(newVal) {
      this.$emit('update:collapsed', newVal)
    }
  },
  methods: {
    toggleSection() {
      if (this.collapsable && !this.disabled) {
        this.internalCollapsed = !this.internalCollapsed
      }
    },
    closePanel() {
      this.$emit('close')
    },
    toggleExpand() {
      this.internalExpanded = !this.internalExpanded
    }
  }
})
</script>

<style scoped>
.bs-collapsable-panel {
  border: 1px solid #eeeeee;
  border-radius: 4px;
  background-color: #ffffff;
  display: flex;
  flex-direction: column;
}

.bs-collapsable-panel-title-container {
  padding: 2px 8px;
  display: flex;
  align-items: center;
  user-select: none;
  transition: background-color 0.2s ease-in-out;
  justify-content: space-between;
  cursor: default;
}

.bs-collapsable-panel-title {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 600;
  font-size: 12px;
  line-height: 1.4;
  margin-right: 8px;
}

.header-right-icons {
  display: flex;
  align-items: center;
}

.arrow-icon {
  transition: transform 0.2s;
  font-size: 14px;
  margin-right: 6px;
  cursor: pointer;
}

.bs-collapsable-panel-content {
  padding: 0;
  border-top: 1px solid #eeeeee;
  border-radius: 0 0 4px 4px;
  flex: 1 1 auto;
  overflow: auto;
}

.bs-selection-section-title {
  margin-bottom: 5px;
  color: #5b5b5b;
  font-size: 12px;
  font-weight: 500;
}

.collapsible-content {
  color: #333e48;
  font-size: 12px;
  line-height: 1.5;
  padding: 4px 6px;
  display: flex;
  flex-direction: column;
  height: 100%;
}

.close-btn {
  font-size: 18px;
  line-height: 1;
  cursor: pointer;
  margin-left: 8px;
  user-select: none;
}

.expand-btn {
  cursor: pointer;
  font-size: 20px;
  margin-left: 8px;
  user-select: none;
}

.bs-panel-wrapper {
  position: relative;
}

.bs-panel-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 9998;
  /* panel is 9999 */
}
</style>
