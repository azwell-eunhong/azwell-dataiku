<template>
  <div class="traces-list-container">
    <div class="paste-trace-section">
      <template v-if="!showPasteArea">
        <BsButton class="paste-trace-btn" color="primary" size="sm" @click="handlePasteNewTrace">
          Paste new trace
        </BsButton>
      </template>
      <template v-else>
        <div class="q-mb-sm paste-trace-instructions">
          Paste a JSON trace or top-level XmlRawResponse object.
        </div>
        <q-input
          v-model="pastedJson"
          type="textarea"
          autogrow
          filled
          class="paste-json-textarea"
          label="JSON Object"
        />
        <div v-if="pasteError" class="paste-error">{{ pasteError }}</div>
        <div class="row q-mt-sm q-gutter-sm">
          <BsButton color="primary" size="sm" @click="handleAddTrace"> Add trace </BsButton>
          <BsButton size="sm" flat @click="handleCancelPaste"> Cancel </BsButton>
        </div>
      </template>
    </div>

    <div
      v-if="tracesStore.localTrace"
      class="local-trace-card"
      :class="{ selected: tracesStore.selectedTrace?.id == tracesStore.localTrace.id }"
      @click="selectTrace(tracesStore.localTrace.id)"
    >
      <div class="close-btn" @click.stop="removeLocalTrace">×</div>
      <q-tooltip transition-show="fade" transition-hide="fade" max-width="200px">
        Local pasted trace
      </q-tooltip>

      <div class="row items-center">
        <q-icon name="insert_drive_file" size="16px" class="q-mr-sm" />
        <div class="trace-title-local">Local Pasted Trace</div>
      </div>

      <div class="trace-meta-local">
        <q-icon name="event" size="16px" />
        <span class="trace-date-time">
          {{ formatTraceDateTime(tracesStore.localTrace.begin) }}
        </span>
        <q-icon name="timer" size="16px" style="margin-left: 8px" />
        <span class="trace-duration">
          {{ ((tracesStore.localTrace.duration || 0) / 1000).toFixed(2) }} s
        </span>
      </div>
    </div>

    <div v-if="hasDatasetTraces" class="filters-section">
      <div class="filters-row row items-center q-gutter-sm">
        <BsTextField v-model="nameFilter" placeholder="Search trace name..." style="width: 300px" />

        <div class="duration-filter row items-center q-gutter-sm">
          <label class="filter-label">Duration:</label>
          <vue-slider
            v-model="durationRange"
            :min="durationBounds.min"
            :max="durationBounds.max"
            :interval="1"
            :dot-size="14"
            :width="220"
            :tooltip="'hover'"
            :enable-cross="false"
            :process-style="{ backgroundColor: 'var(--q-primary)' }"
            :tooltip-style="{ backgroundColor: 'var(--q-primary)' }"
            :style="{ padding: '10px' }"
            range
          />
          <div class="duration-values text-grey-7">
            {{ durationRange[0] }} ms &mdash; {{ durationRange[1] }} ms
          </div>
        </div>

        <div class="date-filter column q-gutter-sm">
          <label class="filter-label">Start Date:</label>

          <div class="row items-center q-gutter-sm">
            <label>From:</label>
            <q-input
              v-model="dateFrom"
              dense
              filled
              class="date-input"
              mask="##/##/####"
              fill-mask
              placeholder="MM/DD/YYYY"
              style="width: 120px"
              @keydown.stop=""
            >
              <template #append>
                <q-icon name="event" class="cursor-pointer" @click.stop="openFromCalendar" />
              </template>
            </q-input>
            <q-menu v-model="fromMenu" cover :no-parent-event="true">
              <q-date
                v-model="fromDateModel"
                mask="YYYY-MM-DD"
                @update:model-value="onFromDateSelected"
              />
            </q-menu>
          </div>

          <div class="row items-center q-gutter-sm">
            <label style="margin-right: 13px">To:</label>
            <q-input
              v-model="dateTo"
              dense
              filled
              class="date-input"
              mask="##/##/####"
              fill-mask
              placeholder="MM/DD/YYYY"
              style="width: 120px"
              @keydown.stop=""
            >
              <template #append>
                <q-icon name="event" class="cursor-pointer" @click.stop="openToCalendar" />
              </template>
            </q-input>
            <q-menu v-model="toMenu" cover :no-parent-event="true">
              <q-date
                v-model="toDateModel"
                mask="YYYY-MM-DD"
                @update:model-value="onToDateSelected"
              />
            </q-menu>
          </div>
        </div>
      </div>

      <div class="filter-chips row items-center q-gutter-sm">
        <q-chip
          v-if="isDateFilterActive"
          size="sm"
          color="grey-7"
          text-color="white"
          class="q-ma-xs"
          removable
          @remove="onDateFilterChipClose"
        >
          Date filter
        </q-chip>

        <q-chip
          v-if="isDurationFilterActive"
          size="sm"
          color="grey-7"
          text-color="white"
          class="q-ma-xs"
          removable
          @remove="onDurationFilterChipClose"
        >
          Duration: {{ durationRange[0] }} - {{ durationRange[1] }}
        </q-chip>
      </div>
    </div>
    <div v-if="hasDatasetTraces">
      <BsButton class="reload-btn" color="primary" size="sm" @click="handleReloadTraces">
        Reload traces
      </BsButton>
    </div>

    <div v-if="tracesStore.isLoadingList" class="loading-container">
      <BsSpinner color="primary" size="2em" />
    </div>
    <div v-else class="traces-scroll-area">
      <template v-if="filteredTraces.length === 0 && tracesStore.datasetTraces.length != 0">
        <div class="no-traces-msg">No trace matches the filters</div>
      </template>
      <template v-else-if="tracesStore.datasetTraces.length === 0">
        <div class="no-traces-msg">
          No traces found or dataset not selected in the webapp configuration
        </div>
      </template>
      <template v-else>
        <q-scroll-area class="flex column fit" style="overflow: auto">
          <q-virtual-scroll
            ref="virtualScroll"
            :items="displayItems"
            :size="42"
            :virtual-scroll-slice-size="30"
            class="flat-list"
          >
            <template #default="props">
              <template v-if="props.item.type === 'group'">
                <div class="group-header" :key="props.item.name">
                  {{ props.item.label }}
                </div>
              </template>

              <template v-else-if="props.item.type === 'item'">
                <q-item
                  :key="props.item.item.id"
                  clickable
                  :active="props.item.item.id == tracesStore.selectedTraceId"
                  active-class="selected-item-active"
                  class="trace-card"
                  tag="div"
                  dense
                  @click="
                    (selectTrace(props.item.item.id), WT1iser.selectTrace(props.item.item.id))
                  "
                >
                  <q-tooltip transition-show="fade" transition-hide="fade" max-width="200px">
                    {{ props.item.item.name }}
                  </q-tooltip>
                  <q-item-section>
                    <div class="trace-title">{{ props.item.item.name }}</div>
                    <div class="trace-meta">
                      <q-icon name="event" size="16px" />
                      <span class="trace-date-time">
                        {{ formatTraceDateTime(props.item.item.begin) }}
                      </span>
                      <q-icon name="timer" size="16px" style="margin-left: 4px" />
                      <span class="trace-duration">
                        {{ (props.item.item.duration / 1000).toFixed(2) }} s
                      </span>
                    </div>
                  </q-item-section>
                </q-item>
              </template>
            </template>
          </q-virtual-scroll>
        </q-scroll-area>
      </template>
    </div>
  </div>
</template>

<script lang="ts">
import dayjs from 'dayjs'
import { debounce } from 'lodash'
import { Notify } from 'quasar'
import {
  QVirtualScroll,
  QItem,
  QItemSection,
  QIcon,
  QScrollArea,
  QTooltip,
  QInput,
  QMenu,
  QDate,
  QChip
} from 'quasar'
import { BsSpinner, BsTextField, BsButton } from 'quasar-ui-bs'
import { ref, onMounted, computed, watch, Ref } from 'vue'
import VueSlider from 'vue-3-slider-component'

import { API } from '@/Api'
import { WT1iser } from '@/common/wt1'
import { useTracesStore } from '@/stores/traces'
import { formatTraceDateTime, parseMDY, smallDateFromISO } from '@/utils/formatDate'
import {
  getLocalTraceItemName,
  getRawTraceFromLS,
  getTraceFromLS,
  removeTraceFromLS
} from '@/utils/localStorage'
import { transformItemsForDisplay } from '@/utils/tracesToDisplayItems'
import { prepareTrace } from '@/utils/prepareTrace'
import { EXPLORE_TRACE_STORAGE_KEY, URL_EXPLORE_TRACE_PARAM_KEY } from '@/utils/config'

export default {
  name: 'TracesList',
  components: {
    QVirtualScroll,
    QItem,
    QItemSection,
    QIcon,
    QScrollArea,
    QTooltip,
    QInput,
    QMenu,
    QDate,
    QChip,
    BsSpinner,
    BsTextField,
    BsButton,
    VueSlider
  },
  setup() {
    // Store
    const tracesStore = useTracesStore()

    // Local trace
    const showPasteArea: Ref<boolean> = ref(false)
    const pastedJson: Ref<string> = ref('')
    const pasteError: Ref<string> = ref('')

    // Filters
    const nameFilter = ref('')
    const durationRange: Ref<[number, number]> = ref([0, 10000])

    const dateFrom = ref('')
    const dateTo = ref('')

    const fromMenu = ref(false)
    const toMenu = ref(false)

    const fromDateModel: Ref<string | null> = ref(null)
    const toDateModel: Ref<string | null> = ref(null)

    onMounted(async () => {
      // loading local trace
      const itemName = getLocalTraceItemName(window.location.href)
      tracesStore.localTrace = getTraceFromLS(itemName)

      // loading explore trace
      const urlObj = new URL(window.location.href)
      if (urlObj.searchParams.get(URL_EXPLORE_TRACE_PARAM_KEY) == 'true') {
        const exploreTraceLS = getRawTraceFromLS(EXPLORE_TRACE_STORAGE_KEY)
        const { trace, error } = prepareTrace(exploreTraceLS)

        if (error) {
          console.error(error)
          Notify.create({
            type: 'negative',
            message: "Couldn't retrieve trace."
          })
        } else {
          Notify.create({
            type: 'positive',
            message: 'Trace successfully retrieved.'
          })
          tracesStore.exploreTrace = trace
        }
      }

      // loading dataset traces
      try {
        tracesStore.datasetTraces = await API.listTraces()
        setDefaultDateFilters()
      } catch (err) {
        console.error('Error loading traces:', err)
        Notify.create({
          type: 'negative',
          message: "Couldn't load traces, please try again later."
        })
      } finally {
        tracesStore.isLoadingList = false
      }
    })

    watch(
      () => tracesStore.traces,
      () => {
        // When traces are updated, check if a trace is selected
        if (!tracesStore.selectedTraceId && tracesStore.traces.length > 0) {
          selectTrace(tracesStore.traces[0].id)
        }

        // When traces are updated, if a trace is selected and has no content,
        // we need to force a refresh (happens after reloading dataset traces)
        if (tracesStore.selectedTraceId && !tracesStore.selectedTrace?.parentNode) {
          selectTrace(tracesStore.selectedTraceId)
        }
      },
      { deep: true }
    )

    const durationBounds = computed(() => {
      const allDurations = []

      for (const t of tracesStore.datasetTraces) {
        if (t.duration != null) allDurations.push(t.duration)
      }

      if (allDurations.length === 0) {
        return { min: 0, max: 10000 }
      }

      return {
        min: Math.min(...allDurations),
        max: Math.max(...allDurations)
      }
    })

    // TODO: move to tracesStore
    const filteredTraces = computed(() => {
      if (!tracesStore.datasetTraces || tracesStore.datasetTraces.length === 0) return []

      // Call the throttled event sender
      sendFilterEvent(nameFilter.value, durationRange.value, dateFrom.value, dateTo.value)

      return tracesStore.datasetTraces.filter((t) => {
        if ((nameFilter.value || '').trim() !== '') {
          const lowerName = (t.name || '').toLowerCase()
          if (!lowerName.includes(nameFilter.value.toLowerCase())) return false
        }
        if (t.duration == null) return false
        if (t.duration < durationRange.value[0] || t.duration > durationRange.value[1]) {
          return false
        }
        const traceTs = new Date(t.begin || '').getTime()
        if (dateFrom.value) {
          const fromDate = parseMDY(dateFrom.value)
          if (fromDate && traceTs < fromDate.getTime()) return false
        }
        if (dateTo.value) {
          const toDate = parseMDY(dateTo.value)
          if (toDate && traceTs > toDate.getTime() + 86399999) return false
        }
        return true
      })
    })

    const displayItems = computed(() => {
      return transformItemsForDisplay(filteredTraces.value)
    })

    const hasDatasetTraces = computed(() => {
      return tracesStore.datasetTraces.length > 0
    })

    const isDateFilterActive = computed(() => {
      return Boolean(parseMDY(dateFrom.value) || parseMDY(dateTo.value))
    })

    const isDurationFilterActive = computed(() => {
      return (
        durationRange.value[0] !== durationBounds.value.min ||
        durationRange.value[1] !== durationBounds.value.max
      )
    })

    watch(
      () => durationBounds,
      () => {
        durationRange.value[0] = durationBounds.value.min
        durationRange.value[1] = durationBounds.value.max
      },
      { deep: true }
    )

    // We need to set default values in the filters because there is a bug in the
    // BS date picker component that makes it impossible to pick the current date
    // if no other date has been selected first.
    function setDefaultDateFilters() {
      if (tracesStore.datasetTraces.length > 0) {
        const minDate = tracesStore.datasetTraces.reduce(
          (min, current) => (current < min ? min : current),
          tracesStore.datasetTraces[0]
        ).begin
        const maxDate = tracesStore.datasetTraces.reduce(
          (max, current) => (current > max ? current : max),
          tracesStore.datasetTraces[0]
        ).begin

        if (minDate && maxDate) {
          dateFrom.value = smallDateFromISO(minDate)
          dateTo.value = smallDateFromISO(maxDate)
        }
      }
    }

    function openFromCalendar() {
      const parsed = parseMDY(dateFrom.value)
      fromDateModel.value = parsed
        ? dayjs(parsed).format('YYYY-MM-DD')
        : dayjs().format('YYYY-MM-DD')
      fromMenu.value = true
    }

    function openToCalendar() {
      const parsed = parseMDY(dateTo.value)
      toDateModel.value = parsed ? dayjs(parsed).format('YYYY-MM-DD') : dayjs().format('YYYY-MM-DD')
      toMenu.value = true
    }

    function onFromDateSelected(val: string) {
      fromMenu.value = false
      if (val) {
        dateFrom.value = dayjs(val).format('MM/DD/YYYY')
      }
    }

    function onToDateSelected(val: string) {
      toMenu.value = false
      if (val) {
        dateTo.value = dayjs(val).format('MM/DD/YYYY')
      }
    }

    async function handleReloadTraces() {
      WT1iser.reloadTraces()
      tracesStore.isLoadingList = true

      try {
        // force the refresh of the traces list in the backend
        await API.reloadTraces()
        // fetch the traces list
        tracesStore.datasetTraces = await API.listTraces()
        setDefaultDateFilters()

        Notify.create({
          type: 'positive',
          message: 'Traces reloaded successfully!'
        })
      } catch (err) {
        console.error('Error loading traces:', err)

        Notify.create({
          type: 'negative',
          message: "Couldn't reload traces, please try again later."
        })
      } finally {
        tracesStore.isLoadingList = false
      }
    }

    // Create throttled event sender
    const sendFilterEvent = debounce(
      (nameFilter: string, durationRange: [number, number], dateFrom: string, dateTo: string) => {
        if (
          nameFilter === '' &&
          durationRange[0] === durationBounds.value.min &&
          durationRange[1] === durationBounds.value.max &&
          dateFrom === '' &&
          dateTo === ''
        ) {
          return
        }

        WT1iser.filterTraces(nameFilter, durationRange.join(','), dateFrom, dateTo)
      },
      1000
    )

    function onDateFilterChipClose() {
      resetDateFilter()
    }

    function resetDateFilter() {
      dateFrom.value = ''
      dateTo.value = ''
    }

    function onDurationFilterChipClose() {
      resetDurationFilter()
    }

    function resetDurationFilter() {
      durationRange.value = [durationBounds.value.min, durationBounds.value.max]
    }

    function handlePasteNewTrace() {
      WT1iser.pasteNewTrace()
      showPasteArea.value = true
    }

    function handleCancelPaste() {
      WT1iser.cancelPasteTrace()
      showPasteArea.value = false
      pastedJson.value = ''
      pasteError.value = ''
    }

    function handleAddTrace() {
      const { trace, error } = prepareTrace(pastedJson.value)

      if (error) {
        pasteError.value = error
      } else if (trace) {
        // update store & local storage
        localStorage.setItem(getLocalTraceItemName(window.location.href), JSON.stringify(trace))
        tracesStore.localTrace = trace

        // reset UI elements
        pastedJson.value = ''
        pasteError.value = ''
        showPasteArea.value = false

        // trigger actions
        selectTrace(trace?.id)
        WT1iser.addTrace()
      }
    }

    function removeLocalTrace() {
      removeTraceFromLS()

      tracesStore.selectedTraceId = null
      tracesStore.localTrace = null
    }

    async function selectTrace(traceId: string) {
      const selectedTrace = tracesStore.traces.find((trace) => trace.id == traceId)

      if (selectedTrace && !selectedTrace.parentNode) {
        tracesStore.isLoadingTrace = true
        tracesStore.updateDatasetTrace(await API.getTrace(traceId))
      }

      tracesStore.isLoadingTrace = false
      tracesStore.selectedTraceId = traceId
    }

    return {
      tracesStore,
      handleReloadTraces,
      showPasteArea,
      pastedJson,
      pasteError,

      nameFilter,
      durationRange,
      durationBounds,
      dateFrom,
      dateTo,

      fromMenu,
      toMenu,
      fromDateModel,
      toDateModel,

      filteredTraces,
      displayItems,
      hasDatasetTraces,
      isDateFilterActive,
      isDurationFilterActive,

      handlePasteNewTrace,
      handleCancelPaste,
      handleAddTrace,
      removeLocalTrace,
      selectTrace,
      openFromCalendar,
      openToCalendar,
      onFromDateSelected,
      onToDateSelected,
      onDateFilterChipClose,
      resetDateFilter,
      onDurationFilterChipClose,
      resetDurationFilter,

      formatTraceDateTime,
      WT1iser
    }
  }
}
</script>

<style lang="scss" scoped>
.paste-error {
  color: #dc2626;
  background-color: #b91c1c44;
  line-height: 1em;
  margin-top: 8px;
  padding: 6px 8px;
  border-radius: 4px;
}

.traces-list-container {
  display: flex;
  flex-direction: column;
  background-color: #fff;
  padding: 1px;
  height: 100%;
}

.filters-section {
  border-bottom: 1px solid #ddd;
  padding: 8px;
  margin-bottom: 4px;

  .filters-row {
    flex-wrap: wrap;
  }

  .filter-label {
    font-size: 13px;
    margin-right: 4px;
    color: #555;
  }

  .duration-filter {
    display: flex;
    align-items: center;
    margin-right: 24px;
  }

  .duration-values {
    font-size: 12px;
    margin-left: 12px;
    min-width: 80px;
  }

  .date-filter {
    .date-input {
      width: 100px;
    }

    label {
      font-size: 12px;
      color: #555;
    }
  }

  .filter-chips {
    margin-top: 8px;

    .q-chip {
      font-size: 12px;
      cursor: pointer;
      background-color: #aaa !important;
      opacity: 0.9;

      &:hover {
        opacity: 1;
      }
    }
  }
}

.paste-trace-section {
  padding: 8px;
  margin-bottom: 4px;

  .paste-trace-instructions {
    font-size: 12px;
    color: #666;
  }

  .paste-json-textarea {
    width: 100%;
    height: 70px;
    overflow-y: auto;
  }
}

.local-trace-card {
  background: #ffffff;
  border-radius: 4px;
  margin: 4px 8px 20px;
  padding: 8px;
  position: relative;
  cursor: pointer;

  &.selected {
    background-color: #d6e1fe !important;
    box-shadow: 0 0 6px rgba(33, 74, 181, 0.3) !important;
    font-weight: 500;
  }

  .close-btn {
    position: absolute;
    right: 8px;
    top: 8px;
    font-size: 16px;
    color: #666;
    cursor: pointer;
    user-select: none;
  }

  .trace-title-local {
    font-size: 14px;
    font-weight: 600;
    color: #333e48;
  }

  .trace-meta-local {
    font-size: 12px;
    color: #666;
    margin-top: 4px;
    display: flex;
    align-items: center;

    .q-icon {
      margin-right: 4px;
    }
  }
}

.local-trace-card:hover {
  background-color: #d6e1fe;
  font-weight: 500;
}

.loading-container {
  margin: 20px 0;
  display: flex;
  justify-content: center;
  align-items: center;
}

.traces-scroll-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding-bottom: 40px;
}

.no-traces-msg {
  text-align: center;
  padding: 20px;
  color: #999;
  font-size: 14px;
}

.flat-list {
  border: none !important;
  background: transparent !important;
  padding: 0 !important;
}

.group-header {
  font-weight: 600;
  font-size: 14px;
  color: #333e48;
  padding: 8px;
  background-color: #fff;
}

.trace-card {
  background-color: #ffffff;
  margin: 0;
  padding: 8px;
  transition:
    background-color 0.2s,
    color 0.2s;
}

.trace-card:hover {
  background-color: #2b66ff11;
  font-weight: 500;
}

.selected-item-active.trace-card {
  background-color: #d6e1fe !important;
  box-shadow: 0 0 6px rgba(33, 74, 181, 0.3) !important;
  font-weight: 500;
}

.trace-title {
  font-size: 14px;
  color: #333e48;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 180px;
}

.trace-meta {
  display: flex;
  align-items: center;
  font-size: 12px;
  color: #666;
  margin-top: 4px;

  .q-icon {
    margin-right: 4px;
  }
}

.trace-date-time,
.trace-duration {
  margin-left: 4px;
}

:deep(.q-notification--positive) {
  background-color: #d7f0d6 !important;
  color: #0b590b !important;
}

:deep(.q-notification--negative) {
  background-color: #d7f0d6 !important;
  color: #ce1228 !important;
}
</style>
