export interface TracesFilters {
  name: string
  duration: [number, number]
}
