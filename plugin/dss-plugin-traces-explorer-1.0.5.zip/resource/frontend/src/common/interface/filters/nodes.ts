export interface NodesFilters {
  name: string
  group: string | null
}
