import { Trace } from '@/common/interface/trace'

export interface TraceListResponse {
  status: string
  data: Trace[]
}
