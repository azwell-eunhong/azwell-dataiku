export interface ConfigResponse {
  title: string
}
