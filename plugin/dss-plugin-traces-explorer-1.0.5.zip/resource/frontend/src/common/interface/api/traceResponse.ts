import { Trace } from '@/common/interface/trace'

export interface TraceResponse {
  status: string
  data: Trace
}
