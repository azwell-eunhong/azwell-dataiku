export interface Trace {
  id: string
  parentNode?: TraceNode
  name?: string
  begin?: string
  duration?: number
  date?: Date
  overallTotalPromptTokens?: number
  overallTotalCompletionTokens?: number
  overallTotalTokens?: number
  overallEstimatedCost?: number
}

export interface TraceNode {
  id?: string
  traceName?: string
  type: string
  begin?: string
  end?: string
  date?: Date
  duration?: number
  name: string
  children: (TraceNode | TraceNodeEvent)[]
  attributes: SpanAttributes
  usageMetadata?: UsageMetadata
  inputs?: SpanInputsOutputs
  outputs?: SpanInputsOutputs
}

interface TraceNodeEvent {
  type: string
  timestamp: string
  name: string
  children: any[]
  attributes: Record<string, any>
}

export interface UsageMetadata {
  promptTokens: number
  completionTokens: number
  totalTokens: number
  estimatedCost: number
}

interface Message {
  role: string
  content?: string
  text?: string
}

interface CompletionQuery {
  messages: Message[]
}

interface CompletionQuerySettings {
  maxOutputTokens: number
  stopSequences: string[]
}

interface CompletionResponse {
  ok: boolean
  text: string
  finishReason: string
  toolCalls: any[]
  predictedClassProbas: any[]
  fromCache: boolean
  promptTokens?: number
  completionTokens?: number
  totalTokens?: number
  estimatedCost?: number
}

interface SpanAttributes {
  llmId?: string
  llmProvider?: string
  llmModel?: string
  completionQuery?: CompletionQuery
  completionQuerySettings?: CompletionQuerySettings
  completionResponse?: CompletionResponse
}

interface SpanInputsOutputs {
  messages?: Message[]
  text?: string
}
