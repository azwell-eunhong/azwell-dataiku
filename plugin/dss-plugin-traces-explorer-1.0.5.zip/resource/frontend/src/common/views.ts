export enum ViewMode {
  Tree = 'tree',
  Timeline = 'timeline',
  Explorer = 'explorer'
}
