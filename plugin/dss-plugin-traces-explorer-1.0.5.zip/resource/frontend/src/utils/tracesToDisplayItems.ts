import { Trace } from '@/common/interface/trace'

export function transformItemsForDisplay(traces: Trace[]): { type: string; label: string; item?: Trace }[] {
  if (!traces || traces.length === 0) {
    return []
  }

  const now = new Date()
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate())

  function daysAgo(d: Date) {
    const startOfDay = new Date(d.getFullYear(), d.getMonth(), d.getDate())
    const diff = startOfToday.getTime() - startOfDay.getTime()
    return Math.floor(diff / (1000 * 60 * 60 * 24))
  }

  const todayItems: Trace[] = []
  const prev7DaysItems: Trace[] = []
  const prev30DaysItems: Trace[] = []
  const monthMap: Record<string, Trace[]> = {}
  const yearMap: Record<number, Trace[]> = {}
  const monthNames = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ]

  for (const t of traces) {
    const dateBegin = t.date || new Date(t.begin || "") || new Date()
    const diffDays = daysAgo(dateBegin)

    if (diffDays === 0) {
      todayItems.push(t)
    } else if (diffDays <= 7) {
      prev7DaysItems.push(t)
    } else if (diffDays <= 30) {
      prev30DaysItems.push(t)
    } else {
      // older
      if (dateBegin.getFullYear() === now.getFullYear()) {
        const mLabel = monthNames[dateBegin.getMonth() || 0]
        if (!monthMap[mLabel]) {
          monthMap[mLabel] = []
        }
        monthMap[mLabel].push(t)
      } else {
        const y = dateBegin.getFullYear() || 0
        if (!yearMap[y]) {
          yearMap[y] = []
        }
        yearMap[y].push(t)
      }
    }
  }

  const result = []
  if (todayItems.length > 0) {
    result.push({ type: 'group', label: 'Today' })
    todayItems.forEach((i) => result.push({ type: 'item', item: i }))
  }
  if (prev7DaysItems.length > 0) {
    result.push({ type: 'group', label: 'Previous 7 Days' })
    prev7DaysItems.forEach((i) => result.push({ type: 'item', item: i }))
  }
  if (prev30DaysItems.length > 0) {
    result.push({ type: 'group', label: 'Previous 30 Days' })
    prev30DaysItems.forEach((i) => result.push({ type: 'item', item: i }))
  }

  const currentYearMonths = Object.keys(monthMap)
  if (currentYearMonths.length > 0) {
    const monthsWithOrder = currentYearMonths
      .map((m) => ({ label: m, index: monthNames.indexOf(m) }))
      .sort((a, b) => b.index - a.index)
    for (const m of monthsWithOrder) {
      result.push({ type: 'group', label: m.label })
      monthMap[m.label].forEach((i) => result.push({ type: 'item', item: i }))
    }
  }

  const years = Object.keys(yearMap)
    .map((y) => parseInt(y, 10))
    .sort((a, b) => b - a)
  for (const y of years) {
    result.push({ type: 'group', label: y.toString() })
    yearMap[y].forEach((i) => result.push({ type: 'item', item: i }))
  }

  return result
}
