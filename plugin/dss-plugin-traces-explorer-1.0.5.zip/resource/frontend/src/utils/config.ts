export const EXPLORE_TRACE_STORAGE_KEY = 'ls.llm.traceExplorer.trace'
export const LOCAL_TRACE_STORAGE_KEY = 'LOCAL_PASTED_TRACE_'
export const URL_EXPLORE_TRACE_PARAM_KEY = 'readTraceFromLS'
