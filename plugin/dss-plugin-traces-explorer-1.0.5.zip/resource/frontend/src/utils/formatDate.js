import { computed } from 'vue'

export function formatTraceDateTime(date) {
  return new Date(date).toLocaleString()
}

export function formatNodeTime(dateString) {
  return computed(() => {
    if (!dateString) return null
    const date = new Date(dateString)
    if (isNaN(date)) return null

    const timeFormatter = new Intl.DateTimeFormat('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    })

    const formattedTime = timeFormatter.format(date)

    const milliseconds = date.getMilliseconds().toString().padStart(3, '0')

    return `${formattedTime}.${milliseconds}`
  })
}

export function parseMDY(str) {
  if (!str || !/^\d{2}\/\d{2}\/\d{4}$/.test(str)) {
    return null
  }
  const [mm, dd, yyyy] = str.split('/')
  const d = new Date(+yyyy, +mm - 1, +dd)
  return isNaN(d.getTime()) ? null : d
}

export function smallDateFromISO(inputDate) {
  const date = new Date(inputDate);

  const month = date.getMonth() + 1;
  const day = date.getDate();
  const year = date.getFullYear();

  const formattedMonth = month < 10 ? `0${month}` : `${month}`;
  const formattedDay = day < 10 ? `0${day}` : `${day}`;

  return `${formattedMonth}/${formattedDay}/${year}`;
}