import { NodesFilters } from '@/common/interface/filters/nodes'
import { Trace, TraceNode } from '@/common/interface/trace'
import { classifyNodeGroup } from './classifyNodeGroup'

export function matchNode(node: TraceNode, filters: NodesFilters): boolean {
  const { name, group } = filters

  let nameOk = true
  if (name) {
    const nodeName = ((node as Trace).name || '').toLowerCase()
    if (!nodeName.includes(name.toLowerCase())) {
      nameOk = false
    }
  }

  let groupOk = true
  if (group) {
    const nodeGrp = classifyNodeGroup(node)
    if (nodeGrp !== group) {
      groupOk = false
    }
  }

  if (!nameOk || !groupOk) {
    if (node.children && node.children.length > 0) {
      return node.children.some((child) => matchNode(child, filters))
    }
    return false
  }

  return true
}

export function filterTraceNode(node: TraceNode, filters: NodesFilters): TraceNode | undefined {
  if (!matchNode(node, filters)) return undefined

  const filteredChildren = node.children
    .map((child) => filterTraceNode(child, filters))
    .filter((c): c is TraceNode => c !== undefined) as TraceNode[]

  return {
    ...node,
    children: filteredChildren
  }
}
