export function classifyNodeGroup(node) {
  const name = (node.name || '').toLowerCase()
  const type = (node.type || '').toLowerCase()
  if (name.includes('python_llm_call') || name.includes('dku_agent_call')) return 'agent'
  if (name.includes('enforcement')) return 'guard'
  if (type === 'event') return 'event'
  if (node.attributes && node.attributes.completionQuery) return 'llm'
  if (name.includes('dku_llm_mesh_embedding_query')) return 'llm'
  if (name.includes('dku_managed_tool_call')) return 'tool'
  return 'span'
}
