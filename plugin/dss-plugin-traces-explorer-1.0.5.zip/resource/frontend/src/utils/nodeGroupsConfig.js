export const GROUPS_CONFIG = {
  agent: { color: '#d66f9e', shape: 'diamond', label: 'Agent' },
  guard: { color: '#64afd0', shape: 'ellipse', label: 'Guard' },
  tool: { color: '#53c081', shape: 'ellipse', label: 'Tool' },
  llm: { color: '#4285f4', shape: 'ellipse', label: 'LLM' },
  event: { color: '#ff832b', shape: 'ellipse', label: 'Event' },
  span: { color: '#bbb6b6', shape: 'ellipse', label: 'Span' }
}

export function getGroupColor(group) {
  return GROUPS_CONFIG[group]?.color || '#bbb6b6'
}

export function getGroupShape(group) {
  return GROUPS_CONFIG[group]?.shape || 'ellipse'
}

export function getGroupLabel(group) {
  return GROUPS_CONFIG[group]?.label || 'No Label'
}
