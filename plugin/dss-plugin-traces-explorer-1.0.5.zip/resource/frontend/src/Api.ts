import { AxiosError, AxiosResponse } from 'axios'

import axios from '@/api/index'
import { Trace } from '@/common/interface/trace'
import { TraceListResponse } from '@/common/interface/api/traceListResponse'
import { TraceResponse } from '@/common/interface/api/traceResponse'

// Shared request wrapper
async function request<T>(promise: Promise<AxiosResponse<T>>): Promise<T> {
  try {
    const response = await promise
    return response.data
  } catch (err) {
    const error = err as AxiosError
    // Extract error details
    const message = error.response?.data || error.message || 'Unknown error'
    const status = error.response?.status || 'unknown'
    throw new Error(`API error [${status}]: ${message}`)
  }
}

export const API = {
  // Force refresh list on backend side
  reloadTraces: async (): Promise<void> => {
    await request(axios.get('/api/traces/reload'))
  },

  // Retrieve the list of traces
  listTraces: async (): Promise<Trace[]> => {
    const response = await request<TraceListResponse>(
      axios.get<TraceListResponse>('/api/traces/list')
    )

    return response.data.sort(
      (a, b) => (b.begin || "") < (a.begin || "") ? -1 : 1
    )
  },

  // Retrieve the trace by its ID
  getTrace: async (traceId: string): Promise<Trace> => {
    const response = await request<TraceResponse>(
      axios.get<TraceResponse>(`/api/traces/get_trace/${traceId}`)
    )

    return response.data
  }
}
