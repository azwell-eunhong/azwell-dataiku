import {
  Quasar,
  Notify,
  ClosePopup,
  QIcon,
  QMenu,
  QList,
  QItemSection,
  QItem,
  QCardSection,
} from "quasar";
import "@quasar/extras/material-icons/material-icons.css";
import "@quasar/extras/material-icons-outlined/material-icons-outlined.css";
import "@quasar/extras/material-icons-round/material-icons-round.css";
import "@quasar/extras/mdi-v6/mdi-v6.css";
import "quasar/src/css/index.sass";
import "quasar-ui-bs/dist/quasar-ui-bs.css";
import "tabulator-tables/dist/css/tabulator.min.css";
import "tabulator-tables/dist/css/tabulator_simple.min.css";
import "vite/modulepreload-polyfill";
import "./fonts/fonts.scss";
import { QuasarBs } from "quasar-ui-bs";
import { myApp } from "./src/index";
import { ServerApi } from "quasar-ui-bs";
import { baseURL } from "./src/api/index";

ServerApi.init(baseURL);
/* @ts-expect-error */
myApp.config.unwrapInjectedRef = true;

myApp.use(Quasar, {
  plugins: {
    Notify,
  },
  components: {
    QIcon,
    QMenu,
    QList,
    QItemSection,
    QItem,
    QCardSection,
  },
  directives: {
    ClosePopup,
  },
});

myApp.use(QuasarBs);

myApp.mount("#app");

myApp.config.warnHandler = (msg, vm, trace) => {
  console.error(`[Vue warn]: ${msg}\nTrace: ${trace}`);
};
