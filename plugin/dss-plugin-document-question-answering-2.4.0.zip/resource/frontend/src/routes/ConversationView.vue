<template>
  <div class="relative flex flex-col overflow-hidden w-full" style="height: calc(100vh - 52px);">
    <div class="relative h-full w-full flex-1 overflow-auto conv-body">
      <div class="relative flex flex-col h-full">
        <div
          class="relative flex-1 h-full overflow-hidden"
          :class="{ loading: loadingQuestion }"
        >
          <div
            class="h-full w-full overflow-y-auto"
            ref="scrollArea"
            id="conv-scroll-area"
            @scroll="debouncedScrollHanlder"
          >
            <div class="w-full overflow-hidden max-w-[800px] mx-auto">
              <div v-if="summaries && summaries.length > 0">
                <SummaryCarousel :summaries="summaries" :useQuestion="useQuestion" id-prefix="conv" />
              </div>
              <div
                v-for="(item, index) in currentConversation?.data"
                :key="item.id"
                class="flex flex-col history w-full overflow-hidden"
              >
                <QuestionCard
                  :query="item.query"
                  :letter-icon="userNameFirstLetter"
                  v-if="item.query"
                >
                  <div class="file-preview-container">
                    <div v-for="(doc, prevIdx) in item.uploaded_docs" :key="prevIdx">
                      <FilePreview
                        v-if="doc.preview"
                        :uploaded-image="doc.preview"
                        :height="'70%'"
                        :width="'100%'"
                        style="margin-top: 4px"
                        class="media-preview"
                      ></FilePreview>
                      <div v-else class="flex justify-center items-center file-icon-wrapper">
                        <div :name="doc.is_deleted ? FileRemove : TextFileIconName" class="media-preview"></div>
                        <div class="bs-font-medium-1-semi-bold">{{ doc.original_file_name }}</div>
                      </div>
                    </div>
                  </div>
                  <FiltersContainer :filters="item.filters" v-if="item.filters && !isEmpty(item.filters)" />
                </QuestionCard>
                <SummaryCarousel
                  :summaries="item.uploaded_docs"
                  :useQuestion="useQuestion"
                  :id-prefix="`item-${index}`"
                  v-else-if="item.uploaded_docs"
                ></SummaryCarousel>
                <AnswerCard
                  :id="`answer-card-${index}`"
                  v-if="item.query && item.query !== ''"
                  :answer="extractAnswer(item, index)"
                  :feedback="item.feedback"
                  :feedback-options-negative="setup.feedbackNegativeChoices ?? []"
                  :feedback-options-positive="setup.feedbackPositiveChoices ?? []"
                  :kb-on="item.kbOn"
                  :db-on="item.dbOn"
                  @update:feedback="(value) => logFeedback(item.id, item, value)"
                  :typing-effect-on="false"
                  :error-state="errorState"
                  :loading="loadingQuestion && index === currentConversation!.data.length - 1"
                  :query-index="index"
                  :step="item.step || 'loading'"
                  :images="item.generated_images"
                  @expand-source="(value) => (expandSource = value)"
                >
                  <SourcesContainer
                    :id="`query_${index}_sources`"
                    class="self-start"
                    :aggregated-tool-sources="item.sources"
                    :query-index="index"
                    :project-key="setup.projectKey"
                    :folder-id="setup.docsFolderId"
                    :expandSource="expandSource"
                    v-if="item.sources && item.sources.length > 0"
                    @update:expanded="(value) => handleSourceExpanded(index, value)"
                  />
                </AnswerCard>
              </div>
            </div>
          </div>
          <Button
            class="absolute bottom-[2%] left-1/2 -translate-x-1/2 rounded-full w-10 h-10 bg-white"
            variant="outline"
            v-if="isScrollArrowVisible"
            @click="debouncedScrollToBottom"
          >
            <ArrowDownIcon />
          </Button>
        </div>
        <div class="w-full conv-container conv-footer px-3">
          <div class="flex">
            <RetrievalToggle
              v-if="retriever"
              v-model:model-value="useRetriever"
              :retrieval-type="retrievalMode"
              :label="retriever?.alias ?? ''"
            ></RetrievalToggle>
            <UploadedFilesPreview
              class="ml-2"
              :files="uploadedFiles"
              @delete="deleteFile"
            ></UploadedFilesPreview>
          </div>
          <UserInput
            ref="userInputAreaRef"
            id="user-query-container"
            class="w-full"
            :class="{'bg-[#F2F2F2]':loadingQuestion}"
            :input-placeholder="inputPlaceholder"
            :value="currentData.query"
            :loading="loadingQuestion"
            :upload-file-types="uploadFileTypes"
            :streaming-enabled="streamingEnabled"
            :disable-file-upload="disableFileUpload"
            :isMediaConversation="isMediaConv"
            :uploadedFiles="uploadedFiles"
            @send:value="submitQuery"
            @enterkey:value="submitQuery"
            @stop="stopQuery"
            @update:value="
              (value) => {
                currentData.query = value
              }
            "
          />
          <DisclaimerSection />
          <div
            class="w-full flex btn-solutions-footer-container"
            v-if="allowGeneralFeedback && isSmallScreen"
          >
            <GeneralFeedback></GeneralFeedback>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { toRefs, computed, ref, onMounted, onBeforeUnmount } from 'vue'
import { useConversation } from '@/components/composables/use-conversation'
import QuestionCard from '@/components/QuestionCard.vue'
import AnswerCard from '@/components/AnswerCard.vue'
import SourcesContainer from '@/components/SourcesContainer.vue'
import { useUI } from '@/components/composables/use-ui'
import { useI18n } from 'vue-i18n'
import UserInput from '@/components/UserInput.vue'
import { watch } from 'vue'
import FiltersContainer from '@/components/FiltersContainer.vue'
import FilePreview from '@/components/FilePreview.vue'
import DisclaimerSection from '@/components/DisclaimerSection.vue'
import { debounce } from 'lodash'
import GeneralFeedback from '@/components/GeneralFeedback.vue'
import RetrievalToggle from '@/components/RetrievalToggle.vue'
import { useRetrievalToggle } from '@/components/composables/use-retrieval-toggle'
import SummaryCarousel from '@/components/SummaryCarousel.vue'
import { ConversationType, type MediaSummary } from '@/models'
import TextFileIcon from '@/assets/icons/text-file-icon.svg'
import FileRemoveIcon from '@/assets/icons/file-remove-icon.svg'
import UploadedFilesPreview from '@/components/UploadedFilesPreview.vue'
import { isEmpty } from 'lodash'
import { Button } from '@/components/ui/button'
import ArrowDownIcon from '@/components/icons/ArrowDownIcon.vue'
const { t } = useI18n()

const TextFileIconName = `img:${TextFileIcon}`
const FileRemove = `img:${FileRemoveIcon}`

//TODO: make dynamic

const expandSource = ref({ sourceIndex: '', citationIndex: '', queryIndex: '' })
const props = defineProps<{
  id: string
}>()

const { id } = toRefs(props)
const {
  currentData,
  currentConversation,
  errorState,
  loadingQuestion,
  sendQuestion,
  stopQuery,
  logFeedback,
  deleteFile
} = useConversation(id)

const { setup } = useUI()
const { retriever, useRetriever, retrievalMode } = useRetrievalToggle()
const isMediaConv = computed(
  () => currentConversation.value?.conversation_type === ConversationType.MEDIA_QA
)
const summaries = computed(() => {
  return currentConversation.value?.media_summaries
})
const allowGeneralFeedback = computed(() => {
  return setup.value.allowGeneralFeedback
})

const streamingEnabled = computed(() => {
  return setup.value?.llmCapabilities?.streaming
})
const disableFileUpload = computed(() => {
  return (
    !setup.value.uploadFileTypes?.length ||
    uploadedFiles.value.length >= (setup.value.maxNUploadFiles ?? 5)
  )
})

const uploadedFiles = ref<MediaSummary[]>([])
watch(
  () => currentConversation,
  () => {
    if (currentConversation.value == null) {
      uploadedFiles.value = []
    } else {
      uploadedFiles.value = [
        ...(currentConversation.value.media_summaries?.filter(summary => !summary.is_deleted) ?? []),
        ...currentConversation.value.data.flatMap((data) => data.uploaded_docs?.filter(doc => !doc.is_deleted) || [])
      ]
    }
  },
  { immediate: true, deep: true }
)

const userNameFirstLetter = computed(() => {
  return setup.value?.user?.length ? setup.value?.user[0].toLocaleUpperCase() : '?'
})

const uploadFileTypes = computed(() => {
  return setup.value.uploadFileTypes
})

const extractAnswer = (item: any, index: number) => {
  if (currentConversation.value) {
    return item.answer
      ? item.answer
      : index < currentConversation.value.data.length - 1 && !item.generated_images
      ? t('error_message')
      : ''
  }
  return ''
}
const scrollArea = ref<HTMLElement>()
const isScrollArrowVisible = ref(false)

const scrollToBottom = () => {
  if (scrollArea.value) {
    scrollArea.value.scrollTo({
      top: scrollArea.value.scrollHeight,
      behavior: 'smooth'
    })
  }
}
const scrollHandler = () => {
  if (scrollArea.value) {
    isScrollArrowVisible.value =
      scrollArea.value.scrollTop + scrollArea.value.clientHeight + 5 < scrollArea.value.scrollHeight
  }
}
const debouncedScrollToBottom = debounce(scrollToBottom, 200)
const debouncedScrollHanlder = debounce(scrollHandler, 50)
watch(id, debouncedScrollToBottom)

function handleSourceExpanded(index: number, newVal: string) {
  if (
    newVal &&
    currentConversation.value?.data.length &&
    index === currentConversation.value.data.length - 1
  ) {
    debouncedScrollToBottom()
  }
}

const inputPlaceholder = computed(() => {
  return setup.value.questionPlaceholder || t('questionPlaceholder')
})

const submitQuery = (formData?: FormData) => {
  debouncedScrollToBottom()
  sendQuestion(formData)
}
const useQuestion = (question: string) => {
  if (!loadingQuestion.value) {
    currentData.value.query = question
    submitQuery()
  }
}

let resizeObserver: ResizeObserver | undefined
let mutationObserver: MutationObserver | undefined
let windowResizeObserver: ResizeObserver | undefined

const isSmallScreen = ref(false)
const checkSmallScreen = () => {
  isSmallScreen.value = useUI().isSmallScreen()
}
onBeforeUnmount(() => {
  if (resizeObserver) {
    resizeObserver.disconnect()
  }
  if (mutationObserver) {
    mutationObserver.disconnect()
  }
  if (windowResizeObserver) {
    windowResizeObserver.disconnect()
  }
})
onMounted(() => {
  debouncedScrollToBottom()
  checkSmallScreen()

  if (scrollArea.value) {
    resizeObserver = new ResizeObserver(debouncedScrollHanlder)
    resizeObserver.observe(scrollArea.value)
    // debouncedScrollHanlder(); // initial check
    // Use MutationObserver to detect changes in the DOM
    mutationObserver = new MutationObserver(debouncedScrollHanlder)
    mutationObserver.observe(scrollArea.value, {
      childList: true,
      subtree: true,
      attributes: true
    })
  }
  windowResizeObserver = new ResizeObserver(() => {
    checkSmallScreen()
  })
  windowResizeObserver.observe(document.body)
})
</script>

<style lang="scss" scoped>
.conv-container {
  position: relative;
  max-width: 800px;
  align-self: center;
}
.conv-footer {
  margin-top: 5px;
  flex-shrink: 0;
}

.history {
  gap: 16px;
  margin-bottom: 16px;
}

.history:first-child {
  padding-top: 0px !important;
}

.history:first-child {
  border-top: none;
}

.clear-history-btn {
  margin-left: auto;
  margin-right: 10px;
  display: inline-flex;
  align-self: flex-start;
}

.btn-solutions-footer-container {
  justify-content: flex-end;
  padding-right: 8px; /*to align with the right edge of the disclaimer*/
}
.file-preview-container {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  justify-content: flex-start;
}
.media-preview {
  max-width: 100px;
  max-height: 130px;
  width: 100%;
  height: auto;
  object-fit: contain;
}
.file-icon-wrapper {
  background-color: white;
  border-radius: 4px;
}
</style>
