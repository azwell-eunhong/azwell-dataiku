<template>
  <link
    :href="`${CUSTOMIZATION_PATH}/${setup.customThemeName}/custom.css`"
    rel="stylesheet"
    id="customCss"
    v-if="setup && setup.projectKey && setup.useCustomRebranding"
  />
  <link
    :href="`${CUSTOMIZATION_PATH}/${setup.customThemeName}/fonts/fonts.css`"
    rel="stylesheet"
    id="customFonts"
    v-if="setup && setup.projectKey && setup.useCustomRebranding"
  />
  <ToastProvider>
    <SidebarProvider
      v-model:open="isSidebarOpen"
      v-model:openMobile="isSidebarOpenMobile"
      ref="sidebar"
    >
      <Sidebar>
        <SidebarHeader class="bg-white pb-0">
          <SidebarMenu>
            <SidebarMenuItem>
              <div class="flex flex-col justify-between w-full">
                <div class="flex items-center justify-between px-2">
                  <SidebarGroupLabel class="text-md text-black px-0">
                    {{ t('all_conversations') }}
                  </SidebarGroupLabel>
                  <SidebarTrigger class="scale-150" id="left-sidebar-toggle" />
                </div>
                <div class="px-2 flex row" style="justify-content: space-between">
                  <Button
                    id="new-conversation-btn"
                    variant="ghost"
                    @click="newConversation"
                    no-caps
                    class="bs-font-medium-3-normal pl-0 mb-1 text-[var(--q-primary)] hover:text-[var(--q-primary)]"
                  >
                    <div size="18px">
                      <AddSquareIcon></AddSquareIcon>
                    </div>
                    {{ t('new_chat') }}
                  </Button>
                  <Button
                    id="delete-all-conversations-btn"
                    variant="ghost"
                    @click="deleteAllOpen = true"
                    class="bs-font-medium-3-normal px-0 mb-1 text-[var(--q-primary)] hover:text-[var(--q-primary)]"
                    v-if="conversations.length"
                  >
                    <div
                      class="pl-2"
                      size="18px"
                      style="cursor: pointer"
                      @click="deleteAllOpen = true"
                    >
                      <TrashIcon />
                    </div>
                    {{ t('delete_all_conv_title') }}
                    <DeleteDialog
                      :open="deleteAllOpen"
                      :title="t('delete_all_conv_title')"
                      @update:open="deleteAllOpen = $event"
                      :text="t('delete_all_conv_warning')"
                      @cancel="deleteAllOpen = false"
                      @confirm="deleteAllItems"
                    >
                      {{ t('delete_all_conv_message') }}
                    </DeleteDialog>
                  </Button>
                </div>
              </div>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarHeader>
        <SidebarContent>
          <SidebarGroup class="px-0 pt-0">
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <div class="pb-2" style="overflow-x: hidden" id="conversations-list">
                    <div
                      class="column no-wrap justify-center align-center"
                      v-if="!loadingConversations && !errorConversations"
                    >
                      <ConversationCard
                        v-for="(item, index) in conversations"
                        :title="item.name"
                        :date="item.timestamp"
                        :id="item.id"
                        :is-selected="isSelected(item.id, item.selected)"
                        @delete:conv="(id) => deleteItem(id)"
                        @click="navigateToConv(item.id)"
                        v-bind:key="index"
                      />
                    </div>
                    <div v-else-if="errorConversations">
                      <div>ERROR</div>
                    </div>
                    <div v-else>
                      <!-- TODO: Replace spinner -->
                      <!-- <q-spinner color="primary" size="3em"></q-spinner> -->
                      <div color="primary" size="3em">Loading...</div>
                    </div>
                  </div>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
      </Sidebar>
      <main class="w-full h-screen">
        <SidebarHeader class="flex flex-row justify-between">
          <SidebarTrigger
            class="scale-150"
            v-if="!isSidebarActuallyOpen"
            id="center-sidebar-toggle"
          />
          <div v-else></div>
          <div class="flex">
            <GeneralFeedback v-if="allowGeneralFeedback && !isSmallScreen" />
            <SettingsDialog
              class="bs-font-medium-3-normal mx-2 settings-btn"
              id="settings-dialog-btn"
            />
          </div>
        </SidebarHeader>
        <RouterView />
        <slot />
      </main>
    </SidebarProvider>
    <ToastViewport class="fixed top-0 right-0 p-4 flex flex-col gap-2" />
  </ToastProvider>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { useUI } from '@/components/composables/use-ui'
import { useConversations } from '@/components/composables/use-conversations'
import { useConversation } from '@/components/composables/use-conversation'
import { useRouter } from 'vue-router'
import DeleteDialog from '@/components/DeleteDialog.vue'
import TrashIcon from '@/components/icons/TrashIcon.vue'
import AddSquareIcon from '@/components/icons/AddSquareIcon.vue'
import ConversationCard from '@/components/ConversationCard.vue'
import { computed, onMounted, onUnmounted, ref } from 'vue' // Updated import
import { watch } from 'vue'
import { useSettings } from '@/components/composables/use-settings'
import { WT1iser } from '@/common/wt1'
import { CUSTOMIZATION_PATH } from '@/common/constants'
import Button from '@/components/ui/button/Button.vue'
import { ToastProvider, ToastViewport } from '@/components/ui/toast'
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuItem,
  SidebarTrigger
} from '@/components/ui/sidebar'
import { RetrievalMode } from '@/models'
import SidebarProvider from '@/components/ui/sidebar/SidebarProvider.vue'
import SidebarHeader from '@/components/ui/sidebar/SidebarHeader.vue'
import SettingsDialog from '@/components/SettingsDialog.vue'
import GeneralFeedback from '@/components/GeneralFeedback.vue'
import { useLoading } from '@/components/composables/use-loading'

const isSidebarOpen = ref(useUI().isSmallScreen() ? false : true)
const isSidebarOpenMobile = ref(false)
const isSidebarActuallyOpen = computed(() => {
  return isSmallScreen.value ? isSidebarOpenMobile.value : isSidebarOpen.value
})

const { showLoading, hideLoading } = useLoading()

const router = useRouter()
const id = ref<string | null>(null)

const { reset, loadingQuestion } = useConversation(id)

const { setup, initializeUI } = useUI()
const { t } = useI18n()
const sidebar = ref<typeof SidebarProvider>()

function isSelected(itemId: string, isSelected?: boolean) {
  const route = useRoute()
  const converationId = route.params.id
  return itemId === converationId || isSelected === true
}

const isEmptyState = ref<boolean>(false)
watch(useRoute(), (to) => {
  isEmptyState.value = to.path === '/new'
})

const deleteAllOpen = ref<boolean>(false)

const {
  conversations,
  loading: loadingConversations,
  error: errorConversations,
  deleteConversation,
  deleteAllConversations,
  getUserConversations
} = useConversations()

let openEventSent = false

watch(
  setup,
  () => {
    const llmId = setup.value?.llmId
    if (llmId && !openEventSent) {
      openEventSent = true
      WT1iser.init(llmId, setup.value?.imageGenerationLLMId)
      WT1iser.open()
    }
  },
  { deep: true }
)

async function newConversation() {
  WT1iser.newConversation()
  await reset()
  await router.push({ path: '/new' })
  if (useUI().isSmallScreen()) {
    sidebar.value?.toggleSidebar()
  }
}

async function deleteItem(id: string) {
  WT1iser.deleteConversation()
  await deleteConversation(id)
  await router.push({ path: '/new' })
  await reset()
}

async function deleteAllItems() {
  WT1iser.deleteAllConversations()
  await deleteAllConversations()
  await router.push({ path: '/new' })
  await reset()
  deleteAllOpen.value = false
}

async function navigateToConv(id: string) {
  if (loadingQuestion.value) {
    return
  }
  if (useUI().isSmallScreen()) {
    sidebar.value?.toggleSidebar()
  }
  router.push({ path: `/conversation/${id}` })
}

const allowGeneralFeedback = computed(() => {
  return setup.value.allowGeneralFeedback &&  !isEmptyState.value
})

const isSmallScreen = ref(false)
const checkSmallScreen = () => {
  isSmallScreen.value = useUI().isSmallScreen()
}

onMounted(async () => {
  showLoading('Loading data...')
  await initializeUI()
  await getUserConversations()
  checkSmallScreen() // Initial check
  window.addEventListener('resize', checkSmallScreen) // Add resize listener
  hideLoading()
  // Needed to update local storage settings when knowledge bank has changed
  if (setup.value.retriever) {
    if (setup.value.retrievalMode === RetrievalMode.DB) {
      useSettings().updateDbSettings(setup.value.retriever)
    } else if (setup.value.retrievalMode === RetrievalMode.KB) {
      useSettings().updateKbSettings(setup.value.retriever, setup.value.filtersConfig)
    }
  } else {
    useSettings().retrieverSelected.value = false
  }
  useSettings().userSettings.value = JSON.parse(JSON.stringify(setup.value.currentUserProfile))
  isEmptyState.value = router.currentRoute.value.path === '/new'
})

onUnmounted(() => {
  window.removeEventListener('resize', checkSmallScreen) // Remove resize listener
})
</script>
<style lang="scss">
.q-scrollarea__content {
  max-width: 100% !important;
}

.toggle-left-button {
  visibility: hidden !important;
}

.all-title {
  color: #333e48;
}

.black-text {
  color: #000;
}

.material-symbols-outlined {
  font-variation-settings: 'FILL' 0, 'wght' 200, 'GRAD' 0, 'opsz' 24;
}

.active {
  background-color: #66666615;
}

body,
div {
  font-family: 'SourceSansPro';
}

body {
  font-size: 16px;
}

/* Desktop styles */
h1,
h2,
h3,
h4,
h5,
h6 {
  font-weight: bold;
}

h1 {
  font-size: 2.125rem;
  /* 34px */
  line-height: 1;
  /* 34px */
  letter-spacing: -0.0625rem;
  /* -1px */
}

h2 {
  font-size: 1.875rem;
  /* 30px */
  line-height: 1.067;
  /* 32px */
  letter-spacing: -0.05rem;
  /* -0.8px */
}

h3 {
  font-size: 1.5rem;
  /* 24px */
  line-height: 1.083;
  /* 26px */
  letter-spacing: -0.0375rem;
  /* -0.5px */
}

h4 {
  font-size: 1.25rem;
  /* 20px */
  line-height: 1.1;
  /* 22px */
  letter-spacing: -0.025rem;
  /* -0.4px */
}

h5 {
  font-size: 1.125rem;
  /* 18px */
  line-height: 1.111;
  /* 20px */
  letter-spacing: -0.0125rem;
  /* -0.2px */
}

h6 {
  font-size: 1rem;
  /* 16px */
  line-height: 1.125;
  /* 18px */
  letter-spacing: -0.00625rem;
  /* -0.1px */
}

input {
  font-size: inherit;
}

:root {
  /* Colors */
  --brand: #2ab1ad;
  /*Primary color for elements other than action buttons*/
  --bg-examples-brand: #fff;
  /*Examples (visibile on landing page/new chat) background color*/
  --bg-examples-brand-hover: rgba(230, 247, 246, 0.31);
  /*Examples background color on hover*/
  --bg-examples-borders: #b3e8e5;
  /*Examples border color*/
  --examples-question-marks: rgb(1, 178, 170);
  /*Colors of question marks in the examples*/
  --examples-text: black;
  /*Color of the text in the examples*/
  --text-brand: #444;
  /*Text color for the question card*/
  --bg-query: rgba(245, 245, 245, 0.7);
  /*Background color for the question card*/
  --bg-query-avatar: #f28c37;
  /*Background color for the question card avatar*/
  /* Primary color used for action buttons -- using same name as quasar to keep backward compatibility */
  --q-primary: #3B99FC;
}

.bs-selected-items-section .bs-selected-item {
  min-width: 100px !important;
  font-size: 12px !important;
}

.bs-select__popup {
  width: auto !important;
  max-width: none !important;

  .q-item__label {
    padding-left: 1rem;
  }
}

.bs-select .q-field__native,
.bs-select__popup .q-item {
  font-size: inherit;
}

.q-item {
  padding-left: 0 !important;
}

.q-item__section--side {
  padding-right: 0 !important;
}

.q-item__section--avatar {
  min-width: 20px !important;
}

.disabled.filters-selectors {
  cursor: pointer;

  .q-field__inner {
    background: #f5f5f5;
  }
}

.bs-font-medium-2-normal {
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  line-height: 22px;
}

.bs-font-medium-1-normal {
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  line-height: 20px;
}

.bs-font-medium-2-semi-bold {
  font-size: 14px;
  font-style: normal;
  font-weight: 600;
  line-height: 22px;
  /* 157.143% */
}

.bs-font-medium-3-semi-bold {
  font-size: 16px;
  font-style: normal;
  font-weight: 600;
  line-height: 22px;
}

.bs-font-medium-4-normal {
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: 32px;
}

.bs-font-medium-4-semi-bold {
  color: #333e48;
  font-size: 20px;
  font-style: normal;
  font-weight: 600;
  line-height: 32px;
  /* 160% */
}

.bs-font-medium-3-normal {
  font-size: 16px;
  font-style: normal;
  font-weight: 400;
  line-height: 22px;
}

.bs-font-small-2-normal {
  font-size: 10px;
  font-style: normal;
  font-weight: 400;
  line-height: 18px;
}

.dds-caption-400 {
  font-family: SourceSansPro;
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  line-height: 15px;
}

.bs-alert-notification {
  border-radius: 4px;
  box-shadow: none;
}

.q-notification__icon--additional {
  margin-right: 8px;
}

.text-positive-alert {
  color: green !important;
}

.bg-positive-alert {
  background-color: #d7f0d6 !important;
}

.text-negative-alert {
  color: red !important;
}

.bg-negative-alert {
  background-color: #f9e3e5 !important;
}

.bs-font-medium-1-semi-bold {
  font-size: 12px;
  font-style: normal;
  font-weight: 600;
  line-height: 20px;
}

.content-wrapper {
  display: flex;
  flex-direction: column;
  height: 100%;
  max-height: 100%;
  width: 100%;
  max-width: 100%;
  justify-content: center;
  align-items: center;
  overflow-y: hidden;
  overflow-x: hidden;
}

.doc-question-answering-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  max-height: 100%;
}

.doc-question-answering-content,
.column.items-center {
  width: 100%;
  margin-top: 0px;
  padding: 12px;
}

.doc-question-answering-content,
.column.items-center.loading {
  padding-top: 15px;
}

.dku-medium-title {
  width: 100%;
  max-width: 100%;
}

.filters-autoFilter .q-pa-sm {
  padding: 0px;
  margin-left: -15px;
}

.filters-autoFilter {
  margin-top: 21px;
}

.q-field__control-container {
  align-items: center !important;
}

.q-field__native {
  padding: 0px !important;
}

.bs-toggle__content__active {
  background: var(--q-primary) !important;
}

.q-field--outlined {
  .q-field__control {
    &:before {
      border: none !important;
    }

    &:after {
      border: 1px solid #cccccc;
    }

    &:hover {
      &:before,
      &:after {
        border: 1px solid #999999;
      }
    }
  }

  &.q-field--highlighted {
    .q-field__control:after {
      border: 1px solid var(--brand);
    }
  }
}

.q-item {
  min-height: 20px;
  height: auto;
}

.disclaimer {
  width: 100%;
  padding: 20px;
  text-align: center;
}

.sticky-header {
  display: flex;
  align-self: flex-start;
  max-width: 100%;
  width: 100%;
  background-color: white;
  padding: 0px 8px;
  justify-content: flex-end;
  gap: 20px;
  margin-bottom: 10px;
}

.navigation-container {
  position: absolute;
  top: 20px;
  display: flex;
  align-items: center;
  gap: 4px;
  cursor: pointer;
}

.navigation-container span {
  font-style: normal;
  font-weight: 600;
  font-size: 13px;
  line-height: 20px;
  color: #666666;
}

.navigation-container .q-icon {
  margin-left: 5px;
}

.query-input {
  width: 100%;
}

.q-textarea.q-field--dense .q-field__control,
.q-textarea.q-field--dense .q-field__native {
  min-height: 28px !important;
  height: 28px;
  max-height: 300px;
}

@mixin common-small-screen-styles {
  .btn-solution {
    border: none !important;
    padding: 0px !important;
  }

  .q-btn--outline::before {
    border: none !important;
  }

  .disclaimer {
    padding: 8px;
  }

  #use-knowledge-bank-toggle .q-toggle__inner {
    font-size: 35px !important;
  }

  .use-kb-label {
    padding-top: 0.33em !important; //to align with toggle padding
  }

  h1 {
    font-size: 1.5rem;
    /* 24px */
  }

  h2 {
    font-size: 1.125rem;
    /* 18px */
  }

  h3 {
    font-size: 1.125rem;
    /* 18px */
  }
}

@media screen and (orientation: landscape) and (max-height: 600px) and (max-width: 1000px),
  (max-width: 600px) {
  /* Styles for phone screens */
  @include common-small-screen-styles;

  /* Adjusted width for smaller screens so that side bar takes all the screen */
  div.q-layout.q-layout--standard.bg-white {
    --bs-drawer-width: 100% !important;
  }

  .q-drawer.q-drawer--left.q-drawer--bordered.q-drawer--standard {
    width: 100% !important;
  }
}

.doc-footer__icon {
  padding-bottom: 6px !important;
  padding-top: 5px !important;
  border-bottom: 1px solid #f2f2f2;
}

.doc-footer__text {
  border-left: none !important;
  border-bottom: 1px solid #f2f2f2;
}

@media screen and (orientation: landscape) and (max-height: 600px) and (max-width: 1000px),
  (max-width: 767px) {
  /* Styles for phone screens */
  .doc-question-answering-content,
  .column.items-center {
    max-height: 100%;
    overflow-x: hidden;
  }

  .dku-medium-title {
    font-size: 16px;
  }

  .dku-grand-title-sb {
    font-size: 18px;
  }

  .doc-question-answering-content,
  .column.items-center {
    width: 100%;
  }

  .navigation-container {
    top: 16px;
  }

  .btn-solution-text {
    font-size: 10px !important;
  }
}

.flex-1 {
  flex: 1 1 0%;
}

.flex-auto {
  flex: 1 1 auto;
}

.relative {
  position: relative;
}

.flex-column {
  display: flex;
  flex-direction: column;
}

.flex-row {
  display: flex;
  flex-direction: row;
}

.overflow-y {
  overflow-y: auto;
  -webkit-overflow-scrolling: touch !important;
}

.show-on-mobile {
  display: none;
}

@media screen and (orientation: landscape) and (max-height: 500px) and (max-width: 1000px),
  (max-width: 767px) {
  /* Styles for phone screens */
  .hide-on-mobile {
    display: none;
  }

  .show-on-mobile {
    display: initial;
  }
}
</style>
