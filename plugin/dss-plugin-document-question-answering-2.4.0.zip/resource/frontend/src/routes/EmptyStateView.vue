<template>
  <div class="relative flex flex-col w-full" style="height: calc(100vh - 52px);">
    <div class="relative flex-1 overflow-y-scroll flex align-center">
      <div class="justify-center items-center max-w-[800px] px-3 mx-auto my-auto">
        <div class="space-y-4">
          <div class="logo-container" style="width: 100%; display: flex; justify-content: center">
            <img :src="logo" class="logo-img" @error="imgError = true" />
          </div>
          <div
            v-if="subtitle"
            v-html="subtitle"
            class="dku-medium-title"
            style="text-align: center; color: #666666"
          ></div>
        </div>
        <div>
          <div class="title_with_lines" v-if="setup.examples && setup.examples.length">
            {{ $t('examples') }}
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-x-2.5 gap-y-2 w-full mb-2">
            <InfoCard
              v-for="(text, index) in setup.examples"
              :text="text"
              style="cursor: pointer"
              @click="currentData.query = text"
              v-bind:key="index"
            />
          </div>
        </div>
      </div>
    </div>
    <div class="empty-state-footer w-full">
      <div class="max-w-[800px] mx-auto px-3">
        <RetrievalToggle
          v-if="retriever"
          v-model:model-value="useRetriever"
          :retrieval-type="retrievalMode"
          :label="retriever.alias"
          class="toggle"
        />
        <div class="grid drop-zone">
          <UserInput
            :input-placeholder="inputPlaceholder"
            :value="currentData.query"
            :loading="loadingQuestion"
            :upload-file-types="uploadFileTypes"
            :streaming-enabled="streamingEnabled"
            :disable-file-upload="disableFileUpload"
            :class="{'bg-[#F2F2F2]':loadingQuestion}"
            @send:value="sendQuestion"
            @enterkey:value="sendQuestion"
            @update:value="(value) => (currentData.query = value)"
            :isEmptyState="true"
          />
        </div>
        <DisclaimerSection />
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import InfoCard from '@/components/InfoCard.vue'
import logoWithBackground from '@/assets/icons/logo-with-background.svg'
import { useUI } from '@/components/composables/use-ui'
import { useConversation } from '@/components/composables/use-conversation'
import { toRefs, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import UserInput from '@/components/UserInput.vue'
import DisclaimerSection from '@/components/DisclaimerSection.vue'
import DOMPurify from 'dompurify'
import { ref } from 'vue'
import { getCustomImagePath } from '@/common/utils'
import RetrievalToggle from '@/components/RetrievalToggle.vue'
import { useRetrievalToggle } from '@/components/composables/use-retrieval-toggle'

const props = defineProps<{
  id: string | null
}>()

const { t } = useI18n()

const { id } = toRefs(props)
const { currentData, sendQuestion, loadingQuestion } = useConversation(id)

const { setup } = useUI()
defineEmits<{
  (e: 'example-clicked', text: string): void
}>()

const imgError = ref(false)
const logo = computed(() => {
  if (setup.value.useCustomRebranding) {
    const fileName = setup.value.customLogoFileName ? setup.value.customLogoFileName : ''
    return getCustomImagePath(
      fileName,
      logoWithBackground,
      setup.value.customThemeName,
      imgError.value
    )
  } else {
    return logoWithBackground
  }
})

const inputPlaceholder = computed(() => {
  return setup.value.questionPlaceholder || t('questionPlaceholder')
})

const streamingEnabled = computed(() => {
  return setup.value?.llmCapabilities?.streaming
})

const subtitle = computed(() => {
  return DOMPurify.sanitize(setup.value?.subtitle || '')
})
const disableFileUpload = computed(() => {
  return !setup.value.uploadFileTypes?.length
})
const { retriever, useRetriever, retrievalMode } = useRetrievalToggle()

const uploadFileTypes = computed(() => {
  return setup.value.uploadFileTypes
})
</script>

<style scoped lang="scss">
.title_with_lines {
  line-height: 20px;
  text-align: center;
  color: var(--brand);
  font-size: 13px;
  margin-bottom: 19px;
  margin-top: 36px;
}
.title_with_lines {
  display: inline-block;
  position: relative;
  width: 100%;
}
.title_with_lines:before,
.title_with_lines:after {
  content: '';
  position: absolute;
  overflow: hidden;
  height: 10px;
  border-bottom: 1px solid var(--brand);
  top: 0;
  width: calc(50% - 50px);
}
.title_with_lines:before {
  right: 50%;
  margin-right: 50px;
}
.title_with_lines:after {
  left: 50%;
  margin-left: 50px;
}
.empty-state {
  width: 100%;
  max-width: 100%;
  .kb-toggle {
    margin-top: 12px;
    margin-bottom: 4px;
  }
}

.drop-zone {
  position: relative;
}
.logo-container {
  margin-top: 0px;
}
.sticky-header {
  margin-bottom: 0px;
}
.examples-centered {
  align-content: center;
}
// Mixin for common styles for small screens */
@mixin common-styles {
  .empty-state {
    width: 100% !important;
  }
  .examples {
    grid-template-columns: 1fr;
    justify-content: space-between; /* Spread the items equally apart */
    justify-content: center;
    margin-left: 0px;
    max-width: 100%;
  }
  .info-card {
    max-width: 100%;
    margin-left: 0px;
  }
}
.space-y-4 {
  margin-top: 0px;
}
.logo-img {
  max-height: 120px;
  max-width: 100%;
}
@media screen and (orientation: landscape) and (max-height: 500px) and (max-width: 1000px),
  (max-width: 767px) {
  /* Styles for phone screens */
  @include common-styles;
  .logo-container {
    margin-top: 16px;
  }
  .examples-centered {
    align-content: flex-start;
  }
}

.dku-medium-title {
    font-weight: 400;
    font-size: 18px;
    line-height: 23px;
    color: #222;
}

.dku-medium-title ::v-deep ul {
  list-style-type: disc !important;
}

.dku-medium-title ::v-deep a {
  text-decoration: underline !important;
  color: "#0000EE" !important;
}

.dku-medium-title ::v-deep p {
  margin-bottom: 16px !important;
}
</style>
