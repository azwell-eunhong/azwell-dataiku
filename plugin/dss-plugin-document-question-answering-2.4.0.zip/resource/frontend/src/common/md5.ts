import md5 from 'blueimp-md5';

(window as any).md5 = md5;
