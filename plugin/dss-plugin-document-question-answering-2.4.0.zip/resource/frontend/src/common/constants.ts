
export const CUSTOMIZATION_PATH = `/local/static/answers`;
export const SUPPORTED_CUSTOM_IMAGES_EXTENSIONS = ['jpg', 'jpeg', 'png'];
