<template>
  <TooltipProvider :delay-duration="0">
    <div class="files">
      <Tooltip v-for="(file, index) in files" :key="index">
        <TooltipTrigger as-child>
          <Badge
            class="flex items-center bs-font-medium-3-normal bg-[#b3e8e5] hover:bg-[#b3e8e5] text-black file max-w-[120px] min-[400px]:max-w-[150px] min-[450px]:max-w-[200px]"
          >
            <div class="truncate">
              {{ file }}
            </div>
            <img
              id="delete-attached-file"
              :src="closeOutline"
              alt="Close"
              class="w-5 h-5 cursor-pointer"
              @click="closeTag(index)"
            />
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          {{ file }}
        </TooltipContent>
      </Tooltip>
    </div>
  </TooltipProvider>
</template>

<script setup lang="ts">
import Badge from './ui/badge/Badge.vue';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import closeOutline from '@/assets/icons/close-outline.svg'


defineProps<{
  files: string[]
}>()

const emits = defineEmits(['close'])
const closeTag = (index: number) => {
  emits('close', index)
}
</script>

<style lang="scss" scoped>
.files {
  display: flex;
  flex-wrap: wrap;
  padding: var(--bs-spacing-0, 0px);
  align-items: center;
  gap: var(--bs-spacing-1, 4px);
}

.file {
  padding: var(--bs-spacing-05, 2px) 8px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-height: 32px;
  cursor: pointer;
  transition: max-height 0.3s ease;
  align-items: center;
  gap: 10px;
}
</style>
