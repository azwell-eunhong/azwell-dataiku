<template>
  <div :style="imgStyle">
    <img
      :src="image"
      class="file-preview"
      :style="imgStyle"
      loading="lazy"
      @load="emits('loaded')"
      @click="showImage = true"
    />
    <Dialog v-model:open="showImage" v-if="downloadable">
      <DialogContent class="p-4 bg-white">
        <div class="flex items-center justify-between mb-2">
          <TooltipProvider :delay-duration="0">
            <Tooltip>
              <TooltipTrigger as-child>
                <Button name="download-icon" variant="ghost" @click="emits('download', image)" tabindex="-1">
                  <DownloadIcon class="h-5 w-5 cursor-pointer" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                {{ t('tooltip_download_image') }}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <img :src="image" name="generated image" alt="generated image" class="generated-image-preview" />
      </DialogContent>
    </Dialog>
    <Button
      v-if="removable"
      variant="ghost"
      class="absolute top-1 right-1 p-0"
      @click="emits('delete')"
    >
    </Button>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import { useI18n } from 'vue-i18n';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import DownloadIcon from './icons/DownloadIcon.vue';
import { ServerApi } from '@/api/server_api';
import { ResponseStatus } from '@/models';
import imagePlaceholder from '@/assets/images/placeholder-image.webp';
import { TooltipProvider, Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';

// Internationalization
const { t } = useI18n();

// Props and Emits
const props = defineProps<{
  uploadedImage?: string;
  height?: string;
  width?: string;
  removable?: boolean;
  downloadable?: boolean;
  filePath?: string;
  deleted?: boolean;
}>();
const emits = defineEmits(['loaded', 'delete', 'download', 'loaded-file']);

// Refs and Computed
const showImage = ref(false);
const imageSrc = ref(imagePlaceholder);
const image = computed(() => {
  return props.filePath ? imageSrc.value : props.uploadedImage;
});
const imgStyle = computed(() => ({
  maxHeight: props.height ?? '70px',
  maxWidth: props.width ?? '100px',
  cursor: props.downloadable ? 'pointer' : 'default',
  minHeight: props.height ?? '70px',
  minWidth: props.width ?? '100px',
}));

// Fetch Image on Mount
const fetchImage = async () => {
  if (props.filePath) {
    const response = await ServerApi.loadImage(props.filePath);
    if (response.status === ResponseStatus.OK) {
      imageSrc.value = response.data.file_data;
      emits('loaded-file', imageSrc.value);
    }
  }
};
onMounted(() => {
  fetchImage();
});
</script>

<style scoped>
.file-preview {
  display: inline;
}
.generated-image-preview {
  padding: 8px;
  padding-top: 0;
  width: 100%;
}
@media screen and (orientation: landscape) and (max-height: 600px) and (max-width: 1000px),
  (max-width: 600px) {
  .generated-image-preview {
    width: 100%;
  }
}
</style>
