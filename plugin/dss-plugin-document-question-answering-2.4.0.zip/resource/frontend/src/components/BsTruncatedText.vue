<template>
  <div class="bs-truncate-text">
    <slot></slot>
  </div>
</template>

<script lang="ts">

// TODO: Remove the tooltip logic

export default {
  name: 'BSTruncatedText',
  components: {
  },
  props: {
    tooltipContent: String
  },
  data() {
    return {
      isOverflowing: false
    }
  },
  mounted() {
    this.isOverflowing = this.checkOverflow()
  },
  methods: {
    showTooltip() {
      if (this.checkOverflow()) {
        this.isOverflowing = true
      } else {
        this.isOverflowing = false
      }
    },
    checkOverflow(): boolean {
      return (
        this.$el.offsetWidth < this.$el.scrollWidth || this.$el.offsetHeight < this.$el.scrollHeight
      )
    }
  }
}
</script>

<style scoped>
.bs-truncate-text {
  width: 100%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  position: relative;
}
</style>
