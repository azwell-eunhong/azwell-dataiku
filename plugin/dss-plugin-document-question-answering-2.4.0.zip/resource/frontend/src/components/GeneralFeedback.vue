<template>
  <FeedbackProxyPopup
    :feedback-value="feedbackValue"
    :feedback-options="[]"
    :submit-on-hide="false"
    @save="submitFeedback"
  >
    <Button
      variant="outline"
      class="bs-font-medium-3-normal btn-solution"
      id="feedback-btn-general"
    >
      <img size="18px" :src="dataikuIcon" style="margin-right: 2px" class="w-5 h-5 cursor-pointer"/>
      <span class="btn-solution-text">{{ $t('feedback_btn_general') }}</span>
    </Button>
  </FeedbackProxyPopup>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import FeedbackProxyPopup from './FeedbackProxyPopup.vue'
import { FeedbackValue, type Feedback } from '@/models'
import { ServerApi } from '@/api/server_api'
import { useSettings } from './composables/use-settings'
import dataikuIcon from '@/assets/icons/dataiku.png'
import Button from './ui/button/Button.vue'
const { knowledgeBankSelection } = useSettings()
// Reactive data
const feedbackValue = ref(FeedbackValue.GENERAL)
// Method
function submitFeedback(feedback: Feedback) {
  if (!feedback.message) return
  ServerApi.logGeneralFeedback({
    message: feedback.message,
    knowledge_bank_id: knowledgeBankSelection.value ?? ''
  })
}
</script>

<style scoped>
#feedback-btn-general {
  max-width: 170px;
}
.btn-solution-text {
  color: #000000;
  font-family: 'SourceSansPro';
  font-style: normal;
  font-weight: 600;
  font-size: 13px;
  line-height: 12px;
  white-space: nowrap;
}


</style>
