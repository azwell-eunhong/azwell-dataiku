<template>
  <div v-if="fileNames && fileNames.length" class="used-files-preview">
    <div class="flex items-center" style="margin-bottom: 6px">
      <img :src="TextFileIcon" alt="Text file icon" class="w-6 h-6 text-primary mr-1">
      <div>
        <UploadedFiles :files="fileNames" @close="deleteFile"></UploadedFiles>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import type { MediaSummary } from '@/models'
import UploadedFiles from '@/components/UploadedFiles.vue'
import TextFileIcon from '@/assets/icons/text-file-icon.svg'

const props = defineProps<{
  files: MediaSummary[]
}>()
const _files = ref<MediaSummary[]>([])
watch(
  () => props.files,
  (newVal) => {
    _files.value = newVal
  }
)
const fileNames = computed(() => {
  return _files.value.map((file: MediaSummary) => file.original_file_name ?? '')
})
const emits = defineEmits(['delete'])
const deleteFile = (index: number) => {
  const file = _files.value[index]
  emits('delete', file)
}
</script>
<style lang="scss" scoped>
.used-files-preview {
  align-self: center;
}
</style>
