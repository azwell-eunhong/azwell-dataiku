<template>
  <div>
    <div class="flex flex-wrap items-center justify-between mb-2 gap-3 text-sm">
      <span>
        Showing
        <strong>{{ firstRow }}–{{ lastRow }}</strong>
        of
        <strong>{{ rows.length }}</strong>
        records
      </span>

      <label class="flex items-center gap-1">
        <span>Rows&nbsp;per&nbsp;page:</span>
        <select
          v-model.number="internalPageSize"
          class="border rounded px-2 py-1"
        >
          <option v-for="opt in pageSizes" :key="opt" :value="opt">
            {{ opt }}
          </option>
        </select>
      </label>
    </div>

    <Table>
      <TableCaption v-if="title">{{ title }}</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead v-for="col in columns" :key="col.name">
            {{ col.label }}
          </TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow v-for="row in paginatedRows" :key="row.id ?? row.name">
          <TableCell v-for="col in columns" :key="col.name">
            {{ row[col.name] }}
          </TableCell>
        </TableRow>
      </TableBody>
    </Table>
    <nav
      v-if="totalPages > 1"
      class="flex items-center justify-between mt-4 gap-2 select-none"
    >
      <button
        class="px-3 py-1 rounded border"
        :disabled="currentPage === 1"
        @click="goTo(currentPage - 1)"
      >
        ‹
      </button>

      <span>Page {{ currentPage }} / {{ totalPages }}</span>

      <button
        class="px-3 py-1 rounded border"
        :disabled="currentPage === totalPages"
        @click="goTo(currentPage + 1)"
      >
        ›
      </button>
    </nav>
  </div>
</template>

<script setup lang="ts">
import {
  Table,
  TableCaption,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "./ui/table";
import {
  ref,
  computed,
  watch,
  withDefaults,
  defineProps,
  defineEmits,
} from "vue";

const props = withDefaults(
  defineProps<{
    title?: string;
    columns: Record<string, any>[];
    rows: Record<string, any>[];

    pageSize?: number;
    pageSizes?: number[];
    modelValue?: number;
  }>(),
  {
    pageSize: 5,
    pageSizes: () => [5, 10, 20, 30, 50],
    modelValue: 1,
  },
);

const emit = defineEmits<{
  (e: "update:modelValue", value: number): void;
  (e: "update:pageSize", value: number): void;
}>();

const currentPage = ref(props.modelValue);
const internalPageSize = ref(props.pageSize);

watch(
  () => props.modelValue,
  (v) => (currentPage.value = v),
);
watch(currentPage, (v) => emit("update:modelValue", v));

watch(
  () => props.pageSize,
  (v) => (internalPageSize.value = v),
);
watch(internalPageSize, (v) => {
  emit("update:pageSize", v);
  if (currentPage.value > totalPages.value) currentPage.value = totalPages.value;
});

const totalPages = computed(() =>
  Math.max(1, Math.ceil(props.rows.length / internalPageSize.value)),
);

const paginatedRows = computed(() => {
  const start = (currentPage.value - 1) * internalPageSize.value;
  return props.rows.slice(start, start + internalPageSize.value);
});

const firstRow = computed(() =>
  props.rows.length === 0 ? 0 : (currentPage.value - 1) * internalPageSize.value + 1,
);
const lastRow = computed(() =>
  Math.min(currentPage.value * internalPageSize.value, props.rows.length),
);

function goTo(page: number) {
  if (page >= 1 && page <= totalPages.value) currentPage.value = page;
}
</script>
