<template>
  <div class="bs-warning" :class="warningType" v-show="!hide">
    <div class="w-5">
      <component :is="iconName" class="w-4" />
    </div>
    <div class="bs-warning-text-container">
      {{ text }}
      <slot></slot>
    </div>
    <div class="w-5">
      <DismissIcon v-if="closable" name="close" class="cursor-pointer w-4" @click="hide = true" />
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import InfoCircleIcon from './icons/InfoCircleIcon.vue'
import DismissCircleIcon from './icons/DismissCircleIcon.vue'
import SettingsIcon from './icons/SettingsIcon.vue'
import CheckMarkIcon from './icons/CheckMarkIcon.vue'
import DismissIcon from './icons/DismissIcon.vue'
export default defineComponent({
  name: 'BsWarning',
  components: { InfoCircleIcon, DismissCircleIcon, SettingsIcon, CheckMarkIcon, DismissIcon },
  props: {
    text: String,
    warningType: {
      type: String,
      default: 'info' // default type is set to 'info'
    },
    closable: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      hide: false
    }
  },
  computed: {
    iconName() {
      switch (this.warningType) {
        case 'info':
          return InfoCircleIcon
        case 'error':
          return DismissCircleIcon
        case 'success':
          return CheckMarkIcon
        case 'settings':
          return SettingsIcon
        default:
          return InfoCircleIcon
      }
    },
    iconAlt(): string {
      return this.warningType + ' icon'
    }
  }
})
</script>

<style scoped>
.bs-warning {
  display: flex;
  max-width: 600px;
  justify-content: space-between;
  /* width: 100%; */
  padding: var(--bs-spacing-3, 12px) var(--bs-spacing-4, 16px);
  align-items: center;
  gap: var(--bs-spacing-2, 8px);
}

.bs-warning.info,
.bs-warning.settings {
  color: var(--information-bs-color-information, #27468e);
  border-left: 4px solid var(--information-bs-color-information, #27468e);
  background-color: var(--information-bs-color-information-background, #d6e1fe);
}

.bs-warning-text-container {
  flex-grow: 1;
  display: flex;
  align-items: center;
  gap: var(--bs-spacing-2, 8px);
}

.bs-warning.success {
  color: var(--status-bs-color-status-success, #0b590b);
  border-left: 6px solid #0b590b;
  background-color: rgba(0, 128, 0, 0.1);
}

.bs-warning.error {
  color: var(--status-bs-color-status-error, #ce1228);
  border-left: 6px solid #ce1228;
  background-color: rgba(233, 65, 43, 0.1);
}
</style>
