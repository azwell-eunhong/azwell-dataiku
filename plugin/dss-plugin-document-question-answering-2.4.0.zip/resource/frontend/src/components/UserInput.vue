<template>
  <div
    class="user-input-wrapper focus-within:outline-none "
    :class="{ 'rounded-md border border-input focus-within:ring-1 focus-within:ring-[color:var(--brand,#2ab1ad)]': showFileDropZone }"
    @dragenter.prevent="handleDrag"
  >
    <FileDropZoneVue
      v-if="showFileDropZone"
      :upload-file-types="uploadFileTypes"
      :uploadedFiles="uploadedFiles"
      v-model="files"
      @showFileDropZone="toggleShowDropZone"
      @dragover.prevent="handleDrag"
    />

    <div
      class="flex flex-col query-input flex w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50"
      :class="{ 'no-file-upload': !showUploadIcon, 'border-0': showFileDropZone, 'focus-within:ring-1 focus-within:ring-[color:var(--brand,#2ab1ad)]':!showFileDropZone }"
    >
      <textarea
        id="user-input-textarea"
        ref="textAreaRef"
        v-model="internalValue"
        class="resize-none pt-2 focus-visible:outline-none"
        :class="{ 'text-stone-300': props.loading, 'bg-[#F2F2F2]': props.loading }"
        :placeholder="inputPlaceholder"
        @input="handleInput"
        @keydown="handleKeyDown"
        @compositionstart="onCompositionStart"
        @compositionend="onCompositionEnd"
        @focus="handleFocus(true)"
        @blur="handleFocus(false)"
        :disabled="props.loading"
      />
      <div class="h-8 flex flex-row">
        <TooltipProvider :delay-duration="0" >
      <Tooltip>
        <TooltipTrigger as-child>
          <div>
            <button
              v-if="showUploadIcon"
              id="file-dropzone-btn"
              class="file-upload-button"
              :disabled="props.loading"
              @click="toggleFileDropZone"
              aria-label="Toggle file upload dropzone"
            >
              <img
                :src="AttachIcon"
                alt="Attach file icon"
                class="inline-block"
              />
          </button>
          </div>
        </TooltipTrigger>
        <TooltipContent v-if="!loading">
          <p>{{ $t('tooltip_file') }}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
      <TooltipProvider :delay-duration="0" v-if="!loading">
        <Tooltip>
          <TooltipTrigger as-child>
            <Button
              variant="ghost"
              :style="activeStyle" id="user-input-send-icon"
              class="absolute right-2 bottom-1 outline-none rounded-full w-8 h-8"
              @click="handleSend($event)"
              :class="!canSendMessage && 'cursor-default'"
              >
              <ArrowRightIcon />
            </Button>
          </TooltipTrigger>
          <TooltipContent v-if="canSendMessage">
            <p>{{ $t('tooltip_send') }}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      <SquareCircleIcon v-if="loading && streamingEnabled" class="spinner-wrapper w-9 h-9" id="user-input-stop-icon" name="mdiStopCircleOutline" />
      <Loader2 v-else-if="loading" id="user-input-spinner-icon" class="spinner-wrapper animate-spin h-6 w-6 text-[var(--q-primary)]" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue'
import { useSync } from '@/components/composables/use-sync'
import { watch } from 'vue'
import AttachIcon from '@/assets/icons/attach-icon.svg'
import FileDropZoneVue from '../components/FileDropZone.vue'
import type { MediaSummary } from '@/models'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import ArrowRightIcon from './icons/ArrowRightIcon.vue'
import SquareCircleIcon from './icons/SquareCircleIcon.vue'
import Button from './ui/button/Button.vue'
import { Loader2 } from 'lucide-vue-next'

const props = defineProps<{
  value: string
  loading: boolean
  inputPlaceholder: string
  uploadFileTypes?: string
  streamingEnabled?: boolean
  disableFileUpload?: boolean
  uploadedImage?: string
  uploadedFiles?: MediaSummary[]
}>()

const emits = defineEmits([
  'send:value',
  'enterkey:value',
  'update:value',
  'sizeChange',
  'deleteFile',
  'fileChange',
  'stop'
])
const internalValue = useSync(props, 'value', emits)
const focused = ref(false)
const textAreaRef = ref<InstanceType<typeof HTMLElement> | null>(null)
const _showFilesDropZone = ref(false)
const showFileDropZone = computed(() => {
  if (props.disableFileUpload) {
    return false
  }
  return _showFilesDropZone.value
})
const files = ref<File[]>([])

const toggleFileDropZone = () => {
  if (props.loading) {
    return
  }
  _showFilesDropZone.value = !_showFilesDropZone.value
}

const showUploadIcon = computed(() => {
  if (props.disableFileUpload) {
    return false
  }
  return !showFileDropZone.value
})

const toggleShowDropZone = (show: boolean) => {
  _showFilesDropZone.value = show
}

function handleDrag(event: DragEvent) {
  event.preventDefault()
  _showFilesDropZone.value = true
}
const formData = computed(() => {
  if (files.value.length > 0) {
    const formData = new FormData()
    files.value.forEach((file) => {
      formData.append('files[]', file)
    })
    return formData
  }
  return undefined
})
const handleSend = (e: MouseEvent) => {
  e.stopPropagation()
  emits('send:value', formData.value)
  _showFilesDropZone.value = false
  files.value = []
}
const isComposing = ref(false)
function onCompositionStart() {
      isComposing.value = true
}
function onCompositionEnd() {
  isComposing.value = false;
}
function handleInput() {
  adjustTextareaHeight();
}
function handleKeyDown(evt: KeyboardEvent) {
  if (evt.key === 'Enter' && !isComposing.value) {
    if (evt.shiftKey) {
      return;
    } else {
      evt.preventDefault();
      onReturnKey();
    }
  }
}
function onReturnKey() {
  emits('enterkey:value', formData.value)
  _showFilesDropZone.value = false
  files.value = []
}
watch(internalValue, () => {
  setTimeout(() => {
    adjustTextareaHeight()
    textAreaRef.value?.focus()
  }, 0)
})
watch(files, () => {
  if (files.value.length > 0) {
    textAreaRef.value?.focus()
  }
})
function handleFocus(isFocused: boolean) {
  focused.value = isFocused
}
function adjustTextareaHeight() {
  const textarea = textAreaRef.value
  if (!textarea) return

  const maxHeight = 150
  const minHeight = 40
  if (internalValue.value === '') {
    textarea.style.height = `${minHeight}px` //min-height
  } else {
    textarea.style.height =
      textarea.scrollHeight > maxHeight
        ? `${maxHeight}px`
        : `${Math.max(textarea.scrollHeight, textarea.offsetHeight)}px`
    const scrollHeight = textarea.scrollHeight
    textarea.style.overflowY = scrollHeight <= minHeight ? 'hidden' : 'auto'
  }

  emits('sizeChange', textarea.style.height)
}

const activeStyle = computed(() => ({
  backgroundColor: !canSendMessage.value ? '#FFFFFF' : 'var(--brand)',
  color: (!internalValue.value && !files.value.length) ? '#CCCCCC' : '#FFFFFF'
}))

const canSendMessage = computed(() => {
  return !props.loading && (internalValue.value || files.value.length);
});
</script>

<style scoped lang="scss">
.user-input-wrapper {
  position: relative;
  width: 100%;
}
.user-input-wrapper.focused {
  outline: none !important;
}
.user-input-wrapper.disabled {
  background-color: var(--greyscale-grey-lighten-8, #f2f2f2);
}
.query-input {
  min-height: 40px;
  max-height: 240px;
  font-size: 16px;
  min-width: calc(100% - 1px);
  max-width: calc(100% - 1px);
  overflow-y: hidden;
}
.query-input:focus {
  outline: none !important;
}
.query-input.no-file-upload {
  padding: 8px 32px 8px 12px;
}

textarea:disabled {
  background: var(--greyscale-grey-lighten-8, #f2f2f2);
}
.spinner-wrapper {
  position: absolute;
  right: 6px;
  bottom: 2px;
  color: var(--brand);
}
.file-upload-button {
  position: absolute;
  left: 10px;
  z-index: 1;
  bottom: 12px;
}
</style>
