export { default as Switch } from './BsSwitch.vue'
