<script setup lang="ts">
import type { HTMLAttributes } from 'vue'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import ProjectBlankIcon from '@/components/icons/ProjectBlankIcon.vue'
import { useSidebar } from './utils'
import { watch } from 'vue'

const props = defineProps<{
  class?: HTMLAttributes['class']
}>()

const emit = defineEmits<{
  (e: 'update:open', value: boolean): void
}>()

const { toggleSidebar, open } = useSidebar()

watch(open, (newValue) => {
  emit('update:open', newValue)
})

emit('update:open', open.value)
</script>

<template>
  <Button
    data-sidebar="trigger"
    variant="ghost"
    size="icon"
    :class="cn('h-7 w-7', props.class)"
    @click="toggleSidebar"
  >
    <ProjectBlankIcon />
    <span class="sr-only">Toggle Sidebar</span>
  </Button>
</template>
