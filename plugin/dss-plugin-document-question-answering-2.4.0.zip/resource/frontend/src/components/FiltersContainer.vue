<template>
  <Accordion type="single" collapsible class="filters-expansion-item">
    <AccordionItem value="filters" class="border-b-0">
      <AccordionTrigger  class="text-gray-700">
        <div class="text-[11px] pr-2">
          {{ $t('filters') }}
        </div>
      </AccordionTrigger>
      <AccordionContent>
        <div class="flex flex-col" style="margin-left: 4px">
          <div v-for="(tags, filterName) in filters" :key="filterName">
            <div class="bs-font-medium-2-normal filter-text">{{ filterName }}</div>
            <FilterTags :tags="tags" />
          </div>
        </div>
      </AccordionContent>
    </AccordionItem>
  </Accordion>
</template>

<script setup lang="ts">

import FilterTags from './FilterTags.vue'
import { AccordionTrigger, Accordion, AccordionContent, AccordionItem } from './ui/accordion';

defineProps<{
  filters: Record<string, any[]>
}>()
</script>

<style scoped lang="scss">
.filter-text {
  color: #444;
}

.filters-expansion-item {
  margin-top: 6px;
  margin-left: -4px;
}
.filters-expansion-item h3 {
  margin: 0px;
}
</style>
