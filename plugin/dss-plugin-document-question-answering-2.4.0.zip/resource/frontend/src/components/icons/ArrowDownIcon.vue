<template>
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path xmlns="http://www.w3.org/2000/svg"
            d="M17 3.96154C17 3.4305 16.5523 3 16 3C15.4477 3 15 3.4305 15 3.96154V25.5858L5.70711 16.2929C5.31658 15.9024 4.68342 15.9024 4.29289 16.2929C3.90237 16.6834 3.90237 17.3166 4.29289 17.7071L15.2929 28.7071C15.6834 29.0976 16.3166 29.0976 16.7071 28.7071L27.7071 17.7071C28.0976 17.3166 28.0976 16.6834 27.7071 16.2929C27.3166 15.9024 26.6834 15.9024 26.2929 16.2929L17 25.5858V3.96154Z"
            fill="black" />
    </svg>
</template>

<script setup lang="ts">
withDefaults(
    defineProps<{
        color?: string
    }>(),
    { color: 'black' }
)
</script>
