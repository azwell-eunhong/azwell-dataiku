<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="33" viewBox="0 0 32 33" fill="none">
   <rect width="32" height="32" transform="translate(0 0.11377)" fill="white"/>
   <path d="M8 6.11377H24V7.11377H8V6.11377Z" :fill="color"/>
   <path d="M6 8.11377H26V10.1138H6V8.11377Z" :fill="color"/>
   <path d="M28 11.1138H4V26.1138H28V11.1138ZM8.5 14.1138H18.5C19.3284 14.1138 20 14.7853 20 15.6138C20 16.4422 19.3284 17.1138 18.5 17.1138H8.5C7.67157 17.1138 7 16.4422 7 15.6138C7 14.7853 7.67157 14.1138 8.5 14.1138ZM7 21.6138C7 20.7853 7.67157 20.1138 8.5 20.1138H23.5C24.3284 20.1138 25 20.7853 25 21.6138C25 22.4422 24.3284 23.1138 23.5 23.1138H8.5C7.67157 23.1138 7 22.4422 7 21.6138Z" :fill="color"/>
 </svg>
 </template>
 <script setup lang="ts">
 withDefaults(
   defineProps<{
     color?: string
   }>(),
   { color: 'black' }
 )
</script>



