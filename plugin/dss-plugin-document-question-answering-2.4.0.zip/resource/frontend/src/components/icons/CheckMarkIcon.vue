<template>
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path xmlns="http://www.w3.org/2000/svg"
            d="M21.7071 4.79289C22.0976 5.18342 22.0976 5.81658 21.7071 6.20711L8.20711 19.7071C7.81658 20.0976 7.18342 20.0976 6.79289 19.7071L2.29289 15.2071C1.90237 14.8166 1.90237 14.1834 2.29289 13.7929C2.68342 13.4024 3.31658 13.4024 3.70711 13.7929L7.5 17.5858L20.2929 4.79289C20.6834 4.40237 21.3166 4.40237 21.7071 4.79289Z"
            fill="currentColor" />
    </svg>
</template>
<script setup lang="ts">

withDefaults(
    defineProps<{
        color?: string
    }>(),
    { color: 'black' }
)
</script>
