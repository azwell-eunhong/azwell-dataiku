<template>
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill="currentColor" xmlns="http://www.w3.org/2000/svg"
      d="M9.08727 7.00586C7.93725 7.00586 7.00497 7.93814 7.00497 9.08816V14.9186C7.00497 16.0686 7.93725 17.0009 9.08727 17.0009H14.9177C16.0677 17.0009 17 16.0686 17 14.9186V9.08816C17 7.93814 16.0677 7.00586 14.9177 7.00586H9.08727Z" />
    <path fill="currentColor" xmlns="http://www.w3.org/2000/svg"
      d="M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12ZM20.5 12C20.5 7.30558 16.6944 3.5 12 3.5C7.30558 3.5 3.5 7.30558 3.5 12C3.5 16.6944 7.30558 20.5 12 20.5C16.6944 20.5 20.5 16.6944 20.5 12Z" />
  </svg>
</template>
<script setup lang="ts">
withDefaults(
  defineProps<{
    color?: string
  }>(),
  { color: 'black' }
)
</script>
