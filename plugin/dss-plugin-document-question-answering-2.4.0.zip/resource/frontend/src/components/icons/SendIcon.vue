<template>
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M1.27171 5.89475C0.910008 5.77418 0.906543 5.57947 1.27864 5.45543L14.5045 1.04704C14.8711 0.925085 15.081 1.13019 14.9785 1.48913L11.1993 14.7143C11.0953 15.0809 10.884 15.0933 10.7288 14.7455L8.23839 9.1411L12.3959 3.5977L6.85254 7.75525L1.27171 5.89475Z"
      fill="currentColor"
    />
  </svg>
</template>
<script setup lang="ts">
withDefaults(
  defineProps<{
    color?: string
  }>(),
  { color: 'black' }
)
</script>
