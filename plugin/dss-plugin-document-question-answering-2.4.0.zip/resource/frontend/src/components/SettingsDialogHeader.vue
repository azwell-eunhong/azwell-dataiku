<template>
  <div class="p-4">
    <div class="flex items-center justify-between">
      <div class="flex items-center space-x-2">
        <SettingsIcon class="w-6 h-6" />
        <div class="text-xl">{{ t('settings') }}</div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import SettingsIcon from './icons/SettingsIcon.vue'
import { useI18n } from 'vue-i18n'
const { t } = useI18n()
</script>
