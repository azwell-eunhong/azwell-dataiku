<template>
  <div class="dku-tiny-text disclaimer" id="disclaimer">
    <div v-html="disclaimerText"></div>
  </div>
</template>
<script lang="ts" setup>
import { computed } from 'vue'
import { useUI } from '@/components/composables/use-ui'
import DOMPurify from 'dompurify'

// Hook to modify all <a> tags to have target="_blank" and rel="noopener noreferrer"
  DOMPurify.addHook('afterSanitizeAttributes', (node) => {
  if (node.tagName === 'A') {
    node.setAttribute('target', '_blank')
    node.setAttribute('rel', 'noopener noreferrer')
  }
})

const disclaimerText = computed(() => {
  return DOMPurify.sanitize(useUI().setup.value.disclaimer || '')
})
</script>

<style lang="css" scoped>

.dku-tiny-text {
    font-weight: 400;
    font-size: 10px;
    line-height: 13px;
    color: #222;
}
</style>
