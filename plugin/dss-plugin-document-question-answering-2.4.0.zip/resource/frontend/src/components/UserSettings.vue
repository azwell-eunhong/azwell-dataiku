<template>
  <div>
    <div class="flex items-center space-x-2">
      <div class="bs-font-medium-4-semi-bold">{{ t('user_settings') }}</div>
    </div>
    <div>
      <div class="flex items-center justify-between user-settings-language">
        <div class="all-title bs-font-medium-3-normal setting-key">{{ t('language') }}</div>
        <div class="setting-value">
          <Select :modelValue="selectedLanguage" @update:modelValue="value => updateSettings('language', value as string | number | null )">
            <SelectTrigger class="bs-font-medium-3-normal">
              <SelectValue :placeholder="selectedLanguage" />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                <SelectItem v-for="lang in languages" :key="lang" :value="lang">
                  {{ lang }}
                </SelectItem>
              </SelectGroup>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div v-for="(value, key) in otherSettings" :key="key"
        class="flex items-center justify-between user-settings-other">
        <div class="all-title flex items-center bs-font-medium-3-normal setting-key">
          {{ key }}
          <TooltipProvider :delay-duration="0">
            <Tooltip>
              <TooltipTrigger as-child>
                <InfoCircleFillIcon class="h-4 w-4 ml-1 cursor-pointer" />
              </TooltipTrigger>
              <TooltipContent>
                {{ value.description }}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <Input class="bs-font-medium-3-normal setting-value" :model-value="value.value"
          @update:model-value="(val: string | number | null) => updateSettings(String(key), val)" />
      </div>

      <ImageSettings :settings="props.settings" @update:settings="value => emits('update:settings', value)" />
    </div>
  </div>
</template>
<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { useUI } from './composables/use-ui'
import ImageSettings from './ImageSettings.vue'
import { updateObject } from '@/common/utils'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { TooltipProvider, TooltipContent, Tooltip, TooltipTrigger } from '@/components/ui/tooltip'
import InfoCircleFillIcon from './icons/InfoCircleFillIcon.vue';
const { t } = useI18n()
const { setup } = useUI()
const props = defineProps<{
  settings: Record<string, any>
}>()

const selectedLanguage = computed(() => {
  return props.settings.language.value
})

const otherSettings = computed(() => {
  const settings = JSON.parse(JSON.stringify(props.settings))
  delete settings.language
  delete settings.media
  delete settings.generated_media_info
  return settings
})

const languages = computed(() => {
  return setup.value.supportedLanguages?.map((lang: any) => lang.value) ?? []
})

const emits = defineEmits<{
  (e: 'update:settings', value: any): void
}>()

const updateSettings = (key: string, value: string | number | null) => {
  const newSettings = updateObject(props.settings, key, value)
  emits('update:settings', newSettings)
}
</script>
<style lang="scss" scoped>
.user-settings-language,
.user-settings-other {
  margin-bottom: 1rem;
}

.setting-key {
  width: 50%;
}

.setting-value {
  width: 50%;
}
</style>
