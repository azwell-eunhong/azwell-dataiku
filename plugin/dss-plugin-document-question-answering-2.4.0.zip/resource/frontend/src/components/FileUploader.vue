<template>
  <div style="display: inline-block">
    <Button
      id="select-files-btn"
      variant="link"
      @click="triggerFileInput"
      class="bs-font-medium-3-normal choose-files-btn text-[var(--q-primary)]"
    >
      {{ t('select_files') }}<span class="show-on-mobile">&nbsp;{{ t('files_and_images') }}</span>
  </Button>
    <input
      type="file"
      ref="fileInput"
      id="file-input"
      @change="handleFileChange"
      :accept="uploadFileTypes"
      multiple
      style="display: none"
    />
  </div>
</template>

<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { ref } from 'vue'
import Button from './ui/button/Button.vue';

const { t } = useI18n()
defineProps<{
  uploadFileTypes?: string
}>()

const emits = defineEmits(['update:status', 'uploadFile', 'updateSelectedFiles'])

const fileInput = ref<HTMLInputElement | null>(null)

const triggerFileInput = () => {
  fileInput.value?.click()
}

const handleFileChange = async (event: Event) => {
  emits('uploadFile', event)
}

const clearFileInput = () => {
  if (fileInput.value) {
    fileInput.value.value = ''
  }
}

// Expose the clearFileInput method
defineExpose({
  clearFileInput
})
</script>

<style scoped lang="scss">
.choose-files-btn {
  padding: 3px;
  margin-top: -3px;
}
</style>
