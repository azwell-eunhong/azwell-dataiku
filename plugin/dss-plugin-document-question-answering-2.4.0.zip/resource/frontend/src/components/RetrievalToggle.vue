<template>
  <div
    class="flex bs-font-medium-3-semi-bold kb-toggle-container use-knowledge-bank-label"
    v-if="isRetrievalActivated"
  >
    <div class="flex-row items-center no-wrap use-kb-label use-db-label">
      <div v-if="retrievalType === RetrievalMode.KB" size="24px" :style="{ color: 'var(--q-primary)'}">
        <KbIcon color="currentColor" style="height: 24px; width: 24px;" />
      </div>
      <div v-if="retrievalType === RetrievalMode.DB" size="24px" :style="{ color: 'var(--q-primary)'}">
        <DbIcon color="currentColor" style="height: 24px; width: 24px;" />
      </div>
      <span class="all-title bs-font-medium-3-normal">
        {{ !label ? defaultLabel : $t('use') + ' ' + label }}
      </span>
    </div>
    <Switch
      class="ml-2 my-auto data-[state=checked]:bg-[color:var(--q-primary,#3B99FC)] data-[state=unchecked]:bg-[#e5e5e5] retrieval-toggle"
      :model-value="modelValue"
      @update:model-value="(value) => $emit('update:modelValue', value)"
    ></Switch>
  </div>
</template>
<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { useUI } from './composables/use-ui'
import DbIcon from './icons/DbIcon.vue'
import KbIcon from './icons/KbIcon.vue'
import { RetrievalMode } from '@/models'
import Switch from '@/components/ui/switch/BsSwitch.vue'

const { setup } = useUI()
const { t } = useI18n()

const props = defineProps<{
  modelValue: boolean
  retrievalType: RetrievalMode | null
  label: string
}>()

defineEmits<{
  (e: 'update:modelValue', value: boolean): void
}>()

const defaultLabel = computed(() => {
  return props.retrievalType == RetrievalMode.KB
    ? t('use_knowledge_bank')
    : props.retrievalType == RetrievalMode.DB
    ? t('use_dataset')
    : ''
})
const isRetrievalActivated = computed(() => {
  return setup.value.retrievalMode !== RetrievalMode.NO_RETRIEVER
})
</script>
<style scoped>
.use-kb-label {
  padding-bottom: 4px;
  gap: 4px;
}
</style>
