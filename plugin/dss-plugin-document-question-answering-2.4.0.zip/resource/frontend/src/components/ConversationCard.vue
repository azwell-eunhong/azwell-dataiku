<template>
  <div
    class="py-2 px-4 card conv-card"
    :class="{ selected: isSelected }"
    @click="emits('update:conv', id)"
  >
    <div class="flex items-center justify-between align-center mb-2">
      <div class="flex flex-col max-w-[90%] gap-2">
        <div class="max-w-full">
          <TooltipProvider :delay-duration="0" disableHoverableContent>
            <Tooltip>
              <TooltipTrigger as-child>
                <div
                  class="overflow-hidden whitespace-nowrap text-ellipsis bs-font-medium-3-normal"
                >
                  {{ title }}
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>{{ title }}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>
      <div>
        <div
          class="text-[var(--q-primary)]"
          v-if="isSelected"
          @click.stop="openDialogDelete = true"
        >
          <TrashIcon id="delete-selected-conversation-icon"></TrashIcon>
          <DeleteDialog
            :open="openDialogDelete"
            :title="t('delete_item_title')"
            :text="t('delete_item_warning', { title: title })"
            @confirm="emits('delete:conv', props.id); openDialogDelete = false"
            @cancel="openDialogDelete = false"
            @update:open="openDialogDelete = $event"
          />
      </div>
        <div v-else></div>
      </div>
    </div>
    <div class="bs-font-medium-2-normal date flex justify-between ">
      <div class="flex items-center">
        <img :src="calendarIcon" class="pr-1"/>
        {{ formattedDate.split('-')[0] }}
      </div>
      <div class="flex items-center">
        <img :src="clockIcon" class="pr-1"/>
        {{ formattedDate.split('-')[1] }}
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import TrashIcon from './icons/TrashIcon.vue'
import clockIcon from '@/assets/icons/clock-icon.svg'
import calendarIcon from '@/assets/icons/calendar-icon.svg'
import { computed, ref } from 'vue'
import DeleteDialog from './DeleteDialog.vue'
import { useI18n } from 'vue-i18n'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'

const openDialogDelete = ref(false)

const { t } = useI18n()

function formatTimestamp(timestamp: number): string {
  const date = new Date(timestamp * 1000)
  const full = `${date.toLocaleString('default', {
    month: 'short'
  })} ${date.getDate()}, ${date.getFullYear()}`
  const fullWithTimestamp = `${full} - ${date.toLocaleTimeString('default', {
    hour: '2-digit',
    minute: '2-digit'
  })}`

  return fullWithTimestamp
}

const props = defineProps<{
  title: string
  date: number
  id: string
  isSelected: boolean
}>()

const formattedDate = computed(() => {
  return formatTimestamp(props.date)
})

const emits = defineEmits<{
  (e: 'update:conv', id: string): void
  (e: 'delete:conv', id: string): void
}>()
</script>

<style scoped lang="scss">
.column {
  max-width: 90%;
  gap: 8px;
  margin-bottom: 8px;
}
.card {
  // border-radius: 4px;
  // box-shadow: 0px 4px 2px rgba(0, 0, 0, 0.1);
  border-bottom: 1px solid var(--light_grey, #eaeff3);
  background: #fff;
  cursor: pointer;
}

.title {
  color: #333; /* .dds-caption-400 */
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.date {
  color: var(--greyscale-grey-lighten-4, #999);
}

.selected {
  // background: #f5f5f5;
  background: rgba(59, 153, 252, 0.2);
}
</style>
