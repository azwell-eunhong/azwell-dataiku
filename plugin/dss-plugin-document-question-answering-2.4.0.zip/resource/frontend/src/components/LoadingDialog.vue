<template>
  <Dialog v-model:open="isLoading">
    <DialogContent class="flex flex-col items-center justify-center bg-gray-100 text-gray-900 w-[250px] md:w-[400px] rounded-lg q-spinner">
      <Loader2 class="animate-spin h-16 w-16 text-[var(--q-primary)] loading-spinner" />
      <p class="mt-4 text-lg">{{ message }}</p>
    </DialogContent>
  </Dialog>
</template>

<script setup lang="ts">
import { Dialog, DialogContent } from '@/components/ui/dialog'
import { Loader2 } from 'lucide-vue-next'
import { useLoading } from '@/components/composables/use-loading'

const { isLoading, message } = useLoading()
</script>
