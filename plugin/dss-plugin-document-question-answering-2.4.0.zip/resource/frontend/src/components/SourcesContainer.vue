<template>
    <Collapsible :open="expanded" @update:open="expanded = $event">
      <CollapsibleTrigger class="flex items-center justify-left p-2 text-left font-semibold text-xs text-gray-600" :aria-label="`${expanded ? 'Collapse' : 'Expand'} &quot;${$t('sources')}&quot;`">
        {{ $t('sources') }}
        <ChevronDownIcon class="h-2 w-2 transition-transform ml-2" :class="{ 'rotate-180': expanded }" />
    </CollapsibleTrigger>
    <CollapsibleContent>
      <div class="source-item mt-2 mb-2">
        <Collapsible
          v-for="(source, index) in sources"
          :key="index"
          :open="sourceExpanded[index]"
          @update:open="sourceExpanded[index] = $event"
          class="source-text text-[11px] leading-4 text-gray-700 mb-4 break-words whitespace-pre-wrap"
        >
          <div class="source-meta ml-1 mb-2 font-semibold inline-flex gap-2.5" :id="`meta_${queryIndex}_source_${index + 1}`">
            <img
              class="source-thumbnail w-[100px] h-[60px] object-cover overflow-hidden"
              :src="(source.metadata.source_thumbnail_url as string)"
              v-if="source.metadata?.source_thumbnail_url"
            />
            <div class="my-auto">
            <span>{{ `${index + 1}. ` }} </span>
              <span v-if="getUrlFromSource(source)">
              <a :href="getUrlFromSource(source)!" target="_blank" class="source-link underline">
                  <span class="source-title">{{ getSourceTitle(source) }}</span>
                </a>
              </span>
              <span v-else class="source-title">{{ getSourceTitle(source) }}</span>
              <span v-if="source.records && source.records.columns" class="source-sample text-gray-600 font-normal"> ({{ $t('sample') }}) </span>
            </div>
            <div v-if="source.images && source.images.length" class="source-images flex gap-2">
              <img
                v-for="(img, imgIndex) in source.images"
                :key="imgIndex"
                :src="img.file_data"
                class="source-image w-[120px] h-auto object-cover my-1 cursor-zoom-in transition-transform duration-200 shadow-sm hover:scale-102 hover:shadow-md"
                @click="openLightbox(img.file_data)"
              />
            </div>
          </div>
          <div
            v-if="source.records && source.records.columns"
            :id="`query_${queryIndex}_source_${index + 1}`"
            class="source-content pl-2 pr-2 max-w-full overflow-hidden whitespace-normal"
          >
            <div v-if="displaySqlQuery">
              <div class="source-query-container pb-2">
                <span class="source-sql-query font-bold">{{ $t('sql_query') }}</span>
                <br />
                <span class="source-query text-sm">{{ source.records.query }}</span>
              </div>
            </div>
            <DataTable :rows="source.records.rows" :columns="source.records.columns"></DataTable>
          </div>
          <div
            v-else-if="source.textSnippet && displaySourceChunks"
            :id="`query_${queryIndex}_source_${index + 1}`"
            v-html="convertNewlinesToHTML(sanitize(source.textSnippet))"
            class="source-content pl-2 pr-2 max-w-full overflow-hidden whitespace-normal text-sm"
          />
          <TagsContainer :tags="getSourceTags(source)" v-if="source.metadata?.tags" />
        </Collapsible>
      </div>
      <transition name="lightbox-zoom">
        <div
          v-if="lightboxImage"
          class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-70 cursor-zoom-out lightbox-overlay"
          @click="closeLightbox"
        >
          <img :src="lightboxImage" class="max-w-[90vw] max-h-[90vh] object-contain rounded shadow-lg" id="source-image-preview" />
        </div>
      </transition>
    </CollapsibleContent>
  </Collapsible>
</template>


<script lang="ts">
import { defineComponent } from 'vue'
import type { Source, AggregatedToolSources } from '@/models'
import TagsContainer from './TagsContainer.vue'
import type { PropType } from 'vue'
import DOMPurify from 'dompurify'
import DataTable from './DataTable.vue'
import { useUI } from '@/components/composables/use-ui'
import { Collapsible, CollapsibleTrigger, CollapsibleContent } from './ui/collapsible'
import ChevronDownIcon from './icons/ChevronDownIcon.vue'

const { setup } = useUI()

const urlRegex =
  /(?:https?|ftp):\/\/[\S]+|(www\.[\S]+)|(?:\b\w+\.\w{2,}(?::\d{1,5})?(?:\/[\S]*)?\b)/gi
export default defineComponent({
  props: {
    aggregatedToolSources: {
      type: Array as () => AggregatedToolSources[],
      required: true
    },
    queryIndex: {
      type: Number,
      required: true
    },
    projectKey: {
      type: String,
      default: ''
    },
    folderId: {
      type: String,
      default: ''
    },
    expandSource: {
      type: Object as PropType<{ sourceIndex: string; citationIndex: string; queryIndex: string }>
    }
  },
  data() {
    return {
      expanded: false,
      sourceExpanded: [] as boolean[],
      timeout: undefined as ReturnType<typeof setTimeout> | undefined,
      displaySqlQuery: setup.value.displaySqlQuery,
      lightboxImage: null as string | null

    }
  },
  methods: {
    getSourceTitle(source: Source) {
      if (!source.usedTables && !source.title) {
        return ''
      }

      const source_title = source.usedTables ?? source.title;
      const { page, score } = source.metadata || {};

      if (!source_title) {
          return ''
      }

      const metadataParts = []
      if (page) {
        metadataParts.push(`Page: ${page}`)
      }
      if (score) {
        metadataParts.push(`Similarity Score: ${score}`)
      }

      const metadataString = metadataParts.length > 0 ? `, ${metadataParts.join(', ')}` : ''
      return `${source_title}${metadataString}`
    },
    sanitize(str: string) {
      return DOMPurify.sanitize(str, { FORBID_TAGS: ['input'] })
    },
    getUrlFromSource(source: Source): string | null {
      return (source.url as string) ?? null
    },
    isFileName(str: string): boolean {
      return /\.(pdf|docx|doc|xls|xlsx|ppt|pptx|txt|csv)$/i.test(str)
    },
    getUrlFromString(txt: string): string {
      const urls = txt.match(urlRegex) || []
      return urls.length > 0 ? (urls[0] as string) : ''
    },
    getDomainFromUrl(url: string): string {
      const match = url.match(/^(?:https?:\/\/)?(www\.)?([^/]+)/i)
      return match ? match[0] : ''
    },
    convertNewlinesToHTML(str: string): string {
      const lines = str.split('\n\n')
      let convertedString = lines[0]
      for (let i = 1; i < lines.length; i++) {
        convertedString += "<div style='margin-bottom: 6px;'>" + lines[i] + '</div>'
      }
      return convertedString
    },
    getSourceTags(source: Source) {
      if (source.metadata && source.metadata.tags) {
        const tags = {} as any
        ;(source.metadata.tags as any[]).forEach(
          (el: { name: string; value: string; type: string }) =>
            (tags[el.name] = el.type === 'string' ? [el.value] : [...el.value])
        )
        return tags
      }
    },
    handleExpandSource(info: Record<string, string>) {
      this.expanded = true
      this.sourceExpanded[Number(info.citationIndex)] = true
      this.timeout = setTimeout(() => {
        const href = this.displaySourceChunks ? `#query_${this.queryIndex}_source_${info['sourceIndex']}`: `#meta_${this.queryIndex}_source_${info['sourceIndex']}`;
        const targetElement = document.querySelector(href)
        if (targetElement) {
          targetElement.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'start' })
        }
      }, 200)
    },
    expandEventHandler(event: Event) {
      this.handleExpandSource((event as CustomEvent).detail)
    },
    openLightbox(imgUrl: string) {
      this.lightboxImage = imgUrl
    },
    closeLightbox() {
      this.lightboxImage = null
    }
  },
  watch: {
    expandSource(info: Record<string, string>) {
      this.handleExpandSource(info)
    },
    sources: {
      handler(newSources) {
        this.sourceExpanded = newSources.map(() => false);
      },
      immediate: true
  }
  },
  computed: {
    displaySourceChunks() {
      return setup.value.displayChunks
    },
    sources(): Source[] {
      if (this.aggregatedToolSources.length > 0) {
        const sources = this.aggregatedToolSources[0].items || [];
        return sources;
      }
      return [];
    }
  },
  components: { Collapsible, CollapsibleTrigger, CollapsibleContent, ChevronDownIcon, TagsContainer, DataTable },
  mounted() {
    const element = document.getElementById(`query_${this.queryIndex}_sources`)
    element?.addEventListener('expandSource', this.expandEventHandler)
  },
  beforeUnmount() {
    const element = document.getElementById(`query_${this.queryIndex}_sources`)
    element?.removeEventListener('expandSource', this.expandEventHandler)
    clearTimeout(this.timeout)
  }
})
</script>


<style scoped>
.expansion-item {
  font-style: normal;
  font-weight: 600;
  font-size: 20px;
  line-height: 15px;
  color: #666666;
  width: 100%;
}
.sources-expansion-item {
  margin-top: 8px;
  font-size: 12px;
  /* color: teal; */
  margin-left: -4px;
  color: #444;
  font-weight: bold;
  max-width: 90%;
}
:deep(.q-item) {
  padding: 4px;
}
:deep(.q-item__section--side > .q-icon) {
  font-size: 16px;
}
.source-item {
  margin-top: 5px;
  margin-bottom: 5px;
  word-wrap: break-word;
  overflow: hidden; /* Prevents overflowing */
}
.source-text {
  font-style: normal;
  font-weight: 400;
  font-size: 11px;
  line-height: 16px;
  /* color: teal; */
  color: #444;
  margin-bottom: 16px;
  word-wrap: break-word;
  overflow-wrap: break-word;
  overflow: hidden; /* Prevents overflowing */
  white-space: pre-wrap;
}
.source-records {
  color: #666666;
  font-weight: normal;
}
.source-content {
  word-wrap: break-word;
  overflow-wrap: break-word;
  padding-left: 6px;
  overflow: hidden;
  max-width: 100%; /* Ensures it doesn't exceed parent container */
  padding-left: 6px;
  margin-right: 6px;
  white-space: normal; /* Override if necessary */
}
.source-meta {
  margin-left: 4px;
  margin-bottom: 10px;
  font-weight: 600;
  display: inline-flex;
  gap: 10px;
}
.source-link {
  color: #666666;
  font-weight: 500;
  /* color: teal; */
  color: #444;
}
.source-thumbnail {
  width: 100px;
  height: 60px;
  overflow: hidden;
}
.source-query-container {
  padding-bottom: 8px;
}
.source-query {
  font-size: 12px;
}
.source-sql-query {
  font-weight: bold;
}

/* Ensure parent containers are not causing overflow */
.source-item,
.sources-expansion-item {
  max-width: 100%;
  overflow: hidden;
}
.source-image {
  width: 120px;
  height: auto;
  object-fit: cover;
  margin: 4px 0;
  cursor: zoom-in;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15);
}

.source-image:hover {
  transform: scale(1.02);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.lightbox-full-image {
  max-width: 90vw;
  max-height: 90vh;
  object-fit: contain;
  border-radius: 4px;
  box-shadow: 0 8px 16px rgba(0,0,0,0.5);
}

.lightbox-zoom-enter-active,
.lightbox-zoom-leave-active {
  transition: opacity 0.3s ease, transform 0.3s ease;
}
.lightbox-zoom-enter-from,
.lightbox-zoom-leave-to {
  opacity: 0;
  transform: scale(0.95);
}
</style>
