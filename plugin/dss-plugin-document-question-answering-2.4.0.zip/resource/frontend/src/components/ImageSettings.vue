<template>
  <div v-if="settings.media">
    <div class="text-lg font-semibold mb-4">{{ t('image_generation_settings') }}</div>
    <bs-warning
      type="info"
      :text="t('image_generation_settings_disclaimer')"
      :closable="true"
      class="user-settings-image mb-8"
    >
    </bs-warning>
    <div class="flex items-center justify-between mb-4">
      <div class="flex items-center align-center">
        <span class="text-base">{{ t('image_generation_model') }}</span>
        <TooltipProvider :delay-duration="0">
          <Tooltip>
            <TooltipTrigger as-child>
              <InfoCircleFillIcon class="h-4 w-4 ml-1 cursor-pointer" />
            </TooltipTrigger>
            <TooltipContent>
              {{ t('image_generation_model_tooltip') }}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
      <span class="text-base">{{ model }}</span>
    </div>

    <div class="flex items-center justify-between mb-4" v-if="maxImagesPerWeek">
      <div class="flex items-center align-center">
        <span class="text-base">{{ t('max_images_per_week') }}</span>
        <TooltipProvider :delay-duration="0">
          <Tooltip>
            <TooltipTrigger as-child>
              <InfoCircleFillIcon class="h-4 w-4 ml-1 cursor-pointer" />
            </TooltipTrigger>
            <TooltipContent>
              {{ t('max_images_per_week_tooltip') }}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
      <span>
        <b class="text-base font-normal">{{ quotaLabel }}</b> {{ nextResetInDaysHours.length ? t('until') : '' }}
        <b class="text-base font-normal">{{ nextResetInDaysHours }}</b>
      </span>
    </div>
    <div
      v-for="(value, key) in settings.media.image"
      :key="key"
      class="flex items-center justify-between mb-4 user-settings-image"
    >
      <div class="flex items-center align-center">
        <span class="text-base">{{ t(key) }}</span>
      <TooltipProvider :delay-duration="0">
        <Tooltip>
          <TooltipTrigger as-child>
            <InfoCircleFillIcon class="h-4 w-4 ml-1 cursor-pointer" />
          </TooltipTrigger>
          <TooltipContent>
            {{ t(value.description) }}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
    <Select
      :model-value="value.value"
        @update:model-value="val => updateSettings('media.image.' + key, val as string | number | null)"
    >
      <SelectTrigger class="w-[170px] setting-value">
        <SelectValue :placeholder="value.value" :id="`select-${key}`" />
      </SelectTrigger>
      <SelectContent>
        <SelectGroup>
          <SelectItem
            v-for="option in value.options"
            :key="option"
            :value="option"
          >
            {{ option }}
          </SelectItem>
        </SelectGroup>
      </SelectContent>
        <DismissIcon
          v-if="value.value"
          :id="`dismiss-selected-${key}`"
          @click.stop="updateSettings('media.image.' + key, null)"
          class="absolute right-16 h-4 w-4 cursor-pointer opacity-50"
        />
      </Select>
    </div>
  </div>
</template>
<script setup lang="ts">
import { computed } from 'vue';
import { useI18n } from 'vue-i18n';
import { useUI } from './composables/use-ui';
import BsWarning from './BsWarning.vue'
import { updateObject } from '@/common/utils';
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { TooltipProvider, Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import InfoCircleFillIcon from './icons/InfoCircleFillIcon.vue';
import DismissIcon from './icons/DismissIcon.vue';

const { t } = useI18n()
const { setup } = useUI()
const props = defineProps<{
  settings: Record<string, any>
}>()
const model = computed(() => {
  return setup.value.imageGenerationLLMId ? setup.value.imageGenerationLLMId.split(':')[2] : ''
})
const maxImagesPerWeek = computed(() => {
  return setup.value.maxImagesToGenerate
})
const numImagesLeft = computed(() => {
  if (!maxImagesPerWeek.value) return 0
  if (props.settings.generated_media_info && props.settings.generated_media_info.image) {
    if(!nextResetInDaysHours.value.length) return maxImagesPerWeek.value
    const numGenerated = props.settings.generated_media_info.image['count']
    return maxImagesPerWeek.value - numGenerated
  }
  return maxImagesPerWeek.value
})
const quotaLabel = computed(() => {
  if (!maxImagesPerWeek.value) return ''
  return `${Math.max(numImagesLeft.value, 0)} ${t('images_left_of')} ${maxImagesPerWeek.value}`
})
const nextResetInDaysHours = computed(() => {
  if (!maxImagesPerWeek.value || !props.settings.generated_media_info) return ''
  // Calculate next reset time in days and hours
  // (e.g., Next week from the first generation within a week)
  const firstGeneration = Math.floor(
    props.settings.generated_media_info.image['first_generated_at']
  )
  const hoursInS = 60 * 60
  const dayInS = hoursInS * 24
  const currentTime = Math.floor(Date.now() / 1000)
  const elapsedTime = currentTime - firstGeneration
  if (elapsedTime >= 7 * dayInS) return ''
  const timeUntilNextReset = 7 * dayInS - (elapsedTime % (7 * dayInS))
  // Convert time to days and hours
  const days = Math.floor(timeUntilNextReset / dayInS)
  const hours = Math.floor((timeUntilNextReset % dayInS) / hoursInS)

  return `${days}${t('days')} ${hours > 0 ? `${hours}${t('hours')}` : ''}`
})
const emits = defineEmits<{
  (e: 'update:settings', value: any): void
}>()
const updateSettings = (key: string, value: string | number | null) => {
  const newSettings = updateObject(props.settings, key, value)
  emits('update:settings', newSettings)
}
</script>
