<template>
  <Popover v-model:open="open">
    <PopoverTrigger v-if="!disableTrigger" as-child>
      <slot></slot>
    </PopoverTrigger>
    <slot v-else></slot>
    <PopoverContent class="min-w-[300px] max-w-[400px] p-0 border-[#a6d6d4] card-container">
        <CardHeader>
          <div class="flex justify-between items-center">
            <div class="flex items-center gap-2">
              <svg
                class="w-4 h-4"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 16 16"
                fill="none"
              >
                <path
                  d="M1.00073 7.96559C1.00073 4.12594 4.13789 1.01953 8.00037 1.01953C11.8628 1.01953 15 4.12594 15 7.96559C15 11.8052 11.8628 14.9117 8.00037 14.9117C6.89513 14.9117 5.85195 14.6539 4.92308 14.201L2.11158 14.9488C2.11148 14.9488 2.11139 14.9488 2.1113 14.9488C1.46125 15.1231 0.853473 14.5326 1.03139 13.8733L1.03141 13.8732L1.77081 11.1351C1.27925 10.1847 1.00073 9.10709 1.00073 7.96559ZM8.00037 1.89449C4.61434 1.89449 1.87569 4.61591 1.87569 7.96559C1.87569 9.01867 2.1466 10.008 2.62158 10.8711C2.67616 10.9703 2.69017 11.0867 2.66066 11.1961L1.87613 14.1012C1.87611 14.1013 1.87609 14.1014 1.87607 14.1014C1.87626 14.1017 1.87648 14.1019 1.87674 14.1022C1.87862 14.104 1.88017 14.1046 1.88023 14.1046L1.88019 14.1046L1.88011 14.1045C1.88013 14.1045 1.88157 14.1046 1.88478 14.1037L1.88574 14.1035L4.85864 13.3128C4.96379 13.2848 5.07559 13.297 5.17221 13.3471C6.01953 13.7857 6.97937 14.0367 8.00037 14.0367C11.3864 14.0367 14.125 11.3153 14.125 7.96559C14.125 4.61591 11.3864 1.89449 8.00037 1.89449ZM1.88011 14.1045C1.88001 14.1045 1.88002 14.1045 1.8801 14.1045L1.88011 14.1045Z"
                  fill="black"
                />
              </svg>
              <span class="text-base">{{ title }}</span>
            </div>
            <svg
              class="w-4 h-4 cursor-pointer"
              @click="closePopup"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 16 16"
              fill="none"
            >
              <path
                d="M2.58859 2.71569L2.64645 2.64645C2.82001 2.47288 3.08944 2.4536 3.28431 2.58859L3.35355 2.64645L8 7.293L12.6464 2.64645C12.8417 2.45118 13.1583 2.45118 13.3536 2.64645C13.5488 2.84171 13.5488 3.15829 13.3536 3.35355L8.707 8L13.3536 12.6464C13.5271 12.82 13.5464 13.0894 13.4114 13.2843L13.3536 13.3536C13.18 13.5271 12.9106 13.5464 12.7157 13.4114L12.6464 13.3536L8 8.707L3.35355 13.3536C3.15829 13.5488 2.84171 13.5488 2.64645 13.3536C2.45118 13.1583 2.45118 12.8417 2.64645 12.6464L7.293 8L2.64645 3.35355C2.47288 3.17999 2.4536 2.91056 2.58859 2.71569L2.64645 2.64645L2.58859 2.71569Z"
                fill="#333E48"
              />
            </svg>
          </div>
        </CardHeader>
        <CardContent class="p-4">
          <p class="text-sm text-gray-400 pb-2">{{ caption }}</p>
          <div class="flex flex-wrap gap-2 my-2">
            <div
              v-for="(option, index) in feedbackOptions"
              :key="index"
              class="px-3 py-1 text-sm border border-gray-300 rounded cursor-pointer"
              :class="{ 'bg-blue-100 border-blue-500': localChoiceSelection[option] }"
              @click="localChoiceSelection[option] = !localChoiceSelection[option]"
            >
              {{ option }}
            </div>
          </div>
          <Textarea
            class="focus:ring-[color:var(--brand,#2ab1ad)] focus-visible:ring-[color:var(--brand,#2ab1ad)] focus:outline-none"
            id="user-feedback-textarea"
            :model-value="localFeedbackMessage"
            :placeholder="input_placeholder"
            @update:modelValue="(modelValue) => (localFeedbackMessage = String(modelValue))"
          />
        </CardContent>
        <CardFooter class="flex justify-end gap-2 p-2">
          <Button
            id="cancel-feedback-btn"
            class="text-[#DD5969] hover:text-[#DD5969]"
            variant="ghost"
            @click="closePopup"
            >
            {{ t('cancel') }}
          </Button>
          <Button
            id="submit-feedback-btn"
            class="ml-2 text-[var(--q-primary)] hover:text-[var(--q-primary)] uppercase"
            variant="ghost"
            :disabled="!submitEnabled"
            @click="emitSave"
          >
            {{ t('submit') }}
          </Button>
        </CardFooter>
    </PopoverContent>
  </Popover>
</template>

<script setup lang="ts">
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover'
import { CardHeader, CardContent, CardFooter } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { ref, computed, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { FeedbackValue, type Feedback } from '@/models'
import { WT1iser } from '@/common/wt1'

const { t } = useI18n()

const open = ref(false)
const explicitClose = ref(false)

const props = defineProps<{
  feedbackValue: FeedbackValue
  feedbackOptions: string[]
  submitOnHide: boolean
  disableTrigger?: boolean
}>()

const emits = defineEmits<{
  (e: 'save', feedback: Feedback): void
  (e: 'close'): void
}>()

const localChoiceSelection = ref<Record<string, boolean>>(
  Object.fromEntries(props.feedbackOptions.map((item) => [item, false]))
)
const localFeedbackMessage = ref<string>('')

const feedback = computed(() => ({
  value: props.feedbackValue,
  message: localFeedbackMessage.value,
  choice: Object.entries(localChoiceSelection.value)
    .filter(([, selected]) => selected)
    .map(([option]) => option),
}))

const input_placeholder = computed(() =>
  props.feedbackValue === FeedbackValue.GENERAL
    ? t('feedback_input_placeholder_general')
    : t('feedback_input_placeholder')
)
const caption = computed(() =>
  props.feedbackValue === FeedbackValue.GENERAL
    ? t('feedback_dialog_placeholder_general')
    : props.feedbackValue === FeedbackValue.POSITIVE
    ? t('feedback_dialog_placeholder_positive')
    : t('feedback_dialog_placeholder_negative')
)
const title = computed(() =>
  props.feedbackValue === FeedbackValue.GENERAL
    ? t('feedback_title_general')
    : props.feedbackValue === FeedbackValue.POSITIVE
    ? t('feedback_title_positive')
    : t('feedback_title_negative')
)
const submitEnabled = computed(() =>
  props.feedbackValue === FeedbackValue.POSITIVE ||
  ((props.feedbackValue === FeedbackValue.GENERAL ||
    props.feedbackValue === FeedbackValue.NEGATIVE) &&
    (feedback.value.message?.length || feedback.value.choice?.length))
)

function closePopup() {
  if (props.feedbackValue === FeedbackValue.GENERAL) {
    localFeedbackMessage.value = ''
  }
  explicitClose.value = true
  open.value = false
  if (props.submitOnHide) {
    emitSave()
  }
  emits('close')
}

function hideOrSubmit() {
  if (props.submitOnHide) {
    emitSave()
  }
}

function emitSave() {
  if (
      props.feedbackValue === FeedbackValue.GENERAL &&
      submitEnabled.value
    ) {
    WT1iser.giveFeedback(0, props.feedbackValue, !!localFeedbackMessage.value)
    emits('save', feedback.value)
    localFeedbackMessage.value = ''
  }
  emits('save', feedback.value)
  explicitClose.value = true
  open.value = false
}

watch(open, (newVal) => {
  if (!newVal) {
    hideOrSubmit()
  }
})
</script>

<style scoped lang="scss">
.feedback-popover-content {
  min-width: 300px;
  max-width: 400px;
}

.feedback-dialog-title {
  margin-right: 36px;
  flex: 1;
}

.caption-text {
  color: var(--greyscale-grey-lighten-4, #999);
}

.chip {
  margin-left: 0;
  border-radius: 3.726px;
  border: 1px solid var(--light_grey, #eaeff3);
  background-color: #fff;
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  line-height: 15px;
  color: var(--dss-objects-dark-teal-base, #3b7879);
  width: fit-content;

  &.active {
    background-color: rgba(67, 125, 126, 0.07);
    border: 1px solid #629394;
  }
}

:deep(.q-chip__icon) {
  color: #609192 !important;
}
</style>
