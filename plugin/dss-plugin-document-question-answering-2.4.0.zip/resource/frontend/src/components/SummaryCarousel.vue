<template>
  <Carousel v-model="carouselSummaryInFocus" class="w-full flex">
    <CarouselContent class="ml-0">
      <CarouselItem
        v-for="(summary, summaryIdx) in summaries"
        :key="summaryIdx"
        class="flex flex-col items-start pl-[36px] pr-[36px] md:pl-[32px] md:pr-[32px]"
        :class="{ 'min-h-[216px]': summaries.length > 1 }"
      >
        <SummaryCard :summary="summary" @question="useQuestion($event)" />
      </CarouselItem>
    </CarouselContent>
    <CarouselPrevious v-if="summaries.length > 1" class="left-0 bg-brand text-white border-none" :id="`${idPrefix}-carousel-previous-arrow`" />
    <CarouselNext v-if="summaries.length > 1" class="right-0 bg-brand text-white border-none" :id="`${idPrefix}-carousel-next-arrow`"/>
  </Carousel>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { Carousel, CarouselContent, CarouselItem, CarouselPrevious, CarouselNext } from './ui/carousel';
import SummaryCard from '@/components/SummaryCard.vue'
import type { MediaSummary } from '@/models'

defineProps<{
  summaries: MediaSummary[]
  useQuestion: (question: string) => void
  idPrefix?: string
}>()

const carouselSummaryInFocus = ref(0)
</script>
