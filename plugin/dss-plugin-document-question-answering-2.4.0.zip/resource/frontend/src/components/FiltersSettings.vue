<template>
  <div v-if="setup.filtersConfig">
    <div class="row items-center no-wrap q-gutter-x-sm" style="margin-top: 20px">
      <div class="bs-font-medium-4-semi-bold">{{ t('filters') }}</div>
    </div>
    <div class="mb-4">
      <Button class="pt-2" variant="link" size="xs" @click="clearAllFilters" v-if="hasSelectedFilters">
        Clear All Filters
      </Button>
      <BsWarning type="info" :text="t('empty_filters_text')" v-else />
    </div>
    <div style="overflow-y: scroll" v-if="setup.filtersConfig.filter_options">
      <div v-for="(options, column) in setup.filtersConfig.filter_options" :key="column" class="mb-4 w-[300px]">
        <div class="flex flex-col justify-between w-[300px]" :class="`select-${column}`">
          <div>{{t('select_label')}} {{ column }}</div>
          <DropdownMenu v-model:open="isOpenMap[column]">
            <DropdownMenuTrigger class="flex justify-end h-9 rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 cursor-pointer" as-child>
              <div>
                <ChevronDownIcon
                  class="transition-transform duration-200 ease-in-out my-auto"
                  :class="{ 'rotate-180': isOpenMap[column] }"
                />
              </div>
            </DropdownMenuTrigger>
            <DropdownMenuContent class="w-[300px] max-h-60 overflow-y-scroll">
              <Input
                v-model="searchTerms[column]"
                :placeholder="t('Filter')"
                @click.prevent
                @keydown.stop
              />
              <DropdownMenuCheckboxItem
                :key="`${column}-select-all`"
                :modelValue="isAllSelected(column)"
                @update:modelValue="toggleAll(column, $event)"
                @select="keepOpen"
                class="font-semibold border-b"
                :class="`${column}-select-all`"
              >
                Select all
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                class="break-all"
                v-for="option in filteredOptions(column)"
                :key="option"
                :modelValue="isSelected(column, option)"
                @update:modelValue="toggleOption(column, option, $event)"
                @select="keepOpen"
              >
                {{ option }}
              </DropdownMenuCheckboxItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <div v-if="props.filters[column]?.length" class="mt-2 flex w-full justify-between max-h-[200px] overflow-y-auto">
          <div class="flex flex-col gap-2 w-28">
            <TooltipProvider :delay-duration="0" disableHoverableContent>
              <Tooltip v-for="option in props.filters[column]" :key="option">
                <TooltipTrigger as-child>
                  <Badge
                    class="bg-[color:var(--q-primary,#3B99FC)] hover:bg-[color:var(--q-primary,#3B99FC)]"
                    :class="`selected-badge-${option}`"
                  >
                    <div class="truncate w-24">{{ option }}</div>
                    <DismissIcon class="ml-2 h-4 w-4 cursor-pointer" @click="removeOption(column, option)" />
                  </Badge>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{{ option }}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <div class="border-solid border-l">
            <Button variant="link" size="xs" @click="clearColumnFilters(column)">Clear All</Button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useI18n } from 'vue-i18n';
import BsWarning from './BsWarning.vue';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
} from '@/components/ui/dropdown-menu';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input'; // Make sure to import the Input component
import { Badge } from '@/components/ui/badge';
import ChevronDownIcon from './icons/ChevronDownIcon.vue'
import DismissIcon from './icons/DismissIcon.vue'
import { useUI } from './composables/use-ui';
import { computed, defineEmits, reactive, watch } from 'vue';

const { t } = useI18n();
const { setup } = useUI();

// Define props
const props = defineProps<{
  filters: Record<string, string[]>;
}>();

// Define emits
const emit = defineEmits<{
  (e: 'update:settings', column: string, newVal: string[]): void;
}>();

// Reactive object to track each dropdown's open state
const isOpenMap = reactive<Record<string, boolean>>({});
// Reactive object for search input values
const searchTerms = reactive<Record<string, string>>({});

const filteredOptions = (column: string) => {
  const searchTerm = searchTerms[column]?.toLowerCase() || '';
  if (!searchTerm) {
    return setup.value.filtersConfig?.filter_options[column] || [];
  }
  return (setup.value.filtersConfig?.filter_options[column] || []).filter(
    (option: string) => option.toLowerCase().includes(searchTerm)
  );
};

function keepOpen(e: Event) {
  // Stop Radix from closing the menu after this selection
  e.preventDefault()
}

// Initialize isOpenMap and searchTerms based on filter_options
watch(
  () => setup.value.filtersConfig?.filter_options,
  (newVal) => {
    if (newVal) {
      for (const column in newVal) {
        if (!(column in isOpenMap)) {
          isOpenMap[column] = false;
          searchTerms[column] = '';
        }
      }
    }
  },
  { immediate: true }
);

/** Check if there are any selected filters */
const hasSelectedFilters = computed(() =>
  Object.values(props.filters).some((options) => options.length > 0)
);

/** Determine if an option is selected for a given column */
const isSelected = (column: string, option: string) => {
  return (props.filters[column] || []).includes(option);
};

const isAllSelected = (column: string) => {
  const visibleOptions = filteredOptions(column);
  const selected = props.filters[column] || [];
  return visibleOptions.length > 0 && visibleOptions.every(option => selected.includes(option));
};

const toggleAll = (column: string, checked: boolean) => {
  const currentSelection = props.filters[column] || [];
  const visibleOptions = filteredOptions(column);
  let newSelection: string[];

  if (checked) {
    // Add only the visible options to the current selection
    newSelection = [...new Set([...currentSelection, ...visibleOptions])];
  } else {
    // Remove the visible options from the current selection
    newSelection = currentSelection.filter(option => !visibleOptions.includes(option));
  }

  emit('update:settings', column, newSelection);
};

/** Toggle an option's selection state */
const toggleOption = (column: string, option: string, checked: boolean) => {
  const current = props.filters[column] || [];
  let newVal: string[];
  if (checked) {
    newVal = [...current, option];
  } else {
    newVal = current.filter((item) => item !== option);
  }
  emit('update:settings', column, newVal);
};

/** Remove a specific selected option */
const removeOption = (column: string, option: string) => {
  const current = props.filters[column] || [];
  const newVal = current.filter((item) => item !== option);
  emit('update:settings', column, newVal);
};

/** Clear selected filters for a specific column */
const clearColumnFilters = (column: string) => {
  emit('update:settings', column, []);
};

/** Clear all selected filters */
const clearAllFilters = () => {
  if (setup.value.filtersConfig) {
    for (const column in setup.value.filtersConfig.filter_options) {
      emit('update:settings', column, []);
    }
  }
};
</script>