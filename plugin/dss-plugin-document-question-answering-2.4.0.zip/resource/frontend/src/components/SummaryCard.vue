<template>
  <div :class="{ deleted: summary.is_deleted }">
    <Card>
      <CardContent>
        <img
          v-if="summary.preview"
          id="summary-file-preview"
          :src="summary.preview"
          class="float-right mb-2 media-preview pt-2 ml-4"
        />
        <img
          v-else-if="summary.is_deleted"
          :src="FileRemoveIcon"
          class="float-right mb-2 media-preview pt-2 ml-4"
        />
        <img
          v-else
          :src="TextFileIcon"
          class="float-right w-24 h-32 object-contain mb-2 pt-2 ml-4"
        />
        <div>
          <CardTitle
            class="text-brand text-[color:var(--brand,#2AB1AD)] break-all"
            :class="{ 'text-gray-400': summary.is_deleted }"
          >
            {{ t('summary') }}: {{ summary.original_file_name }}
          </CardTitle>
          <div class="mt-4 text-base text-justify" id="summary-text">{{ summary.summary }}</div>
          <div v-if="summary.topics" class="mt-4" id="summary-topics">
            <div class="font-medium">{{ t('key_topics') }}</div>
            <div class="mt-2">
              <span
                v-for="(topic, index) in summary.topics"
                :key="index"
                class="mr-2"
              >
                {{ topic }}{{ index < summary.topics.length - 1 ? ',' : '' }}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
    <div class="grid md:grid-cols-3 gap-4 mt-4">
      <InfoCard
        :id="`summary-question-${idx}`"
        v-for="(question, idx) in summary.questions"
        :text="question"
        style="cursor: pointer"
        @click="emits('question', question)"
        v-bind:key="idx"
        />
    </div>
  </div>
</template>

<script setup lang="ts">
import type { MediaSummary } from '@/models/index'
import { useI18n } from 'vue-i18n'
import TextFileIcon from '@/assets/icons/text-file-icon.svg'
import FileRemoveIcon from '@/assets/icons/file-remove-icon.svg'
import { Card, CardContent, CardTitle } from './ui/card'
import InfoCard from '@/components/InfoCard.vue'

const { t } = useI18n()

defineProps<{
  summary: MediaSummary
}>()

const emits = defineEmits(['question'])

// TODO: emit click event to parent component
</script>
<style scoped lang="scss">


.media-preview {
  max-width: 100px;
  max-height: 130px;
  height: auto;
  object-fit: contain;
}
</style>
