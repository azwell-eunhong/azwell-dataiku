## Base imports
from dataiku.code_env_resources import clear_all_env_vars

# Clears all environment variables defined by previously run script
clear_all_env_vars()