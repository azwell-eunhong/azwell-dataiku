from answers.backend.utils.launch_utils import run_create_app


def create_app():
    run_create_app(app)
    return app


create_app()