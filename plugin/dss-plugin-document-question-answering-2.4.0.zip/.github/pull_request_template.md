## 🚀 Pull Request Template

### 📝 Description  
- Summarize the change you made and **why** in few words.  
- If the branch is **not linked to a Shortcut story**, paste the Shortcut ticket ID.  
- If applicable, include any related **support ticket references**.  

---

### ✅ Test Coverage  
- Describe what has been tested and **how** (e.g., unit tests, API tests, Playwright, manual testing).  
- Mention **any untested cases**, or tests **yet to be implemented**.  
- Include **screenshots** of UI changes or test results if helpful.  

---

### 🔁 Submodule Changes  
- [ ] Yes  
- [ ] No  

> _If yes, confirm that submodule updates are necessary and point forward (not backward). Confirm that submodule PRs are created_

---

### 🧪 Should the Reviewer Test This Locally?  
- [ ] Yes  
- [ ] No  

> _If yes, add steps or setup instructions here._

---

### 📌 Additional Notes  
- Include any extra information that would help the reviewer (e.g., caveats, assumptions, migration steps).

---

### 🧹 Pre-Review Checklist (Self Check)  
> Before requesting a review, make sure you've double-checked the following:

- [ ] **Changed files make sense** — No unexpected changes (e.g., frontend files modified during a backend-only update).  
- [ ] **Submodule references point forward** — Only update submodules when needed.  
- [ ] **Tests pass** — All tests pass locally and in CI.  
- [ ] **Tests added** — At least one relevant test is added for new or changed logic.  
- [ ] **PR description is complete** — Shortcut/support tickets linked, tests described, and notes provided.