from answers.solutions.vector_search.generic_vector_search import (
    GenericVectorQuery,
)
from answers.solutions.vector_search.models import VecOperator


class ElasticSearchOperator(VecOperator):
    pass

class ElasticSearchVectorQuery(GenericVectorQuery):
    def __init__(self):
        super().__init__(ElasticSearchOperator)
