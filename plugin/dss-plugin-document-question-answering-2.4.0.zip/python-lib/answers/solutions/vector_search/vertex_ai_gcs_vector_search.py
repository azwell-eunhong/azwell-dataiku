from answers.solutions.vector_search.generic_vector_search import GenericVectorQuery
from answers.solutions.vector_search.models import VecOperator


class VertexAIGCSOperator(VecOperator):
    pass

class VertexAIGCSVectorQuery(GenericVectorQuery):
    def __init__(self):
        super().__init__(VertexAIGCSOperator)
