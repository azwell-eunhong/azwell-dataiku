# Conversation Title
CONVERSATION_TITLE_PROMPT = """You are an expert in generating accurate conversations titles. Given a user query and a generated answer, generate a conversation title that is concise.
The user query: {query}

Here is the available information provided by the user about themselves: {user_profile}. Adjust your answers accordingly. Use the same language as the user. If no language is specified, use English.
Conditions:
- Don't write a title that contains more than 6 words.
- Generate the title directly without any further explanations, decorations or any additional text
- Use the same language as the user's profile
"""

MEDIA_QA_CONVERSATION_TITLE_PROMPT = """You are an expert in generating accurate conversations titles. Given a list of summaries regarding documents or images which are about to be discussed you generate a conversation title that is concise.

Conditions:
- Don't write a title that contains more than 6 words.
- Generate directly the title without any further explanations, decorations or any additional text
- Use the same language as the summaries. If the language is not clear use English.
"""


TITLE_USER_PROMPT = """
    Create the title based on the following generated text
    # --- START OF GENERATED TEXT ---
    {generated_content}
    # --- END OF GENERATED TEXT ---
    Your suggested title as string:
"""

