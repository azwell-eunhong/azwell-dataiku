from common.solutions.prompts.conversation_title import TITLE_USER_PROMPT
from langchain.prompts import ChatPromptTemplate


#TODO delete this class once not used in AC
class ConversationTitleChainHandler:
    def __init__(self, system_prompt: str):
        self.chain = None

        self._prompt = ChatPromptTemplate.from_messages([("system", system_prompt), ("user", TITLE_USER_PROMPT)])

    def get_prompt(self) -> ChatPromptTemplate:
        return self._prompt
