class UISettingsService:
    @staticmethod
    def get_ui_settings():
        """
        Retrieve UI settings.
        Mocked for now but will come from webapp.json.
        """
        return {
            "language": "en",
            "theme": "dark",
            "logoFileName": "logo.png",
            "iconFileName": "icon.ico",
            "inputPlaceholder": "Enter text here",
            "fontSize": "medium"
        }