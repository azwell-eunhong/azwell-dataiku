import copy
import os
from typing import List, Union

from common.backend.models.base import RAGImage, Source
from common.backend.utils.llm_utils import logger
from requests import HTTPError


def get_rag_images_full_data(images: Union[List[RAGImage], List[str]]) -> List[RAGImage]:
    if not isinstance(images, List): # avoid to break if images is None or other.
        return []
    is_legacy = True
    try:
        logger.debug("Importing ImageRetrieval from dataiku.langchain.document_handler")
        from dataiku.langchain.document_handler import ImageRefPart, ImageRetrieval, InlineImagePart
        is_legacy = False
        def get_image_parts(document_info, full_folder_id, index, image_retrieval):
            parts = []
            image_cache = {}
            for image_path in document_info["content"]:
                if image_retrieval == ImageRetrieval.IMAGE_REF:
                    parts.append(ImageRefPart(index, full_folder_id, image_path))
                    continue

                if image_path in image_cache:
                    parts.append(InlineImagePart(index, image_cache[image_path][0], image_cache[image_path][1]))
                else:
                    try:
                        from dataiku.core import intercom

                        project_key, lookup = full_folder_id.split(".", 1)
                        download_response = intercom.backend_api_get_call(
                            "managed-folders/download-path?projectKey=" + project_key + "&lookup=" + lookup + "&path=" + image_path, None)
                        mime_type = "image/" + os.path.splitext(image_path)[1][1:]
                        image_cache[image_path] = [download_response.content, mime_type]
                        parts.append(InlineImagePart(index, download_response.content, mime_type))
                    except HTTPError as e:
                        logger.warning("Error when retrieving file {image_path} in folder {folder_id} : {err_msg}"
                                        .format(image_path=image_path,
                                                folder_id=full_folder_id,
                                                err_msg=str(e)),
                                        )
            return parts
    except ImportError:
        logger.debug(
            "Importing ImageRetrieval from from dataiku.langchain.document_handler failed, falling back to default import"
        )
        from dataiku.langchain.metadata_handler import ImageRetrieval, MetadataHandler
        is_legacy = True

    output: List[RAGImage] =  []
    for image in images:
        if isinstance(image, dict):
            document_info = {"content": image.get("file_path")}
            full_folder_id = image.get("full_folder_id")
            index = image.get("index")
            image_retrieval = ImageRetrieval.IMAGE_INLINE
            if is_legacy:
                parts = MetadataHandler._get_image_parts(document_info, full_folder_id, index, image_retrieval)
            else:
                parts = get_image_parts(document_info, full_folder_id, index, image_retrieval)
            if parts and len(parts) > 0:
                image_copy = copy.deepcopy(image)
                image_copy["file_data"] = f"data:image/png;base64,{parts[0].inline_image}"
                output.append(image_copy)
                # Shouldn't happend
                for part in parts[1:]:
                    output.append({"file_data": f"data:image/png;base64,{part.inline_image}"})
        else:
            # Here we handle legacy
            output.append({"file_data": image})
    return output

def get_sources_to_store(sources: List[Source]) -> List[Source]:
    # Do not store images data in db
    # Only store info of images to be loaded later

    sources_copy: List[Source] = []
    if sources:
        sources_copy = copy.deepcopy(sources) # type: ignore
        for source in sources_copy:
            if source.get("images"):
                for image in source["images"] or []:
                    image.pop("file_data", None)
    return sources_copy
