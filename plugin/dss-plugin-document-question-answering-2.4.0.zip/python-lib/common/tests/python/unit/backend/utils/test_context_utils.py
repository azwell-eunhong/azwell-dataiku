# import datetime
import unittest

# from datetime import datetime
# from unittest.mock import patch

# from common.backend.utils.context_utils import (
#     add_llm_step_trace,
#     clear_main_trace,
#     get_main_trace,
#     get_main_trace_dict,
#     init_user_trace,
#     log_llm_step_trace,
# )

# trace_example = {
#     "type": "span",
#     "begin": 1701000000000 * 1000,
#     "end": 1701000001230 * 1000,
#     "duration": 1230,
#     "name": "TEST_NAME",
#     "children": [],
#     "attributes": {"key": "value"},
#     "inputs": {"messages": [{"role": "system", "text": "example text"}]},
#     "outputs": {"text": "string"},
# }


class TestLLMTracing(unittest.TestCase):
    pass
    # def test_init_user_trace(self):
    #     clear_main_trace()
    #     init_user_trace("TEST_MAIN_TRACE")
    #     trace = get_main_trace()
    #     self.assertIsNotNone(trace)
    #     self.assertEqual(trace.span.get("name", ""), "TEST_MAIN_TRACE")
    #     clear_main_trace()
    #     init_user_trace("TEST_MAIN_TRACE", 999)
    #     trace = get_main_trace()
    #     self.assertTrue(trace._begin_ts == 999)

    # def test_add_llm_step_trace(self):
    #     clear_main_trace()
    #     init_user_trace("TEST_MAIN_TRACE")
    #     add_llm_step_trace(trace_example)
    #     main_trace = get_main_trace()
    #     self.assertEqual(get_main_trace().span.get("name", ""), "TEST_MAIN_TRACE")
    #     children = main_trace.span.get("children", [])
    #     self.assertEqual(len(children), 1)

    #     main_time = main_trace.span.get("begin", None)
    #     self.assertTrue(main_time is not None)
    #     main_time = datetime.fromisoformat(main_time.replace("Z", "+00:00"))
    #     now = datetime.now(tz=main_time.tzinfo)

    #     self.assertTrue(abs((now - main_time).total_seconds()) <= 60)

    # @patch("common.llm_assist.logging.logger.debug")
    # def test_log_llm_step_trace(self, mock_logger):
    #     log_llm_step_trace()
    #     mock_logger.assert_called_once()

    # def test_get_main_trace_dict(self):
    #     clear_main_trace()
    #     init_user_trace("TEST_MAIN_TRACE")
    #     result = get_main_trace_dict("input_message", "output_message")
    #     self.assertEqual(result["inputs"]["messages"][0]["text"], "input_message")
    #     self.assertEqual(result["outputs"]["text"], "output_message")
    #     main_trace = get_main_trace()
    #     main_time = main_trace.span.get("begin", None)
    #     self.assertTrue(main_time is not None)

    #     main_time = datetime.fromisoformat(main_time.replace("Z", "+00:00"))
    #     now = datetime.now(tz=main_time.tzinfo)
    #     self.assertTrue(abs((now - main_time).total_seconds()) <= 60)

