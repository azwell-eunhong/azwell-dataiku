
import unittest

# from unittest.mock import MagicMock, patch

# from common.backend.constants import LLM_API_ERROR
# from common.backend.models.base import ConversationParams
# from common.solutions.chains.docs.doc_extraction_chain import DocumentExtractionChain
# from dataiku.langchain.dku_llm import DKULLM
# from dataikuapi.dss.llm import DSSLLMCompletionQuery, DSSLLMCompletionResponse


class TestGenericAnswersChain(unittest.TestCase):
    pass
    # @patch('common.solutions.chains.generic_answers_chain.handle_response_trace')
    # @patch('common.solutions.chains.generic_answers_chain.is_fallback_enabled')
    # @patch('common.solutions.chains.generic_answers_chain.get_fallback_completion')
    # @patch('common.solutions.chains.generic_answers_chain.get_llm_completion')
    # def test_generic_answers_chain_use_fallback_on_exception(
    #     self,
    #     mock_get_llm_completion,
    #     mock_to_fallback,
    #     mock_is_fallback_enabled,
    #     mock_handle_response_trace,
    # ):
    #     # Arrange
    #     llm = MagicMock(spec=DKULLM)
    #     doc_extraction_chain = DocumentExtractionChain(
    #         llm=llm,
    #         media_summaries=[],
    #         self_service_decision={}
    #     )


    #     mock_is_fallback_enabled.return_value = True

    #     fake_completion = MagicMock(name="OriginalCompletion")
    #     mock_get_llm_completion.return_value = fake_completion

    #     mock_handle_response_trace = MagicMock()

    #     # completion.execute() mocks, error on first call
    #     # then  simulate a reply
    #     first_error = Exception("simulated LLM failure")
    #     fake_json = '{ "some": "value" }'

    #     fallback_response = DSSLLMCompletionResponse({"ok": "ok", "text": fake_json}, text=fake_json)
    #     fake_completion.execute.side_effect = [first_error, fallback_response]
    #     mock_to_fallback.return_value = fake_completion

    #     params = MagicMock(spec=ConversationParams)
    #     completion = MagicMock(spec=DSSLLMCompletionQuery)
    #     completion.llm = llm


    #     # Act
    #     # Using the mangled name to access the private method due to 'name mangling'.
    #     with patch.object(doc_extraction_chain, 'finalize_non_streaming', return_value={'some': 'value'}) as mock_finalize:
    #         result = doc_extraction_chain._GenericAnswersChain__run_non_streaming_query(
    #             params=params,
    #             completion=completion,
    #             answer_context=[],
    #         )

    #         # Assert
    #         self.assertIn({"some": "value"}, result)

    # @patch('common.solutions.chains.generic_answers_chain.handle_response_trace')
    # @patch('common.solutions.chains.generic_answers_chain.is_fallback_enabled')
    # @patch('common.solutions.chains.generic_answers_chain.get_fallback_completion')
    # @patch('common.solutions.chains.generic_answers_chain.get_llm_completion')
    # def test_generic_answers_chain_fails_and_fallback_too(
    #     self,
    #     mock_get_llm_completion,
    #     mock_to_fallback,
    #     mock_is_fallback_enabled,
    #     mock_handle_response_trace,
    # ):
    #     # Arrange
    #     llm = MagicMock(spec=DKULLM)
    #     doc_extraction_chain = DocumentExtractionChain(
    #         llm=llm,
    #         media_summaries=[],
    #         self_service_decision={}
    #     )


    #     mock_is_fallback_enabled.return_value = True 

    #     fake_completion = MagicMock(name="OriginalCompletion")
    #     mock_get_llm_completion.return_value = fake_completion

    #     mock_handle_response_trace = MagicMock()

    #     # completion.execute() mocks, error on first call
    #     # then  simulate a reply
    #     llm_error = Exception("simulated LLM failure")

    #     fake_completion.execute.side_effect = [llm_error, llm_error]
    #     mock_to_fallback.return_value = fake_completion

    #     params = MagicMock(spec=ConversationParams)
    #     completion = MagicMock(spec=DSSLLMCompletionQuery)
    #     completion.llm = llm


    #     # Act
    #     # Using the mangled name to access the private method due to 'name mangling'.
    #     with patch.object(doc_extraction_chain, 'finalize_non_streaming', return_value={'error': 'error_msg'}) as mock_finalize:
    #         result = doc_extraction_chain._GenericAnswersChain__run_non_streaming_query(
    #             params=params,
    #             completion=completion,
    #             answer_context=[],
    #         )

    #         # Assert
    #         self.assertIn({"error": "error_msg"}, result)
    #         mock_finalize.assert_called_with(params, LLM_API_ERROR)