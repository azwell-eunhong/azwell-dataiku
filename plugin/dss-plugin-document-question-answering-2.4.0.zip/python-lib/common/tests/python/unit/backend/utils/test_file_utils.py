
import unittest

from common.backend.utils.file_utils import get_file_mime_type


class TestFileUtils(unittest.TestCase):
    def test_get_file_mime_type(self):
        test_cases = [
            # images
            ("image.png", "image/png"),
            ("photo.jpeg", "image/jpeg"),
            ("graphic.webp", "image/webp"),
            ("animation.gif", "image/gif"),
            
            # documents
            ("document.pdf", "application/pdf"),
            ("report.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
            ("notes.txt", "text/plain"),
            ("data.json", "application/json"),
            ("script.py", "text/x-python"),
            ("page.html", "text/html"),
            ("app.js", "text/javascript"),
            ("readme.md", "text/markdown"),

            # weird things
            ("file_with_no_extension", None), 
            ("strange.name.with.many.dots.tar.gz", "application/x-tar"), 
            ("UPPERCASE.TXT", "text/plain"), 
            ("weird&name@file!.html", "text/html"), 
        ]

        # Collect failed cases to report all MIME type mismatches at once.

        failed_cases = []

        for file_name, expected_mime_type in test_cases:
            mime_type = get_file_mime_type(file_name)
            if mime_type != expected_mime_type:
                failed_cases.append((file_name, mime_type, expected_mime_type))

        if failed_cases:
            error_messages = [
                f"File '{file_name}' returned MIME type '{mime_type}' but expected '{expected_mime_type}'."
                for file_name, mime_type, expected_mime_type in failed_cases
            ]
            self.fail("\n".join(error_messages))