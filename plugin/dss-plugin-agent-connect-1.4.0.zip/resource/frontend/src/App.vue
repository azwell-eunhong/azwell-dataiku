<template><RouterView></RouterView></template>

<script lang="ts">
import { RouterView } from "vue-router";
import { ServerApi } from "@/api/server_api";
import { WebSocketApi } from "@/api/websocket_api";

export default {
    data() {
        return {
            answer: "",
        };
    },
    async created() {
        let dataikuLib;
        try {
            /* eslint-disable @typescript-eslint/ban-ts-comment */
            // @ts-ignore
            // eslint-disable-next-line no-undef
            dataikuLib = dataiku;
        } catch (e) {
            dataikuLib = undefined;
        }
        let host = "";
        const isLocal = !dataikuLib;
        if (!isLocal) {
            await (async () => {
                while (!dataikuLib?.getWebAppBackendUrl) {
                    await new Promise((resolve) => setTimeout(resolve, 1000));
                }
                host = dataikuLib.getWebAppBackendUrl("/");
                WebSocketApi.init("/", host.replace("http", "ws"));
            })();
        } else {
            const apiPort = import.meta.env.VITE_API_PORT;
            const LOCAL_BACKEND_URL = `http://127.0.0.1:${apiPort}`;
            host = LOCAL_BACKEND_URL;

            WebSocketApi.init(LOCAL_BACKEND_URL, "/");
        }
        ServerApi.init({ host });
    },
    components: {
        RouterView,
    },
    beforeUnmount() {
        console.debug("closing websocket");
        WebSocketApi.close();
    },
    methods: {},
};
</script>
