import installApp from "./install-lib"
const version = __UI_VERSION__

export default {
  version: version,
  install: installApp,
}
