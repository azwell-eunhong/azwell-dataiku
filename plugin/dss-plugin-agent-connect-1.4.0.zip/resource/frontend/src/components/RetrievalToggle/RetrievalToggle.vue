<template>
  <div
    class="row bs-font-medium-3-semi-bold kb-toggle-container use-knowledge-bank-label"
    v-if="isRetrievalActivated"
  >
    <div class="flex-row items-center no-wrap use-kb-label use-db-label">
      <q-icon
        v-if="retrievalType === RetrievalMode.KB"
        size="24px"
        color="primary"
      >
        <KbIcon color="currentColor" />
      </q-icon>
      <q-icon
        v-if="retrievalType === RetrievalMode.DB"
        size="24px"
        color="primary"
      >
        <DbIcon color="currentColor" />
      </q-icon>
      <span class="all-title bs-font-medium-3-normal">
        {{ !label ? defaultLabel : $t('use') + ' ' + label }}
      </span>
    </div>
    <QToggle
      class="use-knowledge-bank-toggle use-db-toggle"
      :model-value="modelValue"
      @update:model-value="(value) => $emit('update:modelValue', value)"
    ></QToggle>
  </div>
</template>
<script setup lang="ts">
import { QToggle } from 'quasar'
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'
import DbIcon from '@/components/icons/DbIcon.vue'
import KbIcon from '@/components/icons/KbIcon.vue'
import { useUI } from '@/composables/useUI'
import { RetrievalMode } from '@/models'
const { setup } = useUI()
const { t } = useI18n()

const props = defineProps<{
    modelValue: boolean
    retrievalType: RetrievalMode | null
    label: string
  }>()

defineEmits<{
    (e: 'update:modelValue', value: boolean): void
  }>()

const defaultLabel = computed(() => {
  return props.retrievalType == RetrievalMode.KB
    ? t('use_knowledge_bank')
    : props.retrievalType == RetrievalMode.DB
      ? t('use_dataset')
      : ''
})
const isRetrievalActivated = computed(() => {
  return setup.value.retrievalMode !== RetrievalMode.NO_RETRIEVER
})
</script>
<style scoped>
  .use-kb-label {
    padding-bottom: 4px;
    gap: 4px;
  }
</style>
