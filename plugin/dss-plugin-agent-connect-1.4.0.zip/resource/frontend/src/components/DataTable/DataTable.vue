<template>
  <div class="q-pa-xs">
    <BsTable
      :title="title"
      :rows="rows"
      :columns="columns"
      row-key="name"
      :globalSearch="false"
      :stickyHeader="false"
    />
  </div>
</template>
<script setup lang="ts">
  import { BsTable } from 'quasar-ui-bs'
  defineProps<{
    title?: string
    columns: Record<string, any>[]
    rows: Record<string, any>[]
  }>()
</script>
<style lang="scss" scoped>
  :deep(.bs-table-top-container) {
    display: none !important;
  }
  :deep(.bs-table-search-container) {
    display: none !important;
  }
</style>
