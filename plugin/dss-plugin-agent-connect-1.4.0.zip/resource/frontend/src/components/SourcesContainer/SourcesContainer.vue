<template>
  <q-expansion-item
    :label="$t('sources')"
    v-model="expanded"
    header-class="expansion-item"
    switch-toggle-side
    class="sources-expansion-item"
    :id="`query_${queryIndex}_sources`"
  >
    <div class="source-item">
      <div
        v-for="(source, index) in sources"
        :key="index"
        v-if="sources.length > 0"
      >
        <AgentName :name="source.name" :isAgent="source.type === 'agent'" />
        <div
          v-if="source.answer && displayAgentsAnswers"
          v-md="{
            content: source.answer,
            translations: { copy_code: 'copy' },
            queryIndex: index
          }"
          ref="agentAnswer"
          class="source-content agent-answer"
        ></div>
        <div
          class="source-step"
          v-for="(step, sourceIndex) in source.items"
          :key="sourceIndex"
        >
          <div class="row items-center q-gutter-x-xs source-tool">
            <img
              :src="ToolIcon"
              width="16"
              height="16"
              style="margin-top: 2px; margin-right: 2px"
            />
            {{ step.toolCallDescription }}
          </div>
          <div
            v-for="(item, toolSourceIndex) in step.items"
            :key="index"
            class="source-text"
          >
            <div
              class="source-meta"
              :id="`meta_${queryIndex}_source_${toolSourceIndex}`"
            >
              <img
                class="source-thumbnail"
                :src="item.metadata.source_thumbnail_url"
                v-if="item.metadata?.source_thumbnail_url"
              />
              <div>
                <span>{{ `${toolSourceIndex + 1}. ` }} </span>
                <span v-if="getUrl(item)">
                  <a :href="getUrl(item)" target="_blank" class="source-link">
                    <span class="source-title">{{ item.title }}</span>
                  </a>
                </span>
              </div>
              <div
                v-if="item.images && item.images.length"
                class="source-images"
              >
                <img
                  v-for="(img, imgIndex) in item.images"
                  :key="imgIndex"
                  :src="img.file_data"
                  class="source-image"
                  @click="openLightbox(img.file_data)"
                />
              </div>
            </div>
            <div
              v-if="item.records && item.records.columns"
              :id="`query_${queryIndex}_source_${toolSourceIndex}`"
              class="source-content"
            >
              <div v-if="displaySqlQuery && item.generatedSqlQuery">
                <div class="source-query-container">
                  <span class="source-sql-query"> {{ $t('sql_query') }} </span>
                  <br />
                  <span class="source-query">
                    {{ item.generatedSqlQuery }}
                  </span>
                </div>
              </div>
              <!-- TODO agents records are diff: have data + columns -->
              <DataTable
                :rows="item.records.rows"
                :columns="item.records.columns"
                v-if="item.records.rows"
              ></DataTable>
            </div>
            <div
              v-else-if="item.textSnippet && displaySourceChunks"
              v-md="{
                content: item.textSnippet,
                translations: { copy_code: 'copy' },
                queryIndex: queryIndex
              }"
              ref="sourceContent"
              class="source-content"
            ></div>
          </div>
        </div>
      </div>
    </div>
    <transition name="lightbox-zoom">
      <div v-if="lightboxImage" class="lightbox-overlay" @click="closeLightbox">
        <img :src="lightboxImage" class="lightbox-image" />
      </div>
    </transition>
  </q-expansion-item>
</template>

<script setup lang="ts">
  import AgentName from '@/components/SourcesContainer/AgentName.vue'
  import DataTable from '@/components/DataTable/DataTable.vue'
  import { useUI } from '@/composables/useUI'
  import ToolIcon from '@/assets/icons/icon-agent-tool-plugin.svg'
  const { setup } = useUI()

  import { ref, computed, onMounted, onBeforeUnmount } from 'vue'

  const props = defineProps({
    sources: {
      type: Array,
      required: true
    },
    queryIndex: {
      type: Number,
      required: true
    }
  })

  const expanded = ref(false)
  const displaySqlQuery = computed(() => {
    return setup.value.sourcesConfig?.displaySqlQuery
  })
  const displaySourceChunks = computed(() => {
    return setup.value.sourcesConfig?.displayChunks
  })
  const displayAgentsAnswers = computed(() => {
    return (
      setup.value.sourcesConfig?.displayAgentsAnswers &&
      props.sources &&
      props.sources.length > 1
    )
  })

  const lightboxImage = ref<string | null>(null)

  const openLightbox = (imgUrl: string) => {
    lightboxImage.value = imgUrl
  }

  const closeLightbox = () => {
    lightboxImage.value = null
  }
  const getUrl = (item) => item.url || null

  const handleExpandSource = (info) => {
    expanded.value = true
    setTimeout(() => {
      const href = displaySourceChunks.value
        ? `#query_${props.queryIndex}_source_${info['sourceIndex']}`
        : `#meta_${props.queryIndex}_source_${info['sourceIndex']}`
      const targetElement = document.querySelector(href)
      if (targetElement) {
        targetElement.scrollIntoView({
          behavior: 'smooth',
          block: 'nearest',
          inline: 'start'
        })
      }
    }, 200)
  }

  const expandEventHandler = (event) => {
    handleExpandSource(event.detail)
  }

  onMounted(() => {
    const element = document.getElementById(`query_${props.queryIndex}_sources`)
    element?.addEventListener('expandSource', expandEventHandler)
  })

  onBeforeUnmount(() => {
    const element = document.getElementById(`query_${props.queryIndex}_sources`)
    element?.removeEventListener('expandSource', expandEventHandler)
  })
</script>

<style scoped>
  :deep(.q-item) {
    padding: 4px;
  }
  :deep(.q-item__section--side > .q-icon) {
    font-size: 16px;
  }
  .expansion-item {
    font-weight: 600;
    font-size: 20px;
    line-height: 15px;
    color: #666;
    width: 100%;
  }
  .sources-expansion-item {
    margin-top: 8px;
    font-size: 12px;
    font-weight: bold;
    color: #444;
    max-width: 90%;
  }
  .source-item {
    margin-top: 5px;
    margin-bottom: 5px;
  }
  .source-step {
    margin-bottom: 16px;
  }
  .source-tool {
    margin-top: 4px;
  }
  .source-text {
    font-style: normal;
    font-weight: 400;
    font-size: 11px;
    line-height: 16px;
    color: #444;
    margin-bottom: 16px;
    margin-left: 4px;
    border-left: 1px solid #929292;
    word-wrap: break-word;
    overflow-wrap: break-word;
    overflow: hidden; /* Prevents overflowing */
    white-space: pre-wrap;
  }
  .agent-answer {
    font-weight: 400;
    color: #444;
  }
  .source-content {
    word-wrap: break-word;
    overflow-wrap: break-word;
    padding-left: 6px;
    overflow: hidden;
    max-width: 100%; /* Ensures it doesn't exceed parent container */
    padding-left: 6px;
    margin-right: 6px;
    white-space: normal; /* Override if necessary */
  }
  .source-meta {
    display: inline-flex;
    gap: 10px;
    word-wrap: break-word;
    padding-left: 6px;
  }
  .source-link {
    color: #444;
    font-weight: 500;
  }
  .source-thumbnail {
    width: 100px;
    height: 60px;
  }
  .source-query-container {
    padding-bottom: 8px;
  }
  .source-query {
    font-size: 12px;
  }
  .source-sql-query {
    font-weight: bold;
  }
  .source-item,
  .sources-expansion-item {
    max-width: 100%;
    overflow: hidden;
  }
  .source-image {
    width: 120px;
    height: auto;
    object-fit: cover;
    margin: 4px 0;
    cursor: zoom-in;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15);
  }

  .source-image:hover {
    transform: scale(1.02);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  }

  .lightbox-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background-color: rgba(0, 0, 0, 0.7);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
    cursor: zoom-out;
  }

  .lightbox-image {
    max-width: 90vw;
    max-height: 90vh;
    object-fit: contain;
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.5);
    border-radius: 4px;
  }

  .lightbox-zoom-enter-active,
  .lightbox-zoom-leave-active {
    transition: opacity 0.3s ease, transform 0.3s ease;
  }
  .lightbox-zoom-enter-from,
  .lightbox-zoom-leave-to {
    opacity: 0;
    transform: scale(0.95);
  }
</style>
