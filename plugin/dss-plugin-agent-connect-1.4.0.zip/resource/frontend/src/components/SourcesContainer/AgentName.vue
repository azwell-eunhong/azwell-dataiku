<template>
  <div
    dense
    no-caps
    class="q-px-sm documentation-btn agent-name"
    style="display: inline-block"
  >
    <div class="row items-center q-gutter-x-xs">
      <img :src="iconName" width="16" height="16" />
      <div class="documentation-btn__title">{{ name }}</div>
    </div>
  </div>
</template>

<script lang="ts">
  import AgentIcon from '@/assets/icons/agent-icon.svg'
  import AnswersIcon from '@/assets/icons/solutions-icon.svg'
  import { defineComponent } from 'vue'
  export default defineComponent({
    name: 'AgentName',
    props: {
      name: { type: String },
      isAgent: { type: Boolean }
    },
    computed: {
      iconName() {
        return this.isAgent ? AgentIcon : AnswersIcon
      }
    }
  })
</script>
<style scoped>
.agent-name:hover {
    background: #FFFFFF !important;
    color: #333e48 !important;
    border-color: #929292 !important;
}
</style>