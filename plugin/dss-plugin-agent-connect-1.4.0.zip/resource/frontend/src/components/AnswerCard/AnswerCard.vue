<template>
  <div class="answer-card q-pa-sm">
    <div class="answer-section column">
      <div class="row no-wrap" style="max-width: 100%">
        <img :src="icon" class="icon-img" @error="imgError = true" />
        <div class="answer-content">
          <div
            class="bs-font-small-2-normal llm-step"
            v-if="!answer && loading"
          >
            <div class="step-name">
              {{ t(step?.toLowerCase()) }}
            </div>
            <div class="dot-flashing"><div></div></div>
          </div>
          <div
            v-else-if="answer || images"
            class="bs-font-medium-3-normal answer-text"
          >
            <div
              v-if="answer"
              v-md="{
                content: answer,
                translations: { copy_code: t('copy_code') },
                queryIndex: props.queryIndex
              }"
              :style="answerStyle"
              ref="answerRef"
            ></div>
            <div class="row images-preview">
              <FilePreview
                v-for="(image, index) in loadedImages"
                v-bind:key="index"
                :uploaded-image="image.file_data ?? ''"
                :file-path="image.file_data ? '' : image.file_path"
                :height="'256px'"
                :width="'256px'"
                style="margin-top: 4px"
                :downloadable="true"
                @loadedFile="(data: string) => appendImageData(index, data)"
                @download="(data:string) => downloadImage(data, image.file_format)"
              ></FilePreview>
            </div>
            <div class="kb_on_off_tag" v-if="kbOn">
              <q-icon size="20px" style="margin-right: 4px">
                <KbIcon color="currentColor" />
              </q-icon>
              <span>{{ t('answer_generated_with_kb') }}</span>
            </div>
            <div class="kb_on_off_tag" v-if="dbOn">
              <q-icon size="20px" style="margin-right: 4px">
                <DbIcon color="currentColor" />
              </q-icon>
              <!-- <span>{{ t('answer_generated_with_db') }} to <b> NAME_OF_TABLE </b> </span> -->
              <span> {{ t('answer_generated_with_db') }} </span>
            </div>
            <div class="kb_on_off_tag" v-if="agentsOn">
              <q-icon size="20px" style="margin-right: 4px">
                <DbIcon color="currentColor" />
              </q-icon>
              <span> {{ t('answer_generated_with_agents') }} </span>
            </div>
            <slot></slot>
          </div>
        </div>
      </div>
      <div
        class="feedback-buttons self-end"
        v-if="(answer || images) && !loading"
      >
        <IconButton
          class="feedback-icon"
          @click="copyAnswer"
          v-if="answer"
          tooltip="tooltip_copy"
          size="xs"
          ><CopyIcon
        /></IconButton>

        <IconButton
          class="feedback-icon"
          id="feedback-icon"
          @click="downloadImages(loadedImages)"
          v-if="loadedImages && loadedImages.length"
          tooltip="tooltip_download_images"
          size="xs"
        >
          <DownloadIcon />
        </IconButton>

        <IconButton
          class="feedback-icon"
          v-if="!isNegativeFeedback"
          tooltip="tooltip_thumbs_up"
          size="xs"
        >
          <ThumbsUp :active="isPositiveFeedback" />
          <FeedbackProxyPopup
            v-if="!submitted"
            :feedback-value="FeedbackValue.POSITIVE"
            :feedback-options="feedbackOptionsPositive"
            :submit-on-hide="true"
            @save="(value) => submitFeedback(value)"
          />
        </IconButton>

        <IconButton
          class="feedback-icon"
          v-if="!isPositiveFeedback"
          tooltip="tooltip_thumbs_down"
          size="xs"
        >
          <ThumbsDown :active="isNegativeFeedback" />
          <FeedbackProxyPopup
            v-if="!submitted"
            :feedback-value="FeedbackValue.NEGATIVE"
            :feedback-options="feedbackOptionsNegative"
            :submit-on-hide="false"
            @save="(value) => submitFeedback(value)"
          />
        </IconButton>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>
  import { isEqual } from 'lodash'
  import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
  import { useI18n } from 'vue-i18n'
  import AnswerIcon from '@/assets/icons/answer-icon.svg'
  import { getCustomImagePath } from '@/common/utils'
  import FeedbackProxyPopup from '@/components/FeedbackProxyPopup/FeedbackProxyPopup.vue'
  import FilePreview from '@/components/FilePreview/FilePreview.vue'
  import IconButton from '@/components/IconButton/IconButton.vue'
  import CopyIcon from '@/components/icons/CopyIcon.vue'
  import DbIcon from '@/components/icons/DbIcon.vue'
  import DownloadIcon from '@/components/icons/DownloadIcon.vue'
  import KbIcon from '@/components/icons/KbIcon.vue'
  import ThumbsDown from '@/components/icons/ThumbsDown.vue'
  import ThumbsUp from '@/components/icons/ThumbsUp.vue'
  import { useClipboard } from '@/composables/useClipboard'
  import { useUI } from '@/composables/useUI'
  import type { GeneratedMedia, LLLMStep, Feedback } from '@/models'
  import { FeedbackValue } from '@/models'

  const { isCopySupported, copyToClipboard } = useClipboard()

  const { t } = useI18n()
  const { setup } = useUI()
  const props = defineProps<{
    answer: string
    kbOn: boolean | undefined
    dbOn: boolean | undefined
    agentsOn: boolean | undefined
    feedback: Feedback | null
    typingEffectOn: boolean
    errorState: boolean
    feedbackOptionsNegative: string[]
    feedbackOptionsPositive: string[]
    loading: boolean
    queryIndex: number
    step: string | LLLMStep.LOADING
    images: GeneratedMedia[] | undefined
  }>()

  const emits = defineEmits<{
    (e: 'update:feedback', feedback: Feedback): void
    (
      e: 'expandSource',
      info: { sourceIndex: string; citationIndex: string; queryIndex: string }
    ): void
  }>()
  const answerRef = ref<HTMLElement>()
  const imgError = ref(false)
  const icon = computed(() => {
    if (setup.value.useCustomRebranding) {
      const fileName = setup.value.customIconFileName
        ? setup.value.customIconFileName
        : ''
      return getCustomImagePath(
        fileName,
        AnswerIcon,
        setup.value.customThemeName,
        imgError.value
      )
    } else {
      return AnswerIcon
    }
  })
  const isNegativeFeedback = computed(() => {
    return props.feedback && props.feedback.value === FeedbackValue.NEGATIVE
      ? true
      : false
  })

  const isPositiveFeedback = computed(() => {
    return props.feedback && props.feedback.value === FeedbackValue.POSITIVE
      ? true
      : false
  })

  const submitted = computed(() => {
    return isNegativeFeedback.value || isPositiveFeedback.value
  })
  const answerStyle = computed(() => {
    return {
      color: props.answer == t('error_answer') ? 'red' : ''
    }
  })

  const copied = ref<boolean>(false)
  async function copyAnswer() {
    if (!isCopySupported.value) return
    const isCopied = await copyToClipboard(props.answer)
    if (!isCopied) return
    copied.value = true
  }
  const loadedImages = ref(props.images)
  const appendImageData = (index: number, imageData: string): void => {
    if (loadedImages.value) {
      loadedImages.value[index].file_data = imageData
    }
  }
  const downloadImages = (images: GeneratedMedia[]): void => {
    for (const image of images) {
      if (image.file_data) {
        downloadImage(image.file_data, image.file_format)
      }
    }
  }

  const downloadImage = (imageData: string, fileFormat: string): void => {
    const link = document.createElement('a')
    link.href = imageData
    link.download = 'dku_generated_image.' + fileFormat
    link.click()
  }
  const submitFeedback = (feedback: Feedback) => {
    if (!isEqual(feedback, props.feedback)) {
      emits('update:feedback', feedback)
    }
  }
  const addWindowFunctions = () => {
    if (!(window as any).dkuAnswers_copyToClipboard) {
      ;(window as any).dkuAnswers_copyToClipboard = (element: Element) => {
        const code = decodeURIComponent(
          element.getAttribute('data-clipboard-text') ?? ''
        )
        if (!isCopySupported.value) return
        copyToClipboard(code)
      }
    }
    if (!(window as any).dkuAnswers_handleCitationClick) {
      ;(window as any).dkuAnswers_handleCitationClick = (
        citationIndex: number,
        sourceIndex: string,
        queryIndex: number
      ) => {
        // Create a new CustomEvent
        const expandSourceEvent = new CustomEvent('expandSource', {
          detail: {
            sourceIndex: sourceIndex,
            citationIndex: citationIndex.toString(),
            queryIndex: props.queryIndex.toString()
          }
        })
        const element = document.querySelector(`#query_${queryIndex}_sources`)
        // Dispatch the event on the desired element
        element?.dispatchEvent(expandSourceEvent)
      }
    }
    if (!(window as any).dkuAnswers_showHideQuote) {
      ;(window as any).dkuAnswers_showHideQuote = (
        elementId: string,
        show: boolean
      ) => {
        const popup = document.getElementById(elementId)
        if (!popup) return
        const content = popup.children.item(0) as HTMLElement
        if (content) {
          const position = popup.getBoundingClientRect()
          if (position) {
            // position the popup below the citation: 24px below the top of the citation
            content.style.setProperty('top', `${position.top + 24}px`)
          }
          if (show) {
            content.classList.add('show')
          } else {
            content.classList.remove('show')
          }
        }
      }
    }
  }
  onMounted(() => {
    addWindowFunctions()
  })

  function cleanup() {
    // Remove global event handlers from the window object
    if ((window as any).dkuAnswers_handleCitationClick) {
      delete (window as any).dkuAnswers_handleCitationClick
    }

    if ((window as any).dkuAnswers_showHideQuote) {
      delete (window as any).dkuAnswers_showHideQuote
    }
    if ((window as any).dkuAnswers_copyToClipboard) {
      delete (window as any).dkuAnswers_copyToClipboard
    }
  }
  onBeforeUnmount(() => {
    cleanup()
  })
</script>

<style lang="scss" scoped>
  .images-preview {
    gap: 16px;
  }
  .answer-card {
    max-width: 95%;
    width: auto;
    background: white; //rgba(230, 247, 246, 0.6);
    border-radius: 6px;
    padding: 8px;
    align-self: flex-start;
  }

  .answer-section {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    max-width: 100%;
  }
  .icon-img {
    width: 24px;
    height: 24px;
    align-self: baseline;
    margin-right: 8px;
  }
  .answer-content {
    flex-grow: 1;
    word-wrap: break-word;
    overflow: hidden;
    /* Prevents overflowing */
  }
  .llm-step {
    color: #666;
    display: inline-flex;
  }
  .answer-content *:not(div):not(code) {
    white-space: normal;
    margin-bottom: 0px;
  }
  .answer-content #code-wrapper div:not(.exclude) {
    white-space: pre-line;
  }

  .feedback-buttons {
    display: flex;
    color: #6666;
  }

  .feedback-icon.active {
    color: var(--brand);
  }

  .feedback-icon,
  .copy-icon {
    margin-right: 8px;
    cursor: pointer;
    align-self: flex-start;
  }

  .answer-text {
    max-width: 100%;
    color: #444;
    margin-bottom: 6px;
  }

  .blinking-cursor {
    display: inline-block;
    width: 6px;
    height: 20px;
    background-color: #444444;
    animation: blink 0.8s infinite;
  }

  .kb_on_off_tag {
    margin-top: 8px;
    color: #666;
  }

  @keyframes blink {
    0%,
    100% {
      opacity: 0;
    }

    50% {
      opacity: 1;
    }
  }
  .step-name {
    animation: dotFlashing 1.5s infinite alternate;
  }
  .answer-text a {
    color: var(--brand);
    text-decoration: none;
    transition: color 0.3s ease;
  }

  .answer-text a:hover {
    color: var(--brand);
    text-decoration: underline;
  }

  @media (max-width: 767px) {
    .answer-card {
      max-width: 90%;
    }
  }

  :deep(code) {
    white-space: break-spaces;
  }

  div.citation {
    display: inline-block;
  }

  div.markdown {
    display: inline;
  }
  .dot-flashing {
    display: inline-block;
    position: relative;
    width: 3em;
    height: 0.7em;
    vertical-align: baseline;
    align-self: end;
  }

  .dot-flashing::before,
  .dot-flashing::after,
  .dot-flashing div {
    content: '';
    position: absolute;
    width: 0.3em;
    height: 0.3em;
    margin: 0 0.3em;
    border-radius: 50%;
    background-color: currentColor;
    animation: dotFlashing 1.5s infinite alternate;
    vertical-align: baseline;
  }

  .dot-flashing::before {
    left: 0;
    animation-delay: 0s;
  }

  .dot-flashing div {
    left: 0.7em;
    animation-delay: 0.2s;
  }

  .dot-flashing::after {
    left: 1.4em;
    animation-delay: 0.4s;
  }

  @keyframes dotFlashing {
    0% {
      opacity: 1;
    }
    50%,
    100% {
      opacity: 0.5;
    }
  }
</style>
<style>
  .code-wrapper {
    background-color: #282c34;
    border-radius: 4px;
    color: #f8f8f8;
    font-family: 'Courier New', Courier, monospace;
    word-wrap: break-word;
    overflow-x: hidden;
    max-width: 100%;
    font-size: 14px;
    margin: 8px 0px;
  }

  .code-container {
    padding: 8px;
    word-wrap: break-word;
    overflow-x: auto;
    white-space: pre-wrap;
    max-width: 100%;
  }

  :not(pre) > code[class*='language-'],
  pre[class*='language-'] {
    background-color: #282c34;
  }

  .header {
    padding: 8px;
    width: 100%;
    background-color: #202123;
  }

  .copy {
    cursor: pointer;
  }

  .copy-text {
    color: var(--greyscale-grey-lighten-4, #999);
  }

  .citation-popup {
    /* position: relative; */
    display: inline-block;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    color: var(--q-primary);
  }

  .citation-quote-popup {
    visibility: hidden;
    max-width: 400px;
    padding: 8px;
    background-color: white;
    color: #555;
  }

  /* Toggle this class - hide and show the popup */
  .citation-popup .show {
    visibility: visible;
    -webkit-animation: fadeIn 0.5s;
    animation: fadeIn 0.5s;
  }

  /* Add animation (fade in the popup) */
  @-webkit-keyframes fadeIn {
    from {
      opacity: 0;
    }

    to {
      opacity: 1;
    }
  }

  @keyframes fadeIn {
    from {
      opacity: 0;
    }

    to {
      opacity: 1;
    }
  }
  /* .dot-flashing {
    display: inline-block;
  }

  .dot-flashing::before,
  .dot-flashing::after,
  .dot-flashing::after {
    content: '';
    display: inline-block;
    width: 0.8em;
    height: 0.8em;
    margin: 0 0.1em;
    border-radius: 50%;
    background-color: currentColor;
    animation: dotFlashing 1s infinite alternate;
  }

  .dot-flashing::before {
    animation-delay: 0s;
  }

  .dot-flashing::after {
    animation-delay: 0.2s;
  }

  .dot-flashing::after {
    animation-delay: 0.4s;
  }

  @keyframes dotFlashing {
    0% {
      opacity: 1;
    }
    50%,
    100% {
      opacity: 0.3;
    }
  } */
</style>
