<template>
  <div v-if="settings.media">
    <div class="all-title bs-font-medium-2-semi-bold user-settings-image">
      {{ t('image_generation_settings') }}
    </div>
    <bs-warning
      type="info"
      :text="t('image_generation_settings_disclaimer')"
      :closable="true"
      class="user-settings-image"
    >
    </bs-warning>
    <div
      class="flex-row items-center no-wrap user-settings-image image-model-label"
    >
      <span class="all-title bs-font-medium-3-normal setting-key">
        {{ t('image_generation_model') }}
        <q-icon name="info" class="cursor info-icon">
          <BsTooltip
            class="bs-tooltip"
            anchor="top middle"
            self="bottom middle"
          >
            {{ t('image_generation_model_tooltip') }}</BsTooltip
          >
        </q-icon>
      </span>
      <span class="all-title bs-font-medium-3-normal setting-value">
        {{ model }}
      </span>
    </div>
    <div
      class="flex-row items-center no-wrap user-settings-image"
      v-if="maxImagesPerWeek"
    >
      <span class="all-title bs-font-medium-3-normal setting-key">
        {{ t('max_images_per_week') }}
        <q-icon name="info" class="cursor info-icon">
          <BsTooltip
            class="bs-tooltip"
            anchor="top middle"
            self="bottom middle"
          >
            {{ t('max_images_per_week_tooltip') }}</BsTooltip
          >
        </q-icon>
      </span>
      <span class="all-title bs-font-medium-3-normal setting-value">
        <b>{{ quotaLabel }}</b>
        {{ nextResetInDaysHours.length ? t('until') : '' }}
        <b>{{ nextResetInDaysHours }}</b>
      </span>
    </div>
    <div
      v-for="(value, key) in settings.media.image"
      v-bind:key="key"
      class="flex-row items-center no-wrap user-settings-image"
    >
      <div class="all-title row bs-font-medium-3-normal setting-key">
        {{ t(key) }}
        <q-icon name="info" class="cursor info-icon">
          <BsTooltip
            class="bs-tooltip"
            anchor="top middle"
            self="bottom middle"
          >
            {{ t(value.description) }}</BsTooltip
          >
        </q-icon>
      </div>
      <bs-select
        class="bs-font-medium-3-normal setting-value"
        :model-value="value.value"
        :all-options="value.options"
        :clearable="value.clearable"
        @update:model-value="(value: string) => updateSettings('media.image.'+key, value)"
      ></bs-select>
    </div>
  </div>
</template>
<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { updateObject } from '@/common/utils'
import BsWarning from '@/components/BsWarning/BsWarning.vue'
import { useUI } from '@/composables/useUI'
const { t } = useI18n()
const { setup } = useUI()
const props = defineProps<{
    settings: Record<string, any>
  }>()
const model = computed(() => {
  return setup.value.imageGenerationLLMId
    ? setup.value.imageGenerationLLMId.split(':')[2]
    : ''
})
const maxImagesPerWeek = computed(() => {
  return setup.value.maxImagesToGenerate
})
const numImagesLeft = computed(() => {
  if (!maxImagesPerWeek.value) return 0
  if (
    props.settings.generated_media_info &&
      props.settings.generated_media_info.image
  ) {
    if (!nextResetInDaysHours.value.length) return maxImagesPerWeek.value
    const numGenerated = props.settings.generated_media_info.image['count']
    return maxImagesPerWeek.value - numGenerated
  }
  return maxImagesPerWeek.value
})
const quotaLabel = computed(() => {
  if (!maxImagesPerWeek.value) return ''
  return `${Math.max(numImagesLeft.value, 0)} ${t('images_left_of')} ${
    maxImagesPerWeek.value
  }`
})
const nextResetInDaysHours = computed(() => {
  if (!maxImagesPerWeek.value || !props.settings.generated_media_info)
    return ''
    // Calculate next reset time in days and hours
    // (e.g., Next week from the first generation within a week)
  const firstGeneration = Math.floor(
    props.settings.generated_media_info.image['first_generated_at']
  )
  const hoursInS = 60 * 60
  const dayInS = hoursInS * 24
  const currentTime = Math.floor(Date.now() / 1000)
  const elapsedTime = currentTime - firstGeneration
  if (elapsedTime >= 7 * dayInS) return ''
  const timeUntilNextReset = 7 * dayInS - (elapsedTime % (7 * dayInS))
  // Convert time to days and hours
  const days = Math.floor(timeUntilNextReset / dayInS)
  const hours = Math.floor((timeUntilNextReset % dayInS) / hoursInS)
  return `${days}${t('days')} ${hours > 0 ? `${hours}${t('hours')}` : ''}`
})
const emits = defineEmits<{
    (e: 'update:settings', value: any): void
  }>()
const updateSettings = (key: string, value: string | number | null) => {
  const newSettings = updateObject(props.settings, key, value)
  emits('update:settings', newSettings)
}
</script>
<style lang="scss" scoped>
  .user-settings-image {
    margin-bottom: 10px;
  }
  .setting-key {
    width: 50%;
  }
  .setting-value {
    width: 50%;
  }
  .info-icon {
    align-self: center;
    padding-left: 2px;
  }
</style>
