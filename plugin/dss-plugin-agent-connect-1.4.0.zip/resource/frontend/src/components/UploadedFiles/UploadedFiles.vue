<template>
  <div class="files">
    <div
      class="row bs-font-medium-3-normal file"
      v-for="(file, index) in files"
      :key="index"
    >
      <div style="max-width: 155px">
        <BSTruncatedText :tooltip-content="file"> {{ file }}</BSTruncatedText>
      </div>
      <q-icon
        name="close"
        class="cursor-pointer"
        @click="closeTag(index)"
        style="padding-top: 2px"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
  import { defineProps, defineEmits } from 'vue'
  import BSTruncatedText from '@/components/BsTruncatedText/BsTruncatedText.vue'
  defineProps<{
    files: string[]
  }>()

  const emits = defineEmits(['close'])
  const closeTag = (index: number) => {
    emits('close', index)
  }
</script>

<style lang="scss" scoped>
  .files {
    display: flex;
    flex-wrap: wrap;
    padding: var(--bs-spacing-0, 0px);
    align-items: center;
    gap: var(--bs-spacing-1, 4px);
  }

  .file {
    border-radius: 4px;
    background: var(--bg-examples-borders);
    padding: var(--bs-spacing-05, 2px) 8px;
    max-width: 200px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-height: 32px;
    cursor: pointer;
    transition: max-height 0.3s ease;
    align-items: center;
    gap: 10px;
  }
</style>
