<template>
  <div class="summary-card" :class="{ deleted: summary.is_deleted }">
    <q-card v-if="summary" flat>
      <q-card-section class="summary-card-section">
        <q-img
          v-if="summary.preview"
          id="summary-file-preview"
          :src="summary.preview"
          class="float-right q-mb-sm media-preview"
        />
        <q-icon
           v-else-if="summary.is_deleted"
          :name="FileRemoveIconName"
          class="float-right q-mb-sm media-preview"
        ></q-icon>
        <q-icon v-else :name="TextFileIconName" class="float-right q-mb-sm media-preview"></q-icon>
        <q-card-section
          class="text-h6 summary-card-title summary-card-section"
          :class="{ deleted: summary.is_deleted }"
        >
        {{ t('summary') }}: {{ summary.original_file_name }}
        </q-card-section>
        <q-card-section id="summary-text" class="q-mt-sm q-py-none summary-card-section">
          <div v-if="summary.summary" class="text-body">
            {{ summary.summary }}
          </div>
        </q-card-section>
      </q-card-section>
      <q-card-section
        id="summary-topics"
        class="q-my-sm q-py-none summary-card-section"
        v-if="summary.topics"
      >
        <div class="bs-font-medium-2-semi-bold">{{ t('key_topics') }}</div>
        <span
          v-for="(topic, index) in summary.topics"
          :key="index"
          class="q-mr-sm q-mt-sm q-ml-none key-topic"
        >
          {{ topic }}{{ index < summary.topics!.length - 1 ? ',' : '' }}
        </span>
      </q-card-section>
    </q-card>

    <div class="grid no-wrap questions">
      <InfoCard
        :id="`summary-question-${idx}`"
        v-for="(question, idx) in summary.questions"
        :text="question"
        style="cursor: pointer"
        :key="idx"
        @click="emits('question', question)"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
  import { useI18n } from 'vue-i18n'
  import TextFileIcon from '@/assets/icons/text-file-icon.svg'
  import InfoCard from '@/components/InfoCard/InfoCard.vue'
  import type { MediaSummary } from '@/models/index'
  import FileRemoveIcon from '@/assets/icons/file-remove-icon.svg'

  const { t } = useI18n()

  const TextFileIconName = `img:${TextFileIcon}`
  const FileRemoveIconName = `img:${FileRemoveIcon}`

  defineProps<{
    summary: MediaSummary
  }>()

  const emits = defineEmits(['question'])

  // TODO: emit click event to parent component
</script>
<style scoped lang="scss">
  .summary-card-section {
    padding: 4px 0;
  }
  .summary-card-title {
    color: var(--brand);
    overflow-wrap: break-word;
    max-width: 600px;
  }

  .media-preview {
    max-width: 100px;
    max-height: 130px;
    width: 100%;
    height: auto;
    object-fit: contain;
  }

  .questions {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    column-gap: 10px;
    row-gap: 8px;
    width: 100%;
    box-sizing: border-box;
  }
  
  .deleted {
    color: var(--greyscale-grey-lighten-4, #999) !important;
  }
  @mixin common-styles {
    .questions {
      grid-template-columns: 1fr;
      justify-content: space-between; /* Spread the items equally apart */
      justify-content: center;
      margin-left: 0px;
      max-width: 100%;
    }
  }
  @media screen and (orientation: landscape) and (max-height: 500px) and (max-width: 1000px),
    (max-width: 767px) {
    /* Styles for phone screens */
    @include common-styles;
    .questions-centered {
      align-content: flex-start;
    }

    .summary-card {
      padding: 0 4px;
    }

    .summary-card.multiple {
      padding: 0 4px 0 8px;
    }

    .summary-card-title {
      max-width: 320px;
    }
  }
</style>
