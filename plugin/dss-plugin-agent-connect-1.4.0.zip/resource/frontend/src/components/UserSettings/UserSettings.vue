<template>
  <div class="user-settings-container">
    <div class="row items-center no-wrap q-gutter-x-sm">
      <div class="bs-font-medium-4-semi-bold">{{ t('user_settings') }}</div>
    </div>
    <div>
      <div class="flex-row items-center no-wrap user-settings-language">
        <div class="all-title bs-font-medium-3-normal setting-key">
          {{ t('language') }}
        </div>
        <bs-select
          class="bs-font-medium-3-normal setting-value"
          :model-value="selectedLanguage"
          :all-options="languages"
          @update:model-value="(value: string) => updateSettings('language', value)"
        ></bs-select>
      </div>
      <div
        v-for="(value, key) in otherSettings"
        v-bind:key="key"
        class="flex-row items-center no-wrap user-settings-other"
      >
        <div class="all-title row bs-font-medium-3-normal setting-key">
          {{ key }}
          <q-icon name="info" class="cursor info-icon">
            <BsTooltip
              class="bs-tooltip"
              anchor="top middle"
              self="bottom middle"
            >
              {{ value.description }}</BsTooltip
            >
          </q-icon>
        </div>
        <q-input
          class="bs-font-medium-3-normal setting-value"
          :model-value="value.value"
          @update:model-value="(val: string | number | null) => updateSettings(key, val)"
        ></q-input>
      </div>
      <ImageSettings
        :settings="props.settings"
        @update:settings="(value) => emits('update:settings', value)"
      />
    </div>
  </div>
</template>
<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'

import { updateObject } from '@/common/utils'
import ImageSettings from '@/components/ImageSettings/ImageSettings.vue'
import { useUI } from '@/composables/useUI'

const { t } = useI18n()
const { setup } = useUI()
const props = defineProps<{
    settings: Record<string, any>
  }>()
const selectedLanguage = computed(() => {
  return props.settings.language.value
})
const otherSettings: Record<string, any> = computed(() => {
  const settings = JSON.parse(JSON.stringify(props.settings))
  delete settings.language
  delete settings.media
  delete settings.generated_media_info
  return settings
})
const languages = computed(() => {
  return setup.value.supportedLanguages?.map((lang: any) => lang.value) ?? []
})

const emits = defineEmits<{
    (e: 'update:settings', value: any): void
  }>()

const updateSettings = (key: string, value: string | number | null) => {
  const newSettings = updateObject(props.settings, key, value)
  emits('update:settings', newSettings)
}
</script>
<style lang="scss" scoped>
  .user-settings-language,
  .user-settings-other {
    justify-content: space-between;
  }
  .setting-key {
    width: 50%;
  }
  .setting-value {
    width: 50%;
  }
  .info-icon {
    align-self: center;
    padding-left: 2px;
  }
</style>
