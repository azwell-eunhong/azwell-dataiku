<template>
  <q-carousel
    v-model="carouselSummaryInFocus"
    control-type="push"
    transition-prev="jump-right"
    transition-next="jump-left"
    draggable="false"
    swipeable
    animated
    control-color="control-brand"
    prev-icon="arrow_left"
    next-icon="arrow_right"
    padding
    arrows
    class="full-width flex"
    height="auto"
  >
    <q-carousel-slide
      v-for="(summary, summaryIdx) in summaries"
      :key="summaryIdx"
      :name="summaryIdx"
      class="column no-wrap flex-start dku-q-carousel-slide"
      :class="{ single: summaries.length === 1 }"
    >
      <SummaryCard :summary="summary" @question="useQuestion($event)" />
    </q-carousel-slide>
  </q-carousel>
</template>

<script setup lang="ts">
  import { ref } from 'vue'
  import SummaryCard from '@/components/SummaryCard/SummaryCard.vue'
  import type { MediaSummary } from '@/models'

  defineProps<{
    summaries: MediaSummary[]
    useQuestion: (question: string) => void
  }>()

  const carouselSummaryInFocus = ref(0)
</script>

<style scoped lang="scss">
:deep(.q-carousel__slides-container) {
    width: 100%;
  }
  .dku-q-carousel-slide {
    padding-left: 52px !important;
    padding-right: 32px !important;
    min-height: 216px;
  }
  .q-carousel__slide {
    padding: 0px;
  }
  .dku-q-carousel-slide.single {
    min-height: auto;
  }

  :deep(.q-carousel__control) {
    :deep(.q-btn.bg-control-brand) {
      background: var(--brand) !important;
      position: absolute;
      top: 150px;
      right: 0;
    }

    &.q-carousel__prev-arrow :deep(.q-btn) {
      left: 0;
    }

    :deep(.q-btn--push):before {
      border: none !important;
    }
  }

  @media screen and (orientation: landscape) and (max-height: 500px) and (max-width: 1000px),
    (max-width: 767px) {
    :deep(.q-carousel__control) {
      .q-btn.bg-control-brand {
        right: -15px;
      }

      &.q-carousel__prev-arrow :deep(.q-btn) {
        left: -15px;
      }
    }

    .dku-q-carousel-slide {
      padding-left: 36px !important;
      padding-right: 36px !important;
    }
  }
</style>
