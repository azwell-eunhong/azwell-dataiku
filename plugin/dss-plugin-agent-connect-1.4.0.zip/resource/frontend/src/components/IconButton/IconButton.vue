<template>
  <button
    :id="id"
    :name="name"
    type="button"
    class="cursor-pointer"
    ref="buttonRef"
    @click="onClick"
    :style="style"
    v-bind="disabled ? { disabled: true } : {}"
  >
    <q-icon :size="size">
      <slot></slot>
      <BsTooltip
        :anchor="tooltipAnchor"
        :self="tooltipSelf"
        :class="tooltipPosition"
      >
        {{ $t(tooltip) }}
      </BsTooltip>
    </q-icon>
  </button>
</template>

<script setup lang="ts">
  import { ref } from 'vue'
  // Internal ref for the button
  const buttonRef = ref<HTMLButtonElement | null>(null)

  // Expose the ref to the parent
  defineExpose({
    buttonRef
  })

  withDefaults(
    defineProps<{
      name?: string
      size: string
      id?: string
      tooltipAnchor?: string
      tooltipSelf?: string
      tooltipPosition?: string
      tooltip: string
      style?: Record<string, any>
      color?: string
      disabled?: boolean
    }>(),
    {
      color: 'black',
      size: 'sm',
      tooltipAnchor: 'top middle',
      tooltipSelf: 'bottom middle',
      tooltipPosition: 'arrow-top'
    }
  )

  const emits = defineEmits(['click'])
  const onClick = (event: MouseEvent) => {
    emits('click', event)
  }
</script>

<style scoped>
  button {
    border: none;
    background: none;
    padding: 0;
  }
</style>
