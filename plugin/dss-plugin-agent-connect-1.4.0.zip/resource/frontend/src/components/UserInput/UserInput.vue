<template>
  <div
    class="user-input-wrapper"
    :class="{ focused: focused }"
    @dragenter.prevent="handleDrag"
  >
    <BsFileDropZoneVue
      v-if="showFileDropZone"
      :upload-file-types="uploadFileTypes"
      :uploadedFiles="uploadedFiles"
      v-model="files"
      @showFileDropZone="toggleShowDropZone"
      @dragover.prevent="handleDrag"
    />
    <IconButton
      v-if="showUploadIcon"
      id="file-dropzone-btn"
      :name="fileUploadIconName"
      class="file-upload-button"
      @click="toggleFileDropZone"
      size="sm"
      :disabled="loading"
      tooltip="tooltip_file"
      ><AttachIcon></AttachIcon
    ></IconButton>
    <div class="row">
      <textarea
        id="user-input-textarea"
        ref="textAreaRef"
        v-model="internalValue"
        res
        class="query-input"
        :class="{ 'no-file-upload': !showUploadIcon }"
        :placeholder="inputPlaceholder"
        @input="handleInput"
        @keydown="handleKeyDown"
        @compositionstart="onCompositionStart"
        @compositionend="onCompositionEnd"
        @focus="handleFocus(true)"
        @blur="handleFocus(false)"
        :disabled="props.loading"
      >
      </textarea>
      <IconButton
        v-if="!loading"
        id="user-input-send-icon"
        class="send-icon"
        name="send"
        @click="handleSend($event)"
        size="xs"
        :style="activeStyle"
        tooltip="tooltip_send"
      >
        <SendIcon></SendIcon>
      </IconButton>

      <q-icon
        v-else-if="streamingEnabled"
        id="user-input-stop-icon"
        :name="mdiStopCircleOutline"
        class="spinner-wrapper"
        size="sm"
      ></q-icon>
      <div v-else class="spinner-wrapper">
        <q-spinner size="sm" id="user-input-spinner-icon" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { mdiStopCircleOutline } from '@quasar/extras/mdi-v6'
  import { computed, ref, watch } from 'vue'
  import BsFileDropZoneVue from '@/components/BsFileDropZone/BsFileDropZone.vue'
  import IconButton from '@/components/IconButton/IconButton.vue'
  import AttachIcon from '@/components/icons/AttachIcon.vue'
  import SendIcon from '@/components/icons/SendIcon.vue'
  import { useSync } from '@/composables/useSync'
  import type { MediaSummary } from '@/models'

  const fileUploadIconName = `img:${AttachIcon}`

  const props = defineProps<{
    value: string
    loading: boolean
    inputPlaceholder: string
    uploadFileTypes?: string
    streamingEnabled?: boolean
    disableFileUpload?: boolean
    uploadedImage?: string
    uploadedFiles?: MediaSummary[]
  }>()

  const emits = defineEmits([
    'send:value',
    'enterkey:value',
    'update:value',
    'sizeChange',
    'deleteFile',
    'fileChange',
    'stop'
  ])
  const internalValue = useSync(props, 'value', emits)
  const focused = ref(false)
  const textAreaRef = ref<InstanceType<typeof HTMLElement> | null>(null)
  const _showFilesDropZone = ref(false)
  const showFileDropZone = computed(() => {
    if (props.disableFileUpload) {
      return false
    }
    return _showFilesDropZone.value
  })
  const files = ref<File[]>([])

  const toggleFileDropZone = () => {
    if (props.loading) {
      return
    }
    _showFilesDropZone.value = !_showFilesDropZone.value
  }

  const showUploadIcon = computed(() => {
    if (props.disableFileUpload) {
      return false
    }
    return !showFileDropZone.value
  })

  const toggleShowDropZone = (show: boolean) => {
    _showFilesDropZone.value = show
  }

  function handleDrag(event: DragEvent) {
    event.preventDefault()
    _showFilesDropZone.value = true
  }
  const formData = computed(() => {
    if (files.value.length > 0) {
      const formData = new FormData()
      files.value.forEach((file) => {
        formData.append('files[]', file)
      })
      return formData
    }
    return undefined
  })
  const handleSend = (e: MouseEvent) => {
    e.stopPropagation()
    emits('send:value', formData.value)
    _showFilesDropZone.value = false
    files.value = []
  }

const isComposing = ref(false)
function onCompositionStart() {
      isComposing.value = true
}
function onCompositionEnd() {
  isComposing.value = false;
}
function handleInput() {
  adjustTextareaHeight();
}
function handleKeyDown(evt: KeyboardEvent) {
  if (evt.key === 'Enter' && !isComposing.value) {
    if (evt.shiftKey) {
      return;
    } else {
      evt.preventDefault();
      onReturnKey();
    }
  }
}
function onReturnKey() {
  emits('enterkey:value', formData.value)
  _showFilesDropZone.value = false
  files.value = []
}
  watch(internalValue, () => {
    setTimeout(() => {
      adjustTextareaHeight()
      textAreaRef.value?.focus()
    }, 0)
  })
  watch(files, () => {
    if (files.value.length > 0) {
      textAreaRef.value?.focus()
    }
  })
  function handleFocus(isFocused: boolean) {
    focused.value = isFocused
  }
  function adjustTextareaHeight() {
    const textarea = textAreaRef.value
    if (!textarea) return

    const maxHeight = 150
    const minHeight = 40
    if (internalValue.value === '') {
      textarea.style.height = `${minHeight}px` //min-height
    } else {
      textarea.style.height =
        textarea.scrollHeight > maxHeight
          ? `${maxHeight}px`
          : `${Math.max(textarea.scrollHeight, textarea.offsetHeight)}px`
      const scrollHeight = textarea.scrollHeight
      textarea.style.overflowY = scrollHeight <= minHeight ? 'hidden' : 'auto'
    }

    emits('sizeChange', textarea.style.height)
  }

  const activeStyle = computed(() => ({
    color:
      props.loading || (!internalValue.value && !files.value.length)
        ? '#CCCCCC'
        : 'var(--brand)'
  }))
</script>

<style scoped lang="scss">
  .user-input-wrapper {
    position: relative;
    border: 1px solid #c8c8c8;
    border-radius: 4px;
    width: 100%;
  }
  .user-input-wrapper.focused {
    outline: none !important;
    border: 1px solid var(--brand);
  }
  .user-input-wrapper.disabled {
    background-color: var(--greyscale-grey-lighten-8, #f2f2f2);
  }
  .query-input {
    padding: 8px 32px;
    height: 40px;
    min-height: 40px;
    max-height: 100px;
    font-size: 16px;
    min-width: calc(100% - 1px);
    max-width: calc(100% - 1px);
    border: none;
    border-radius: 4px;
    resize: none;
    overflow-y: hidden;
  }
  .query-input:focus {
    outline: none !important;
  }
  .query-input.no-file-upload {
    padding: 8px 32px 8px 12px;
  }

  textarea:disabled {
    background: var(--greyscale-grey-lighten-8, #f2f2f2);
  }
  .file-preview-wrapper {
    margin: 8px;
  }
  .send-icon,
  .spinner-wrapper {
    position: absolute;
    right: 8px;
    bottom: 8px;
    color: var(--brand);
  }
  .send-icon {
    transform: rotate(-38.48deg);
    padding-bottom: 8px;
    bottom: 5px;
  }
  .file-upload-button {
    position: absolute;
    left: 6px;
    z-index: 1;
    bottom: 8px;
  }
</style>
