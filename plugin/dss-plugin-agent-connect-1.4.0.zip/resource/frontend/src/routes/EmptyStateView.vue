<template>
  <div class="relative flex-column overflow-hidden full-height empty-state">
    <div class="sticky-header sticky">
      <SettingsDialog
        class="bs-font-medium-3-normal settings-btn"
        id="settings-dialog-btn"
      />
    </div>
    <div
      class="relative items-center full-height overflow-hidden empty-state-body"
    >
      <div
        class="full-width full-height overflow-y examples-centered"
        style="max-height: 100%"
      >
        <div class="q-gutter-y-md">
          <div
            class="logo-container"
            style="width: 100%; display: flex; justify-content: center"
          >
            <img :src="logo" class="logo-img" @error="imgError = true" />
          </div>
          <div
            class="dku-grand-title-sb"
            style="color: #666666; text-align: center"
          >
            {{ setup.title }}
          </div>
          <div
            v-if="subtitle"
            v-html="subtitle"
            class="dku-medium-title"
            style="text-align: center; color: #666666"
          ></div>
        </div>
        <div>
          <div
            class="title_with_lines"
            v-if="setup.examples && setup.examples.length"
          >
            {{ $t('examples') }}
          </div>
          <div class="grid no-wrap examples">
            <InfoCard
              v-for="(text, index) in setup.examples"
              :text="text"
              style="cursor: pointer"
              @click="currentData.query = text"
              v-bind:key="index"
            />
          </div>
        </div>
      </div>
    </div>
    <div class="empty-state-body" style="flex-shrink: 0">
      <RetrievalToggle
        v-if="retriever"
        v-model:model-value="useRetriever"
        :retrieval-type="retrievalMode"
        :label="retriever.alias"
        class="toggle"
      />
      <div class="grid no-wrap drop-zone">
        <UserInput
          :input-placeholder="inputPlaceholder"
          :value="currentData.query"
          :loading="loadingQuestion"
          :upload-file-types="uploadFileTypes"
          :streaming-enabled="streamingEnabled"
          :disable-file-upload="disableFileUpload"
          @send:value="sendQuestion"
          @enterkey:value="sendQuestion"
          @update:value="(value) => (currentData.query = value)"
          :isEmptyState="true"
        />
      </div>
      <DisclaimerSection />
    </div>
  </div>
</template>
<script lang="ts" setup>
  import DOMPurify from 'dompurify'

  import { ref, toRefs, computed } from 'vue'
  import { useI18n } from 'vue-i18n'
  import logoWithBackground from '@/assets/icons/logo-with-background.png'
  import { getCustomImagePath } from '@/common/utils'
  import DisclaimerSection from '@/components/DisclaimerSection/DisclaimerSection.vue'
  import InfoCard from '@/components/InfoCard/InfoCard.vue'
  import RetrievalToggle from '@/components/RetrievalToggle/RetrievalToggle.vue'
  import SettingsDialog from '@/components/SettingsDialog/SettingsDialog.vue'
  import UserInput from '@/components/UserInput/UserInput.vue'
  import { useConversation } from '@/composables/useConversation'
  import { useRetrievalToggle } from '@/composables/useRetrievalToggle'
  import { useUI } from '@/composables/useUI'

  const props = defineProps<{
    id: string | null
  }>()

  const { t } = useI18n()

  const { id } = toRefs(props)
  const { currentData, sendQuestion, loadingQuestion } = useConversation(id)

  const { setup } = useUI()
  defineEmits<{
    (e: 'example-clicked', text: string): void
  }>()

  const imgError = ref(false)
  const logo = computed(() => {
    if (setup.value.useCustomRebranding) {
      const fileName = setup.value.customLogoFileName
        ? setup.value.customLogoFileName
        : ''
      return getCustomImagePath(
        fileName,
        logoWithBackground,
        setup.value.customThemeName,
        imgError.value
      )
    } else {
      return logoWithBackground
    }
  })

  const inputPlaceholder = computed(() => {
    return setup.value.questionPlaceholder || t('questionPlaceholder')
  })

  const streamingEnabled = computed(() => {
    return setup.value?.llmCapabilities?.streaming
  })

  const subtitle = computed(() => {
    return DOMPurify.sanitize(setup.value?.subtitle || '')
  })

  const disableFileUpload = computed(() => {
    return !setup.value.uploadFileTypes?.length
  })
  const { retriever, useRetriever, retrievalMode } = useRetrievalToggle()

  const uploadFileTypes = computed(() => {
    return setup.value.uploadFileTypes
  })
</script>

<style scoped lang="scss">
  .title_with_lines {
    line-height: 20px;
    text-align: center;
    color: var(--brand);
    font-size: 13px;
    margin-bottom: 19px;
    margin-top: 36px;
  }
  .title_with_lines {
    display: inline-block;
    position: relative;
    width: 100%;
  }
  .title_with_lines:before,
  .title_with_lines:after {
    content: '';
    position: absolute;
    overflow: hidden;
    height: 10px;
    border-bottom: 1px solid var(--brand);
    top: 0;
    width: calc(50% - 50px);
  }
  .title_with_lines:before {
    right: 50%;
    margin-right: 50px;
  }
  .title_with_lines:after {
    left: 50%;
    margin-left: 50px;
  }
  .empty-state {
    width: 100%;
    max-width: 100%;
    height: 100vh;
    .kb-toggle {
      margin-top: 12px;
      margin-bottom: 4px;
    }
  }
  .empty-state-body {
    width: 800px;
    max-width: 100%;
    align-self: center;
  }

  .examples {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    column-gap: 10px;
    row-gap: 8px;
    width: 100%;
    box-sizing: border-box;
  }
  .drop-zone {
    position: relative;
  }
  .logo-container {
    margin-top: 0px;
  }
  .sticky-header {
    margin-bottom: 0px;
  }
  .examples-centered {
    align-content: center;
  }
  // Mixin for common styles for small screens */
  @mixin common-styles {
    .empty-state {
      width: 100% !important;
    }
    .empty-state-body {
      width: 100%;
      max-width: 100%;
      margin-top: 12px;
    }
    .examples {
      grid-template-columns: 1fr;
      justify-content: space-between; /* Spread the items equally apart */
      justify-content: center;
      margin-left: 0px;
      max-width: 100%;
    }
    .info-card {
      max-width: 100%;
      margin-left: 0px;
    }
  }
  .q-gutter-y-md {
    margin-top: 0px;
  }
  .logo-img {
    max-height: 120px;
    max-width: 100%;
  }
  @media screen and (orientation: landscape) and (max-height: 500px) and (max-width: 1000px),
    (max-width: 767px) {
    /* Styles for phone screens */
    @include common-styles;
    .logo-container {
      margin-top: 16px;
    }
    .examples-centered {
      align-content: flex-start;
    }
  }
</style>
