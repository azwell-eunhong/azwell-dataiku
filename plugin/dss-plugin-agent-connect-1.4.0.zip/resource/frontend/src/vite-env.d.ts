declare const __UI_VERSION__: string
