import * as components from './components.js'
import installApp from './install-lib.js'

export const AnswersUI = {
  version: __UI_VERSION__,
  install(app) {
    installApp(app, { components })
  }
}

export * from './components.js'
export const version = __UI_VERSION__
