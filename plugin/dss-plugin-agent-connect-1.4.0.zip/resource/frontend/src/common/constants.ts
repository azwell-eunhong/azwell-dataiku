
export const CUSTOMIZATION_PATH = `/local/static/agent-connect`
export const SUPPORTED_CUSTOM_IMAGES_EXTENSIONS = ['jpg', 'jpeg', 'png']
