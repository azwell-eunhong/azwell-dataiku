# Component MyComponent

# Usage

## Vue CLI project

```js
import Vue from 'vue'
import Plugin from 'dss-answers-ui-components'

Vue.use(Plugin)
```

**OR**:

```html
<style src="quasar-ui-bs/dist/index.css"></style>

<script>
  import { Component as MyComponent } from 'quasar-ui-bs'

  export default {
    components: {
      MyComponent
    }
  }
</script>
```

# Setup
- You need to add .npmrc file to add your personal github token `PAT` to fetch `quasar-ui-bs` package with this content and replace it with your `PAT`.
```
//npm.pkg.github.com/:_authToken=<YOUR_PERSONAL_ACCESS_TOKEN>
@dataiku:registry=https://npm.pkg.github.com/
- Then, run
```
```bash
$ yarn install
```

# Developing

````bash
# start dev in SPA mode
$ yarn dev

# Building package
```bash
$ yarn build
````

# License

MIT(C)
