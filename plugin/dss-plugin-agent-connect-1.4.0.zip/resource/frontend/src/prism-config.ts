// Import required PrismJS components
import 'prismjs/components/prism-javascript' // JavaScript
import 'prismjs/components/prism-typescript' // TypeScript
import 'prismjs/components/prism-css' // CSS
import 'prismjs/components/prism-scss' // SCSS
import 'prismjs/components/prism-json' // JSON
import 'prismjs/components/prism-markup' // XML, HTML, SVG, MathML, etc.
import 'prismjs/components/prism-bash' // Bash/Shell
import 'prismjs/components/prism-python' // Python
import 'prismjs/components/prism-java' // Java
import 'prismjs/components/prism-csharp' // C#
import 'prismjs/components/prism-c' // C
import 'prismjs/components/prism-cpp' // C++
import 'prismjs/themes/prism-tomorrow.css'

export const loadPrismDependencies = () => {
  console.log('loaded Prism Dependencies')
}
