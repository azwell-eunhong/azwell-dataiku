import "@quasar/extras/material-icons/material-icons.css";
import "@quasar/extras/material-icons-outlined/material-icons-outlined.css";
import "@quasar/extras/material-icons-round/material-icons-round.css";
import "@/index.scss";
import QuasarPlugin from './src/quasar-plugin'
// import "dss-answers-ui-components/index.css";
import { myApp } from "./src/index";
import router from "./src/router";
import { registerDirectives } from './src/directives/register'
import { loadPrismDependencies } from './src/prism-config'
import { setCssVar } from 'quasar'
import { default as md5 } from './src/common/md5'
import i18n from './src/i18n'
myApp.config.unwrapInjectedRef = true;

setCssVar("primary", "#3B99FC");
window.md5 = md5;
console.log("router", router);
myApp.use(router);
registerDirectives(myApp);
myApp.use(QuasarPlugin);
loadPrismDependencies();
myApp.use(i18n);

myApp.mount("#app");
