import time
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Union

from common.backend.constants import PROMPT_DATE_FORMAT
from common.backend.models.base import (
    ConversationParams,
    LLMContext,
    LlmHistory,
    LLMStep,
    MediaSummary,
    RetrievalSummaryJson,
    Source,
)
from common.backend.utils.context_utils import LLMStepName
from common.backend.utils.llm_utils import handle_prompt_media_explanation
from common.backend.utils.prompt_utils import append_user_profile_to_prompt
from common.llm_assist.logging import logger
from common.solutions.chains.generic_answers_chain import GenericAnswersChain
from dataiku.core.knowledge_bank import MultipartContext
from dataiku.langchain.dku_llm import DKULLM
from langchain.chains import ConversationChain
from langchain.prompts import PromptTemplate
from langchain_core.prompt_values import PromptValue


class NoRetrievalChain(GenericAnswersChain):
    def __init__(self, llm: DKULLM, chat_has_media: bool = False):
        super().__init__()
        self.__llm = llm
        self.__act_like_prompt = ""
        self.__system_prompt = ""
        self.__prompt_with_media_explanation = chat_has_media
        self.__qa_chain: Optional[ConversationChain] = None
        self.__computed_prompt: Optional[PromptValue] = None

    @property
    def qa_chain(self) -> ConversationChain:
        if self.__qa_chain is None:
            raise ValueError("QA chain is not initialized.")
        return self.__qa_chain

    @property
    def act_like_prompt(self) -> str:
        return self.__act_like_prompt

    @property
    def system_prompt(self) -> str:
        return self.__system_prompt

    @property
    def computed_prompt(self) -> PromptValue:
        if self.__computed_prompt is None:
            raise ValueError("Computed prompt is not initialized.")
        return self.__computed_prompt

    @property
    def llm(self) -> DKULLM:
        return self.__llm

    @property
    def chain_purpose(self) -> str:
        return LLMStepName.NO_RETRIEVAL.value

    def load_role_and_guidelines_prompts(self, params: ConversationParams):
        act_like_prompt, system_prompt = self.load_default_role_and_guidelines_prompts()
        user_profile = params.get("user_profile", None)
        include_full_user_profile = bool(self.webapp_config.get("include_user_profile_in_KB_prompt", False))
        system_prompt = append_user_profile_to_prompt(
            system_prompt=system_prompt, user_profile=user_profile, include_full_user_profile=include_full_user_profile
        )
        system_prompt = handle_prompt_media_explanation(
            system_prompt=system_prompt, has_media=self.__prompt_with_media_explanation
        )
        self.__act_like_prompt = act_like_prompt
        self.__system_prompt = system_prompt

    def create_chain(self, params: ConversationParams) -> ConversationChain:
        """Initializes a ConversationChain with a custom prompt template for generating detailed and friendly AI-human interactions.

        Parameters
        ----------
        - act_like_prompt (str): A descriptive string guiding the AI's behavior and language style.
        - system_prompt (str): A system prompt for the AI to follow.

        Returns
        -------
        - ConversationChain: An instance configured with a tailored prompt template, leveraging the provided `act_like_prompt`.

        """
        datetime_now = datetime.now().strftime(PROMPT_DATE_FORMAT)
        template = rf"""
        Today's date and time: {datetime_now}
        {self.act_like_prompt}
        
        {self.system_prompt}
                
        Chat history:
        {{history}}
        --- End of Chat history ---
        Human: {{input}}
        Assistant:"""
        qa_prompt = PromptTemplate(input_variables=["history", "input"], template=template)

        self.__qa_chain = ConversationChain(llm=self.llm, memory=self.memory, verbose=True, prompt=qa_prompt)

        return self.qa_chain

    def get_computing_prompt_step(self, params: ConversationParams) -> LLMStep:
        return LLMStep.COMPUTING_PROMPT_WITHOUT_RETRIEVAL

    def get_querying_step(self, params: ConversationParams) -> LLMStep:
        return LLMStep.QUERYING_LLM_WITHOUT_RETRIEVAL

    def finalize_non_streaming(
        self,
        params: ConversationParams,
        question_context: Union[str, Dict[str, Any], List[str]],
    ) -> RetrievalSummaryJson:
        return self.get_as_json(
            generated_answer=question_context,
            uploaded_docs=params.get("media_summaries", None),
        )

    def finalize_streaming(
        self,
        params: ConversationParams,
        question_context: Union[str, Dict[str, Any], List[str]],
    ) -> RetrievalSummaryJson:
        return self.get_as_json(generated_answer=question_context, uploaded_docs=params.get("media_summaries", None))

    def __compute_prompt_for_completion_query(self, conv_chain: ConversationChain, user_question: str) -> PromptValue:
        """Generates a prompt for streaming by processing the user's question and conversation history.

        Steps:
        1. Prepares inputs from the user's question and history.
        2. Builds and returns the final prompt based on these inputs

        Parameters
        ----------
        - conv_chain (ConversationChain): Used for input preparation and prompt generation.
        - user_question (str): The user's current question.

        Returns
        -------
        - PromptValue: The generated prompt for the given question.

        """
        inputs = conv_chain.prep_inputs({"input": user_question, "history": self.memory})
        computed_prompt = conv_chain.prep_prompts(input_list=[{"input": user_question, "history": inputs["history"]}])
        if computed_prompt:
            prompt: PromptValue = computed_prompt[0][0]
            return prompt
        else:
            raise Exception("Prompt could not be computed.")

    def create_computed_prompt(
        self,
        params: ConversationParams,
    ) -> Tuple[MultipartContext, PromptValue, Dict[str, Any]]:
        start_time = time.time()
        user_query = params.get("user_query", "")
        question_context: Dict[str, Any] = {}
        self.__computed_prompt = self.__compute_prompt_for_completion_query(
            conv_chain=self.qa_chain, user_question=user_query
        )
        logger.debug(f"""Time ===> taken by Computing prompt for conversational: {(time.time() - start_time):.2f} secs"
        Final prompt:  {self.__computed_prompt.to_string() if self.__computed_prompt else "No prompt"}""")
        return None, self.computed_prompt, question_context

    def get_as_json(
        self,
        generated_answer: Union[str, Dict[str, Any], List[str]],
        user_profile: Optional[Dict[str, Any]] = None,
        uploaded_docs: Optional[List[MediaSummary]] = None,
        sources: Optional[List[Source]] = [],
    ) -> RetrievalSummaryJson:
        llm_context: LLMContext = {}  # type: ignore
        if user_profile:
            llm_context["user_profile"] = user_profile
        if uploaded_docs:
            llm_context["uploaded_docs"] = [
                {
                    "original_file_name": str(uploaded_doc.get("original_file_name")),
                    "metadata_path": str(uploaded_doc.get("metadata_path")),
                }
                for uploaded_doc in uploaded_docs
            ]
        if isinstance(generated_answer, str):
            return RetrievalSummaryJson(
                answer=generated_answer,
                sources=sources if sources else [],
                filters=None,
                knowledge_bank_selection=[],
                llm_context=llm_context,
                user_profile=user_profile if user_profile else {},
            )

        if isinstance(generated_answer, dict):
            answer = generated_answer.get("answer", "")
            if generated_answer.get("images", None):
                return RetrievalSummaryJson(
                    answer=answer,
                    generated_images=generated_answer.get("images", []),
                    sources=sources if sources else [],
                    filters=None,
                    llm_context=llm_context,
                    user_profile=generated_answer.get("user_profile", user_profile),
                )
            return RetrievalSummaryJson(
                answer=answer, sources=sources if sources else [], filters=None, llm_context=llm_context
            )
        logger.error(f"Generated answer type not supported. This should not happen. {generated_answer}")
        return {}

    def create_query_from_history_and_update_params(
        self, chat_history: List[LlmHistory], user_query: str, conversation_params: ConversationParams
    ) -> ConversationParams:
        return conversation_params
