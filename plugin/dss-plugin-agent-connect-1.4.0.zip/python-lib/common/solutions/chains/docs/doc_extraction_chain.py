import time
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Union

from common.backend.constants import PROMPT_DATE_FORMAT, PROMPT_SEPARATOR_LENGTH
from common.backend.models.base import (
    ConversationParams,
    LLMContext,
    LlmHistory,
    LLMStep,
    MediaSummary,
    RetrievalSummaryJson,
    UploadChainTypes,
)
from common.backend.utils.context_utils import LLMStepName
from common.backend.utils.dataiku_api import dataiku_api
from common.backend.utils.prompt_utils import append_user_profile_to_prompt
from common.llm_assist.logging import logger
from common.solutions.chains.generic_answers_chain import GenericAnswersChain
from dataiku.core.knowledge_bank import MultipartContext
from dataiku.langchain.dku_llm import DKULLM
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain_core.prompt_values import PromptValue

project = dataiku_api.default_project
webapp_config = dataiku_api.webapp_config


class DocumentExtractionChain(GenericAnswersChain):
    def __init__(self, llm: DKULLM, media_summaries: List[MediaSummary], self_service_decision: Dict[str, Any]) -> None:
        super().__init__()
        logger.debug("DocumentExtractionChain")
        self.__llm = llm
        self.__act_like_prompt = """# Role and Guidelines
        Your role is to read the extracted text, chat history and human query and to craft a response.
        This text is extracted from a document or documents uploaded to a webapp.
        - Do not speculate if you cannot answer the question based on text provided.
        - If no files have been uploaded do not mention this. Simply reply to the human query.

        """
        self.__system_prompt = """Given the extracted text and the conversation between a human and an AI, please give a short answer to the question at the end.
        """
        self.__media_summaries = media_summaries
        self.__self_service_decision = self_service_decision
        self.__qa_chain: Optional[LLMChain] = None
        self.__computed_prompt: Optional[PromptValue] = None
        self.__extracted_text: str = ""

    @property
    def llm(self) -> DKULLM:
        return self.__llm

    @property
    def act_like_prompt(self) -> str:
        return self.__act_like_prompt

    @property
    def system_prompt(self) -> str:
        return self.__system_prompt

    @property
    def computed_prompt(self) -> PromptValue:
        if self.__computed_prompt is None:
            raise ValueError("Computed prompt is not initialized.")
        return self.__computed_prompt

    @property
    def qa_chain(self) -> LLMChain:
        if self.__qa_chain is None:
            raise ValueError("QA chain is not initialized.")
        return self.__qa_chain

    @property
    def media_summaries(self) -> List[MediaSummary]:
        if not self.__media_summaries:
            raise Exception("No media summaries provided")
        return self.__media_summaries

    @property
    def self_service_decision(self) -> Dict[str, Any]:
        if not self.__self_service_decision:
            raise Exception("No decision provided")
        return self.__self_service_decision

    @property
    def extracted_text(self) -> str:
        return self.__extracted_text

    @property
    def chain_purpose(self) -> str:
        return LLMStepName.TEXT_EXTRACTION_ANSWER.value

    def _source_extracted_text(self) -> str:
        folder = dataiku_api.folder_handle
        full_extracted_text = ""
        selected_tittles = self.self_service_decision.get("documents", [])
        selected_summaries = [s for s in self.media_summaries if s.get("original_file_name") in selected_tittles]
        try:
            for summary in selected_summaries:
                chain_type: Union[str, None] = summary.get("chain_type")
                if chain_type not in [UploadChainTypes.SHORT_DOCUMENT.value]:
                    continue
                metadata_path = summary.get("metadata_path")  # type: ignore
                extract_summary = folder.read_json(metadata_path)
                if not metadata_path:
                    logger.error("metadata_path is not provided for document")
                    raise Exception("metadata_path is not provided for document")
                logger.debug(f"Extracting text from {metadata_path}")
                original_file_name = summary.get("original_file_name", "Unknown")
                full_extracted_text += f"""{"-" * PROMPT_SEPARATOR_LENGTH} START OF DOCUMENT: {original_file_name} {"-" * PROMPT_SEPARATOR_LENGTH}
                Document Name: {original_file_name}
                Main Topics: {extract_summary.get("topics", "Unknown")}
                Full Extracted Text:
                {extract_summary.get("full_extracted_text", "No text extracted")}
                {"-" * PROMPT_SEPARATOR_LENGTH} END OF DOCUMENT: {original_file_name}{"-" * PROMPT_SEPARATOR_LENGTH}
                """
            self.__extracted_text = full_extracted_text
            return self.extracted_text
        except Exception as e:
            raise Exception(f"Error occurred while extracting text from json files: {e}")

    def load_role_and_guidelines_prompts(self, params: ConversationParams):
        user_profile = params.get("user_profile", None)
        include_full_user_profile = bool(self.webapp_config.get("include_user_profile_in_KB_prompt", False))
        system_prompt = append_user_profile_to_prompt(
            system_prompt=self.system_prompt,
            user_profile=user_profile,
            include_full_user_profile=include_full_user_profile,
        )
        self.__system_prompt = system_prompt

    def create_chain(self, params: ConversationParams) -> LLMChain:
        datetime_now = datetime.now().strftime(PROMPT_DATE_FORMAT)
        template = rf"""# --- START OF EXTRACTED TEXT ---
        {{extracted_text}}
        # --- END OF EXTRACTED TEXT ---
        {self.act_like_prompt}

        {self.system_prompt}
        # --- START OF CONVERSATION HISTORY ---
        {{history}}
        # --- END OF CONVERSATION HISTORY ---
        Today's date and time: {datetime_now}
        human query: {{input}}
        Your answer:"""
        qa_prompt = PromptTemplate(input_variables=["extracted_text", "history", "input"], template=template)
        self.__qa_chain = LLMChain(llm=self.llm, prompt=qa_prompt, memory=self.memory, verbose=True)

        return self.qa_chain

    def get_computing_prompt_step(self, params: ConversationParams) -> LLMStep:
        return LLMStep.COMPUTING_PROMPT_WITHOUT_RETRIEVAL

    def get_querying_step(self, params: ConversationParams) -> LLMStep:
        return LLMStep.QUERYING_LLM_WITHOUT_RETRIEVAL

    def finalize_streaming(
        self,
        params: ConversationParams,
        question_context: Union[str, Dict[str, Any], List[str]],
    ) -> RetrievalSummaryJson:
        user_profile = params.get("user_profile", None)
        return self.get_as_json(
            question_context,
            user_profile=user_profile,
        )

    def finalize_non_streaming(
        self,
        params: ConversationParams,
        question_context: Union[str, Dict[str, Any], List[str]],
    ) -> RetrievalSummaryJson:
        return self.finalize_streaming(params=params, question_context=question_context)

    def compute_prompt_for_completion_query(
        self, conv_chain: LLMChain, user_question: str, extracted_text: str
    ) -> PromptValue:
        prompt: PromptValue
        inputs = conv_chain.prep_inputs({"input": user_question, "history": self.memory})
        computed_prompt = conv_chain.prep_prompts(
            input_list=[
                {
                    "input": user_question,
                    "history": inputs["history"],
                    "extracted_text": extracted_text,
                }
            ]
        )
        if computed_prompt:
            prompt = computed_prompt[0][0]
        return prompt

    def create_computed_prompt(
        self,
        params: ConversationParams,
    ) -> Tuple[MultipartContext, PromptValue, Dict[str, Any]]:
        start_time = time.time()
        user_query = params.get("user_query", "")
        self._source_extracted_text()

        question_context: Dict[str, Any] = {}
        self.__computed_prompt = self.compute_prompt_for_completion_query(
            conv_chain=self.qa_chain,
            user_question=user_query,
            extracted_text=self.extracted_text,
        )
        logger.debug(f"Time ===> taken by Computing prompt for conversational: {(time.time() - start_time):.2f} secs")
        # Prompt truncated for logging
        prompt_str = self.__computed_prompt.to_string()
        if len(prompt_str) > 4000:
            logger.debug(f"""
                Final prompt (TRUNCATED):{prompt_str[:2000]}
                ...
                ...
                ...
                {prompt_str[-2000:]}""")
        else:
            logger.debug(f"Final prompt:  {prompt_str if self.__computed_prompt else 'No prompt'}")
        return None, self.computed_prompt, question_context

    def get_as_json(
        self,
        generated_answer: Union[str, Dict[str, Any], List[str]],
        user_profile: Optional[Dict[str, Any]] = None,
    ) -> RetrievalSummaryJson:
        llm_context: LLMContext = {}  # type: ignore
        if user_profile:
            llm_context["user_profile"] = user_profile
        media_summaries = self.media_summaries

        llm_context["media_qa_context"] = [
            {
                "original_file_name": summary.get("original_file_name"),
                "metadata_path": summary.get("metadata_path"),
                "file_path": summary.get("file_path"),
                "chain_type": UploadChainTypes.SHORT_DOCUMENT.value,
                "topics": summary.get("topics"),
            }
            for summary in media_summaries
        ]

        if isinstance(generated_answer, str):
            return {
                "answer": generated_answer,
                "sources": [],
                "filters": None,
                "knowledge_bank_selection": [],
            }

        if isinstance(generated_answer, dict):
            answer = generated_answer.get("answer", "")
            return {
                "answer": answer,
                "sources": [],
                "filters": None,
                "llm_context": llm_context,
            }
        logger.error(f"Generated answer type not supported. This should not happen. {generated_answer}")
        return {}

    def create_query_from_history_and_update_params(
        self,
        chat_history: List[LlmHistory],
        user_query: str,
        conversation_params: ConversationParams,
    ) -> ConversationParams:
        return conversation_params
