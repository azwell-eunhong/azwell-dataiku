import time
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Union

from common.backend.constants import PROMPT_DATE_FORMAT
from common.backend.models.base import (
    ConversationParams,
    LLMContext,
    LlmHistory,
    LLMStep,
    MediaSummary,
    RetrievalSummaryJson,
)
from common.backend.utils.context_utils import LLMStepName
from common.backend.utils.dataiku_api import dataiku_api
from common.backend.utils.prompt_utils import append_user_profile_to_prompt
from common.llm_assist.logging import logger
from common.solutions.chains.generic_answers_chain import GenericAnswersChain
from dataiku.core.knowledge_bank import MultipartContext
from dataiku.langchain.dku_llm import DKULLM
from langchain.chains import ConversationChain
from langchain.prompts import PromptTemplate
from langchain_core.prompt_values import PromptValue

project = dataiku_api.default_project
webapp_config = dataiku_api.webapp_config


class DocumentAsImageChain(GenericAnswersChain):
    def __init__(self, llm: DKULLM, media_summaries: List[MediaSummary]) -> None:
        super().__init__()
        self.__llm = llm
        self.__act_like_prompt = """# Role and Guidelines
        Your role is to look at the chat history, uploaded files and a human query regarding the file and to craft a response.
        The files have been uploaded to a webapp.
        - Do not speculate if you cannot answer the question based on files provided.
        - If no files have been uploaded do not mention this. Simply reply to the human query.
        """
        self.__system_prompt = """Given the following pages and the conversation between a human and an AI, please give a short answer to the question at the end.
        """
        self.__media_summaries = media_summaries

        self.__qa_chain: Optional[ConversationChain] = None
        self.__computed_prompt: Optional[PromptValue] = None

    @property
    def llm(self) -> DKULLM:
        return self.__llm

    @property
    def act_like_prompt(self) -> str:
        return self.__act_like_prompt

    @property
    def system_prompt(self) -> str:
        return self.__system_prompt

    @property
    def qa_chain(self) -> ConversationChain:
        if self.__qa_chain is None:
            raise ValueError("QA chain is not initialized.")
        return self.__qa_chain

    @property
    def computed_prompt(self) -> PromptValue:
        if self.__computed_prompt is None:
            raise ValueError("Computed prompt is not initialized.")
        return self.__computed_prompt

    @property
    def media_summaries(self) -> List[MediaSummary]:
        return self.__media_summaries

    @property
    def chain_purpose(self) -> str:
        return LLMStepName.DOC_AS_IMAGE_ANSWER.value

    def load_role_and_guidelines_prompts(self, params: ConversationParams):
        user_profile = params.get("user_profile", None)
        include_full_user_profile = bool(self.webapp_config.get("include_user_profile_in_KB_prompt", False))
        system_prompt = append_user_profile_to_prompt(
            system_prompt=self.system_prompt,
            user_profile=user_profile,
            include_full_user_profile=include_full_user_profile,
        )
        self.__system_prompt = system_prompt

    def create_chain(self, params: ConversationParams) -> ConversationChain:
        datetime_now = datetime.now().strftime(PROMPT_DATE_FORMAT)
        template = rf"""
        Today's date and time: {datetime_now}
        {self.act_like_prompt}
        
        {self.system_prompt}
                
        Current conversation:
        {{history}}

        Human: {{input}}
        Assistant:"""
        qa_prompt = PromptTemplate(input_variables=["history", "input"], template=template)

        self.__qa_chain = ConversationChain(llm=self.llm, memory=self.memory, verbose=True, prompt=qa_prompt)

        return self.qa_chain

    def get_computing_prompt_step(self, params: ConversationParams) -> LLMStep:
        return LLMStep.COMPUTING_PROMPT_WITHOUT_RETRIEVAL

    def get_querying_step(self, params: ConversationParams) -> LLMStep:
        return LLMStep.QUERYING_LLM_WITHOUT_RETRIEVAL

    def finalize_streaming(
        self,
        params: ConversationParams,
        question_context: Union[str, Dict[str, Any], List[str]],
    ) -> RetrievalSummaryJson:
        user_profile = params.get("user_profile", None)

        # Send sources and filters at the end of the streaming
        return self.get_as_json(
            question_context,
            user_profile=user_profile,
        )

    def finalize_non_streaming(
        self,
        params: ConversationParams,
        question_context: Union[str, Dict[str, Any], List[str]],
    ) -> RetrievalSummaryJson:
        return self.finalize_streaming(params=params, question_context=question_context)

    def compute_prompt_for_completion_query(self, conv_chain: ConversationChain, user_question: str) -> PromptValue:
        prompt: PromptValue
        inputs = conv_chain.prep_inputs({"input": user_question, "history": self.memory})
        computed_prompt = conv_chain.prep_prompts(input_list=[{"input": user_question, "history": inputs["history"]}])
        if computed_prompt:
            prompt = computed_prompt[0][0]
        return prompt

    def create_computed_prompt(
        self,
        params: ConversationParams,
    ) -> Tuple[MultipartContext, PromptValue, Dict[str, Any]]:
        start_time = time.time()
        user_query = params.get("user_query", "")
        question_context: Dict[str, Any] = {}
        self.__computed_prompt = self.compute_prompt_for_completion_query(
            conv_chain=self.qa_chain, user_question=user_query
        )
        logger.debug(f"""Time ===> taken by Computing prompt for conversational: {(time.time() - start_time):.2f} secs
        Final prompt:  {self.__computed_prompt.to_string() if self.__computed_prompt else "No prompt"}""")
        return None, self.computed_prompt, question_context

    def get_as_json(
        self,
        generated_answer: Union[str, Dict[str, Any], List[str]],
        user_profile: Optional[Dict[str, Any]] = None,
    ) -> RetrievalSummaryJson:
        llm_context: LLMContext = {}  # type: ignore
        if user_profile:
            llm_context["user_profile"] = user_profile
        llm_context["media_qa_context"] = self.media_summaries
        if isinstance(generated_answer, str):
            return {
                "answer": generated_answer,
                "sources": [],
                "filters": None,
                "knowledge_bank_selection": [],
                "llm_context": llm_context,
            }
        if isinstance(generated_answer, dict):
            answer = generated_answer.get("answer", "")
            return {"answer": answer, "sources": [], "filters": None, "llm_context": llm_context}
        logger.error(f"Generated answer type not supported. This should not happen. {generated_answer}")
        return {}

    def create_query_from_history_and_update_params(
        self, chat_history: List[LlmHistory], user_query: str, conversation_params: ConversationParams
    ) -> ConversationParams:
        return conversation_params
