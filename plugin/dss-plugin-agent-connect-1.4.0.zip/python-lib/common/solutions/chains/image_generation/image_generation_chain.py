import base64
import json
import time
from datetime import datetime
from typing import Any, Dict, Generator, Optional, Union

from common.backend.models.base import LLMStep, LLMStepDesc, RetrievalSummaryJson
from common.backend.utils.auth_utils import get_auth_user
from common.backend.utils.context_utils import TIME_FORMAT, add_llm_step_trace
from common.backend.utils.llm_utils import get_llm_image_generation, handle_response_trace
from common.backend.utils.picture_utils import detect_image_format, get_image_bytes
from common.backend.utils.user_profile_utils import (
    get_image_height,
    get_image_quality,
    get_image_width,
    get_nbr_images_to_generate,
    get_num_images_user_can_generate,
    set_nbr_images_to_generate,
)
from common.llm_assist.logging import logger
from common.solutions.chains.no_retrieval_chain import NoRetrievalChain
from dataiku.langchain.dku_llm import DKULLM
from dataiku.llm.tracing import SpanBuilder
from dataikuapi.dss.llm import DSSLLMImageGenerationQuery, DSSLLMImageGenerationResponse


class ImageGenerationChain:
    def __init__(
        self,
        llm: DKULLM,
        image_generation_llm: DKULLM,
        user_query: str,
        referred_image: Optional[str],
        user_profile_sql_manager: Any,
        user_profile: Optional[Dict[str, Any]] = None,
        trace: SpanBuilder = None,
    ):
        self.user_query = user_query
        self.referred_image = referred_image
        self.user_profile = user_profile
        self.llm = llm
        self.image_generation_llm = image_generation_llm
        self.user_profile_sql_manager = user_profile_sql_manager
        self.trace = trace

    def run_image_generation_query(self, max_images_to_generate: int) -> Generator[Union[LLMStepDesc, RetrievalSummaryJson], Any, None]:
        self.trace.begin(int(time.time() * 1000))
        self.trace.inputs["query"] = self.user_query
        if max_images_to_generate > 0 and self.user_profile:
            stored_user_profile = self.user_profile_sql_manager.get_user_profile(get_auth_user())
            if stored_user_profile:
                self.user_profile = stored_user_profile
            else:
                logger.debug("New user profile")
                # If the user profile is not found, add a flag to mark the user profile as new
                # to insert a new user profile in the database
                self.user_profile["new_user_profile"] = True
            num_images = get_num_images_user_can_generate(self.user_profile)
            question_context = {}
            if num_images == 0:
                message = "Oops! You’ve reached your image generation limit for this week. Check your next reset time in your Settings."
                question_context["answer"] = message
                yield {"step": LLMStep.STREAMING_END}
                yield NoRetrievalChain(self.llm).get_as_json(question_context)
                return
            elif num_images < get_nbr_images_to_generate(self.user_profile):  # type: ignore
                set_nbr_images_to_generate(self.user_profile, num_images)  # type: ignore
        logger.debug("Running image generation query")

        yield {"step": LLMStep.GENERATING_IMAGE}
        try:
            generation: DSSLLMImageGenerationQuery = get_llm_image_generation(self.image_generation_llm)
            start_time: str = datetime.now().strftime(TIME_FORMAT)
            generation.with_prompt(self.user_query)
            if self.referred_image:
                logger.debug(f"Referred image: {self.referred_image}")
                image_bytes = get_image_bytes(self.referred_image)
                if image_bytes:
                    generation.with_original_image(image=image_bytes)
            if self.user_profile and self.user_profile.get("media") and self.user_profile.get("media").get("image"):  # type: ignore
                if height := get_image_height(self.user_profile):
                    logger.debug(f"User set image height: {height}")
                    generation.height = height
                    self.trace.attributes["image_height"] = height
                if width := get_image_width(self.user_profile):
                    logger.debug(f"User set image width: {width}")
                    self.trace.attributes["image_width"] = width
                    generation.width = width
                if nbr_images := get_nbr_images_to_generate(self.user_profile):
                    logger.debug(f"User set number of images to generate: {nbr_images}")
                    self.trace.attributes["images_to_generate"] = nbr_images
                    generation.images_to_generate = nbr_images
                if quality := get_image_quality(self.user_profile):
                    logger.debug(f"User set quality: {quality}")
                    self.trace.attributes["image_quality"] = quality
                    generation.quality = quality
            resp: DSSLLMImageGenerationResponse = generation.execute()
            handle_response_trace(resp)
            question_context = {}
            trace_response = {}
            trace_response["status"] = "ok" if resp.success else "error"
            if resp.success:
                logger.debug("Image generation was successful")
                images = []
                trace_response["images"] = [] # type: ignore
                for image in resp._raw["images"]:
                    image_data = image["data"]
                    image_format = detect_image_format(base64.b64decode(image_data)) or "png"
                    logger.debug(f"Image type: {image_format}")
                    image_b64 = f"data:image/{image_format};base64," + image_data
                    images.append(
                        {
                            "file_data": image_b64,
                            "file_format": image_format,
                            "referred_file_path": self.referred_image if self.referred_image else "",
                        }
                    )
                    trace_response["images"].append({"file_data": "INLINE_IMAGE", "file_format": image_format}) # type: ignore
                question_context["images"] = images  # type: ignore
                question_context["user_profile"] = self.user_profile  # type: ignore
            else:
                logger.error(f"Image generation failed: {resp._raw}")
                trace_response["error_response"] = resp._raw
                resp = resp._raw
                message = "An error occurred while generating the image. If you changed some image generation settings, please try again with the default settings."
                if resp.get("errorMessage"):
                    error_json = {}
                    # Extract error information from the model's response
                    if "response: " in resp["errorMessage"]:
                        error_json_str = resp["errorMessage"].split("response: ", 1)[1]
                        error_json = json.loads(error_json_str)
                        error_json = error_json.get("error", {})
                    else:
                        error_json = json.loads(resp["errorMessage"])
                    if "message" in error_json:
                        message += " Here is the model's message: " + error_json.get("message", "")
                question_context["answer"] = message
            logger.debug(
                f"Time ===> taken by run_image_generation_query: {round((datetime.now() - datetime.strptime(start_time, TIME_FORMAT)).total_seconds(), 2)} secs"
            )
            self.trace.outputs["response"] = trace_response
            add_llm_step_trace(self.trace.to_dict())
            yield {"step": LLMStep.STREAMING_END}
            yield NoRetrievalChain(self.llm).get_as_json(question_context)
        except Exception as e:
            logger.exception(f"Error in image generation: {e}")
            self.trace.outputs["response"] = {"status": "error", "error_response": f"Error in image generation: {e}"}
            add_llm_step_trace(self.trace.to_dict())
            question_context["answer"] = "An error occurred while generating the image."
            yield NoRetrievalChain(self.llm).get_as_json(question_context)
