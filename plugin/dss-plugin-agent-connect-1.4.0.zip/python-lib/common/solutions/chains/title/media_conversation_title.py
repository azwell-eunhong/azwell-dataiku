from typing import List

from common.backend.constants import CONVERSATION_DEFAULT_NAME, DEFAULT_TITLE_GENERATION_ERROR, PROMPT_SEPARATOR_LENGTH
from common.backend.models.base import MediaSummary
from common.backend.utils.dataiku_api import dataiku_api
from common.backend.utils.llm_utils import (
    get_alternative_llm,
    get_llm_completion,
    handle_response_trace,
)
from common.llm_assist.logging import logger
from common.solutions.chains.title.conversation_title_chain import (
    ConversationTitleChainHandler,
)
from common.solutions.prompts.conversations import MEDIA_QA_CONVERSATION_TITLE_PROMPT
from dataiku.langchain.dku_llm import DKULLM
from dataikuapi.dss.llm import DSSLLMCompletionQuery, DSSLLMCompletionResponse


class SummaryTitler(ConversationTitleChainHandler):
    def __init__(self) -> None:
        super().__init__(MEDIA_QA_CONVERSATION_TITLE_PROMPT)
        self.webapp_config = dataiku_api.webapp_config
        self.media_conversation_title_prompt = self.get_prompt()

    def list_summaries(self, summaries: List[MediaSummary]) -> str:
        folder = dataiku_api.folder_handle
        all_summaries = ""
        if len(summaries) < 1:
            raise Exception("No media summaries found.")
        all_summaries += f"""
            {'-'*PROMPT_SEPARATOR_LENGTH} START OF SUMMARIES {'-'*PROMPT_SEPARATOR_LENGTH}
            """
        for media_summary in summaries:
            original_file_name = media_summary.get("original_file_name", "")
            topics = media_summary.get("topics", [])
            metadata_path = media_summary.get("metadata_path")
            if not metadata_path:
                logger.error(f"metadata_path is not provided for document {original_file_name}")
                raise Exception(f"metadata_path is not provided for document {original_file_name}")
            extract_summary = folder.read_json(metadata_path)
            summary_text = extract_summary.get("summary", "")
            all_summaries += f"""
            File: {original_file_name}
            Topics: {topics}
            Summary: {summary_text}
            {'-'*PROMPT_SEPARATOR_LENGTH}
            """
        all_summaries += f"{'-'*PROMPT_SEPARATOR_LENGTH} END OF SUMMARIES {'-'*PROMPT_SEPARATOR_LENGTH}"
        return all_summaries

    def generate_summary_title(self, summaries: List[MediaSummary]) -> str:
        media_summaries: str = self.list_summaries(summaries)
        prompt_message = self.media_conversation_title_prompt\
                    .invoke(dict(generated_content=media_summaries))\
                    .to_string()
        title_llm: DKULLM = get_alternative_llm("title_llm_id")
        completion: DSSLLMCompletionQuery = get_llm_completion(title_llm)
        completion.with_message(prompt_message)
        conversation_title = CONVERSATION_DEFAULT_NAME
        try:
            resp: DSSLLMCompletionResponse = completion.execute()
            handle_response_trace(resp)
            conversation_title = str(resp.text) if resp.text else CONVERSATION_DEFAULT_NAME
            if error_message := resp._raw.get("errorMessage"):
                logger.error(error_message)
            logger.debug(f"conversation_title: {conversation_title}")
            return conversation_title
        except Exception as e:
            logger.exception(f"{DEFAULT_TITLE_GENERATION_ERROR}: {e}.")
            return CONVERSATION_DEFAULT_NAME