from langchain.prompts import ChatPromptTemplate


class ConversationTitleChainHandler:
    def __init__(self, system_prompt: str):
        self.chain = None
        title_user_prompt = """
        Create the title based on the following generated text
        # --- START OF GENERATED TEXT ---
        {generated_content}
        # --- END OF GENERATED TEXT ---
        Your suggested title as string:
        """
        self._prompt = ChatPromptTemplate.from_messages(
        [("system", system_prompt), ("user", title_user_prompt)]
    )

    def get_prompt(self) -> ChatPromptTemplate:
        return self._prompt