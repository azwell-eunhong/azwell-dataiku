import time
from abc import ABC, abstractmethod
from collections.abc import Generator
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Union

from common.backend.models.base import (
    ConversationParams,
    LlmHistory,
    LLMStep,
    LLMStepDesc,
    MediaSummary,
    RetrievalSummaryJson,
)
from common.backend.utils.context_utils import TIME_FORMAT, LLMStepName
from common.backend.utils.dataiku_api import dataiku_api
from common.backend.utils.llm_utils import (
    append_summaries_to_completion_msg,
    get_llm_capabilities,
    get_llm_completion,
    handle_response_trace,
    parse_error_messages,
)
from common.llm_assist.logging import logger
from dataiku.core.knowledge_bank import MultipartContext
from dataiku.langchain.dku_llm import DKULLM
from dataikuapi.dss.llm import (
    DSSLLMCompletionQuery,
    DSSLLMCompletionQueryMultipartMessage,
    DSSLLMCompletionResponse,
    DSSLLMStreamedCompletionChunk,
    DSSLLMStreamedCompletionFooter,
)
from dataikuapi.utils import DataikuException
from langchain.memory import ConversationBufferMemory
from langchain_core.prompt_values import PromptValue


class GenericAnswersChain(ABC):
    # Abstract class for Answers chains
    # Implement all abstract properties & methods in the child class
    def __init__(self):
        self._forced_non_streaming = False

    @property
    def forced_non_streaming(self):
        return self._forced_non_streaming

    @forced_non_streaming.setter
    def forced_non_streaming(self, value):
        if isinstance(value, bool):
            self._forced_non_streaming = value
        else:
            raise ValueError("forced_non_streaming must be a boolean")

    @property
    def webapp_config(self):
        return dataiku_api.webapp_config

    @property
    @abstractmethod
    def qa_chain(self) -> Any:
        raise NotImplementedError("Subclasses must implement qa_chain property")

    @property
    @abstractmethod
    def act_like_prompt(self) -> str:
        raise NotImplementedError("Subclasses must implement act_like_prompt property")

    @property
    @abstractmethod
    def system_prompt(self) -> str:
        raise NotImplementedError("Subclasses must implement system_prompt property")

    @property
    @abstractmethod
    def llm(self) -> DKULLM:
        raise NotImplementedError("Subclasses must implement llm property")

    @property
    @abstractmethod
    def computed_prompt(self) -> PromptValue:
        raise NotImplementedError("Subclasses must implement computed_prompt property")

    @property
    @abstractmethod
    def chain_purpose(self) -> str:
        raise NotImplementedError("Subclasses must implement chain_purpose property")

    @abstractmethod
    def load_role_and_guidelines_prompts(self, params: ConversationParams):
        raise NotImplementedError("Subclasses must implement load_role_and_guidelines_prompts method")

    @abstractmethod
    def create_chain(self, params: ConversationParams) -> Any:
        raise NotImplementedError("Subclasses must implement create_chain method")

    def prepare_qa_chain(self, params: ConversationParams) -> None:
        self.load_role_and_guidelines_prompts(params)
        self.create_chain(params)

    @abstractmethod
    def get_computing_prompt_step(self, params: ConversationParams) -> LLMStep:
        raise NotImplementedError("Subclasses must implement get_computing_prompt_step method")

    @abstractmethod
    def get_querying_step(self, params: ConversationParams) -> LLMStep:
        raise NotImplementedError("Subclasses must implement get_querying_step method")

    @abstractmethod
    def finalize_streaming(
        self, params: ConversationParams, question_context: Union[str, Dict[str, Any], List[str]]
    ) -> RetrievalSummaryJson:
        raise NotImplementedError("Subclasses must implement finalize_streaming method")

    @abstractmethod
    def finalize_non_streaming(
        self, params: ConversationParams, question_context: Union[str, Dict[str, Any], List[str]]
    ) -> RetrievalSummaryJson:
        raise NotImplementedError("Subclasses must implement finalize_non_streaming method")

    @abstractmethod
    def create_computed_prompt(
        self,
        params: ConversationParams,
    ) -> Tuple[MultipartContext, PromptValue, Dict[str, Any]]:
        raise NotImplementedError("Subclasses must implement create_computed_prompt method")

    @abstractmethod
    def get_as_json(
        self,
        generated_answer: Union[str, Dict[str, Any], List[str]],
        user_profile: Optional[Dict[str, Any]] = None,
    ) -> RetrievalSummaryJson:
        logger.error("get_as_json method not implemented")
        return {}

    @abstractmethod
    def create_query_from_history_and_update_params(
        self, chat_history: List[LlmHistory], user_query: str, params: ConversationParams
    ) -> ConversationParams:
        return params

    def __run_non_streaming_query(
        self,
        params: ConversationParams,
        completion: DSSLLMCompletionQuery,
        question_context: Dict[str, Any],
    ) -> Generator[Union[LLMStepDesc, RetrievalSummaryJson], Any, None]:
        start_time: str = datetime.now().strftime(TIME_FORMAT)
        global_start_time = params.get("global_start_time")
        if not global_start_time:
            raise Exception("global_start_time is not provided")
        response = ""
        step = self.get_querying_step(params)
        logger.debug({"step": step.name})
        yield {"step": step}
        try:
            resp: DSSLLMCompletionResponse = completion.execute()
            handle_response_trace(resp)
            response = str(resp.text)
            if not resp.text and resp.errorMessage:
                response = resp.errorMessage
            logger.debug(f"""Time ===> taken by getting first chunk: {round((datetime.now() - datetime.strptime(start_time, TIME_FORMAT)).total_seconds(), 2)} secs
            Time ===> GLOBAL taken by getting first chunk: {(time.time() - global_start_time):.2f} secs
            """)

        except Exception as e:
            msg = "Error when calling LLM API"
            logger.exception(f"{msg}: {e}.")
            result = self.finalize_streaming(params, msg)
            yield result

        question_context["answer"] = response
        yield self.finalize_non_streaming(params, question_context)

    def __run_streaming_query(
        self, params: ConversationParams, completion: DSSLLMCompletionQuery, question_context: Dict[str, Any]
    ) -> Generator[
        Union[
            DSSLLMStreamedCompletionChunk,
            DSSLLMStreamedCompletionFooter,
            LLMStepDesc,
            RetrievalSummaryJson,
        ],
        Any,
        None,
    ]:
        start_time: str = datetime.now().strftime(TIME_FORMAT)
        global_start_time = params.get("global_start_time")
        if not global_start_time:
            raise Exception("global_start_time is not provided")
        log_time = True
        try:
            chain_purpose: str = params.get("chain_purpose") or LLMStepName.UNKNOWN.value
            for chunk in completion.execute_streamed():
                yield chunk
                if log_time:
                    if global_start_time:
                        logger.debug(f"""Time ===> taken by getting first chunk: {round((datetime.now() - datetime.strptime(start_time, TIME_FORMAT)).total_seconds(), 2)} secs
                        Time ===> GLOBAL taken by getting first chunk: {(time.time() - global_start_time):.2f} secs""")
                    else:
                        logger.debug(
                            f"Time ===> taken by getting first chunk: {round((datetime.now() - datetime.strptime(start_time, TIME_FORMAT)).total_seconds(), 2)} secs"
                        )
                    log_time = False
                if isinstance(chunk, DSSLLMStreamedCompletionFooter):
                    handle_response_trace(chunk)
            yield {"step": LLMStep.STREAMING_END}
            result = self.finalize_streaming(params, question_context)
            if result:
                yield result
        except DataikuException as e:
            logger.exception(f"LLM step {chain_purpose} failed with DataikuException: {e}")
            message = parse_error_messages(e)
            error_message = "LLM did not respond correctly. " + message
            yield DSSLLMStreamedCompletionChunk({"text": error_message})
            yield DSSLLMStreamedCompletionFooter({"finishReason": "error", "errorMessage": error_message})
        except Exception as e:
            msg = "Error when calling LLM API"
            logger.exception(f"{msg}: {e}.")
            result = self.finalize_streaming(params, msg)
            yield result

    def __create_completion_query(
        self, computed_prompt: PromptValue, params: ConversationParams, multipart_context: MultipartContext
    ) -> DSSLLMCompletionQuery:
        media_summaries: List[MediaSummary] = params.get("media_summaries") or []
        previous_media_summaries: List[MediaSummary] = params.get("previous_media_summaries") or []
        summaries = media_summaries + previous_media_summaries
        completion: DSSLLMCompletionQuery = get_llm_completion(self.llm)
        completion.with_message(computed_prompt.to_string(), role="system")
        if summaries:
            msg: DSSLLMCompletionQueryMultipartMessage = completion.new_multipart_message(role="user")
            # Commented this code for now as we don't always have summaries so the decision chain would need change
            # Later it can be used in other chains as well
            # selected_titles: List[str]
            # if self_service_decision := params.get("self_service_decision"):
            #     documents = self_service_decision.get("documents")
            #     selected_titles = documents if isinstance(documents, list) else []
            #     selected_summaries = [s for s in media_summaries if s.get("original_file_name") in selected_titles]
            # else:
            #     logger.warn("No self service decision provided")
            selected_summaries = summaries
            append_summaries_to_completion_msg(selected_summaries, msg)
        if multipart_context:
            multipart_context.add_to_completion_query(completion, role="user")

        completion.with_message(params.get("user_query", ""), role="user")
        return completion

    def format_history(self, chat_history: List[LlmHistory]):
        return [(item["input"], item["output"]) for item in chat_history]

    def run_completion_query(
        self, params: ConversationParams, memory: ConversationBufferMemory
    ) -> Generator[
        Union[
            LLMStepDesc,
            RetrievalSummaryJson,
            DSSLLMStreamedCompletionChunk,
            DSSLLMStreamedCompletionFooter,
        ],
        Any,
        None,
    ]:
        self.memory = memory
        self.prepare_qa_chain(params)

        yield {"step": self.get_computing_prompt_step(params)}

        multipart_context, computed_prompt, question_context = self.create_computed_prompt(params)

        completion = self.__create_completion_query(computed_prompt, params, multipart_context)

        llm_capabilities = get_llm_capabilities()
        if llm_capabilities["streaming"] and not self.forced_non_streaming:
            yield from self.__run_streaming_query(
                params=params,
                completion=completion,
                question_context=question_context,
            )
        else:
            yield from self.__run_non_streaming_query(
                params=params, completion=completion, question_context=question_context
            )

    def load_default_role_and_guidelines_prompts(self) -> tuple:
        act_like_prompt = dataiku_api.webapp_config.get("primer_prompt", "")
        system_prompt = dataiku_api.webapp_config.get(
            "system_prompt",
            "The following is a friendly conversation between a human and an AI. The AI is talkative and provides lots of specific details from its context. If the AI does not know the answer to a question, it truthfully says it does not know.",
        )
        return act_like_prompt, system_prompt
