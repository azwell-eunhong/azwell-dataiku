
import unittest
from typing import List, cast

from common.backend.models.base import RetrieverMode, Source
from common.backend.utils.sources_formatter import format_sources, sources_are_old_format


class TestSourcesFormatter(unittest.TestCase):

    # Note: In this test, we are using a raw list of dictionaries and casting them to the expected typed model.
    # This approach is chosen because the dictionaries are derived directly from a specific use case, ensuring they contain
    # the correct data structure. 

    NEW_DB_FORMAT = [
        {
            "toolCallDescription": "Used Database: kb_cooking_stuff_embedded",
            "items": [
                {
                    "type": "RECORDS",
                    "records": {
                        "rows": [{"total_questions": 45}],
                        "columns": [
                            {
                                "name": "total_questions",
                                "label": "total_questions",
                                "field": "total_questions",
                                "align": "left",
                            }
                        ],
                        "query": 'SELECT COUNT("question") AS "total_questions"\n  FROM "ANSWERS_kitchen_history"\n  LIMIT 50',
                    },
                    "generatedSqlQuery": 'SELECT COUNT("question") AS "total_questions"\n  FROM "ANSWERS_kitchen_history"\n  LIMIT 50',
                    "usedTables": "kitchen_history",
                }
            ],
        }
    ]
    
    OLD_DB_FORMAT = [{
        'sample': {
            'rows': [{
                'total_questions': 45
            }],
            'columns': [{
                'name': 'total_questions',
                'label': 'total_questions',
                'field': 'total_questions',
                'align': 'left'
            }],
            'query': 'SELECT COUNT("question") AS "total_questions"\n  FROM "ANSWERS_kitchen_history"\n  LIMIT 50'
        },
        'metadata': {
            'source_title': 'kitchen_history'
        }
    }]

    NEW_KB_FORMAT = [{
        'toolCallDescription': 'Used Knowledge Bank: kb_cooking_stuff_embedded',
        'items': [{
            'type': 'SIMPLE_DOCUMENT',
            'metadata': {
                'source_title': 'Curry Spices and Their Combinations',
                'source_url': 'https://example.com/curry',
                'source_thumbnail_url': '',
                'tags': [{
                    'name': 'Category',
                    'value': 'Ingredients & Flavors',
                    'type': 'string'
                }, {
                    'name': 'Source',
                    'value': 'https://example.com/curry',
                    'type': 'string'
                }, {
                    'name': 'Title',
                    'value': 'Curry Spices and Their Combinations',
                    'type': 'string'
                }]
            },
            'title': 'Curry Spices and Their Combinations',
            'url': 'https://example.com/curry',
            'textSnippet': 'Curry pairs well with coconut, ginger, and chicken in sauces.',
            'images': []
        }, {
            'type': 'SIMPLE_DOCUMENT',
            'metadata': {
                'source_title': 'Indian Spices: Curry, Turmeric, Cumin',
                'source_url': 'https://example.com/indian-spices',
                'source_thumbnail_url': '',
                'tags': [{
                    'name': 'Category',
                    'value': 'Ingredients & Flavors',
                    'type': 'string'
                }, {
                    'name': 'Source',
                    'value': 'https://example.com/indian-spices',
                    'type': 'string'
                }, {
                    'name': 'Title',
                    'value': 'Indian Spices: Curry, Turmeric, Cumin',
                    'type': 'string'
                }]
            },
            'title': 'Indian Spices: Curry, Turmeric, Cumin',
            'url': 'https://example.com/indian-spices',
            'textSnippet': 'Indian spices such as curry, turmeric, and cumin add depth and warmth to curries and rice dishes.',
            'images': []
        }, {
            'type': 'SIMPLE_DOCUMENT',
            'metadata': {
                'source_title': 'Dry Spices in Cakes',
                'source_url': 'https://example.com/dry-spices',
                'source_thumbnail_url': '',
                'tags': [{
                    'name': 'Category',
                    'value': 'Ingredients & Flavors',
                    'type': 'string'
                }, {
                    'name': 'Source',
                    'value': 'https://example.com/dry-spices',
                    'type': 'string'
                }, {
                    'name': 'Title',
                    'value': 'Dry Spices in Cakes',
                    'type': 'string'
                }]
            },
            'title': 'Dry Spices in Cakes',
            'url': 'https://example.com/dry-spices',
            'textSnippet': 'Sweet spices such as cinnamon, nutmeg, and ginger bring warmth and depth to cakes and desserts.',
            'images': []
        }]
    }]

    OLD_KB_FORMAT = [{
        'excerpt': 'Curry pairs well with coconut, ginger, and chicken in sauces.',
        'metadata': {
            'source_title': 'Curry Spices and Their Combinations',
            'source_url': 'https://example.com/curry',
            'source_thumbnail_url': '',
            'tags': [{
                'name': 'Category',
                'value': 'Ingredients & Flavors',
                'type': 'string'
            }, {
                'name': 'Source',
                'value': 'https://example.com/curry',
                'type': 'string'
            }, {
                'name': 'Title',
                'value': 'Curry Spices and Their Combinations',
                'type': 'string'
            }]
        },
        'images': []
    }, {
        'excerpt': 'Indian spices such as curry, turmeric, and cumin add depth and warmth to curries and rice dishes.',
        'metadata': {
            'source_title': 'Indian Spices: Curry, Turmeric, Cumin',
            'source_url': 'https://example.com/indian-spices',
            'source_thumbnail_url': '',
            'tags': [{
                'name': 'Category',
                'value': 'Ingredients & Flavors',
                'type': 'string'
            }, {
                'name': 'Source',
                'value': 'https://example.com/indian-spices',
                'type': 'string'
            }, {
                'name': 'Title',
                'value': 'Indian Spices: Curry, Turmeric, Cumin',
                'type': 'string'
            }]
        },
        'images': []
    }, {
        'excerpt': 'Sweet spices such as cinnamon, nutmeg, and ginger bring warmth and depth to cakes and desserts.',
        'metadata': {
            'source_title': 'Dry Spices in Cakes',
            'source_url': 'https://example.com/dry-spices',
            'source_thumbnail_url': '',
            'tags': [{
                'name': 'Category',
                'value': 'Ingredients & Flavors',
                'type': 'string'
            }, {
                'name': 'Source',
                'value': 'https://example.com/dry-spices',
                'type': 'string'
            }, {
                'name': 'Title',
                'value': 'Dry Spices in Cakes',
                'type': 'string'
            }]
        },
        'images': []
    }]


    def test_sources_need_formatting(self):
        assert sources_are_old_format(self.OLD_KB_FORMAT) is True
        assert sources_are_old_format(self.OLD_DB_FORMAT) is True
        assert sources_are_old_format(self.NEW_KB_FORMAT) is False
        assert sources_are_old_format(self.NEW_DB_FORMAT) is False


    def test_answers_format_conversion_KB(self):
        result = format_sources(cast(List[Source], self.OLD_KB_FORMAT), tool_type=RetrieverMode.KB.value, tool_name="Knowledge Bank: kb_cooking_stuff_embedded")
        assert result == self.NEW_KB_FORMAT

    def test_answers_format_conversion_DB(self):
        result = format_sources(cast(List[Source], self.OLD_DB_FORMAT), tool_type=RetrieverMode.DB.value, tool_name="Database: kb_cooking_stuff_embedded")
        assert result == self.NEW_DB_FORMAT