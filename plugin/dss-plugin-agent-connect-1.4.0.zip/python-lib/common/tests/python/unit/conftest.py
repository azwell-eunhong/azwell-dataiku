import sys
from unittest.mock import MagicMock

mock_langchain = MagicMock()
mock_dku_llm = MagicMock()

# Create a fake module structure

sys.modules["dataiku.langchain"] = MagicMock()
sys.modules["dataiku.langchain.dku_llm"] = mock_dku_llm

sys.modules["dataiku.llm"] = MagicMock()
sys.modules["dataiku.llm.tracing"] = MagicMock()

# Mock SpanBuilder if used
sys.modules["dataiku.llm.tracing"].SpanBuilder = MagicMock()

sys.modules["dataiku.core.knowledge_bank"] = MagicMock()
sys.modules["dataiku.core.knowledge_bank.MultipartContext"] = MagicMock()

sys.modules["common.backend.utils.dataiku_api"] = MagicMock()
# Mock DKULLM class if needed
mock_dku_llm.DKULLM = MagicMock()