from flask import g


def get_auth_user():
    return g.get("authIdentifier", "user_not_found")

def get_auth_agent():
    return g.get("userAgent", "user_agent_not_found")