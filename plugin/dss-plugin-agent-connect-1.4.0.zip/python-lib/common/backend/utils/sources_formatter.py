from typing import Dict, List, Union, cast

from common.backend.models.base import (
    AggregatedToolSources,
    Source,
)


def sources_are_old_format(sources: Union[List[Dict], List[Source]]) -> bool:
    keys_to_check = ["toolCallDescription", "items"]
    for source in sources:
        if any(key in source for key in keys_to_check):
            return False
    return True


def format_sources_if_requried(sources: Union[List[Dict], List[Source]], tool_type: str, tool_name: str) -> List[AggregatedToolSources]:
    """
    Take a source list, checks its format and enrich it to match
    agents-connect formatting if necessary
    """
    if sources:
        if sources_are_old_format(sources):  
            return format_sources(cast(List[Source], sources), tool_type, tool_name) # cast for type checker, will not affect runtime
    return cast(List[AggregatedToolSources], sources) # cast for type checker, will not affect runtime


def format_sources(sources: List[Source], tool_type: str, tool_name: str) -> List[AggregatedToolSources]: 
    """
    Wraps a given list of sources into a new dataset compatible with
    agents-connect format.
    """

    if not sources:
        return []

    items = []
    for source in sources : 
        if tool_type == "kb":
            items.append(dict(
                type="SIMPLE_DOCUMENT",
                metadata=source.get("metadata", {}),
                title=source.get("metadata", {}).get("source_title", ""),
                url=source.get("metadata", {}).get("source_url", ""),
                textSnippet=source.get("excerpt"),
                images=source.get("images"),
            ))
        else:
            if source.get("sample") or source.get("metadata"):
                items.append(dict(
                    type="RECORDS",
                    records=source.get("sample", {}),
                    generatedSqlQuery=source.get("sample", {}).get("query", ""),
                    usedTables=source.get("metadata", {}).get("source_title", ""), 
                ))
            else:
                items.append(source)

    return ([{
        "toolCallDescription": f"Used {tool_name}",
        "items": items
    }])

