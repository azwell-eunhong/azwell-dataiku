import re
from typing import Any, Dict, List, Union


def escape_dictionary_for_langchain(dictionary: Union[Dict[str, Any], str, List[Any]]) -> str:
    """Escapes the string associated with a dictionary.
    The string brackets are escaped so that they can be used in a langchain prompt.

    :param dictionary: dict: The dictionary to escape.

    :returns: dictionary_str: str: The escaped dictionary.
    """
    dictionary_str = str(dictionary)
    dictionary_str = re.sub(r'\{', '{{', dictionary_str)
    dictionary_str = re.sub(r'\}', '}}', dictionary_str)
    dictionary_str = dictionary_str.replace('None', 'null')
    dictionary_str = dictionary_str.replace('True', 'true')
    dictionary_str = dictionary_str.replace('False', 'false')
    return dictionary_str