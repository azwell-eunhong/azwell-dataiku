import base64
import imghdr
import io
from typing import Dict, Optional

import dataiku
from common.backend.utils.dataiku_api import dataiku_api
from common.llm_assist.logging import logger


def get_empty_image_base64():
    # This is a 1x1 transparent PNG encoded in base64
    return "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/wcAAgAB/ivFZ8sAAAAASUVORK5CYII="

def b64encode_image_from_path(file_path: Optional[str] = None):
    """
    Encodes an image from a specified file path to a base64-encoded string.

    Parameters:
    - file_path (str): The path to the image file to be encoded. This path must point to a valid
    image file in the managed folder configured in the webapp.

    Returns:
    - str: A base64-encoded string representing the image. This string can be directly used in data URIs
        or for storage in text-based formats.
    """
    if not file_path:
        raise ValueError("file_path must be set.")

    try:
        config: Dict[str, str] = dataiku_api.webapp_config
        upload_folder: str = config["upload_folder"]
        file_folder = dataiku.Folder(upload_folder)
        with file_folder.get_download_stream(file_path) as stream:
            file_content = stream.read()
        base64_encoded = base64.b64encode(file_content)
        img_b64 = base64_encoded.decode("utf-8")
        return img_b64
    except Exception as err:
        logger.exception(f"Error getting file {file_path} from upload folder, error: {err}")
        return get_empty_image_base64()


def detect_image_format(image_bytes):
    # Open image bytes as bytes stream
    byte_stream = io.BytesIO(image_bytes)
    # Use imghdr.what() method which takes a byte stream
    image_format = imghdr.what(byte_stream)

    return image_format


def get_image_bytes(image_path: str) -> Optional[str]:
    folder = dataiku_api.folder_handle
    # List all files in the folder
    files = folder.list_paths_in_partition()
    image_bytes = None
    if image_path in files or "/"+image_path in files:
        # Read the file as bytes
        with folder.get_download_stream(image_path) as stream:
            image_bytes = stream.read()
        logger.debug("Successfully retrieved the image as bytes.")
    else:
        logger.debug(f"File '{image_path}' not found in the folder.")
    return image_bytes
