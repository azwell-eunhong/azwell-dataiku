import base64
from io import BytesIO
from typing import Dict, List, Union

import pypdfium2 as pdfium  # type: ignore
from common.backend.constants import (
    BLACKLISTED_MIME_TYPES,
    CHAIN_MIME_TYPES,
    DOCUMENT_EXTENSIONS,
    IMAGE_EXTENSIONS,
    PROMPT_SEPARATOR_LENGTH,
)
from common.backend.models.base import MediaSummary, UploadFileError
from common.backend.utils.dataiku_api import dataiku_api
from common.backend.utils.picture_utils import b64encode_image_from_path
from common.backend.utils.upload_utils import get_checked_config
from common.llm_assist.logging import logger
from dataikuapi.dss.llm import DSSLLMCompletionQueryMultipartMessage
from dataikuapi.utils import DataikuException
from werkzeug.datastructures import FileStorage

webapp_config: Dict[str, str] = dataiku_api.webapp_config


def load_pdf_images_from_bytes(pdf_bytes: bytes) -> List[str]:
    b64_images = []
    try:
        pdf_document = pdfium.PdfDocument(pdf_bytes)
        for page in pdf_document:
            pil_image = page.render().to_pil()
            with BytesIO() as buffered:
                pil_image.save(buffered, format="PNG")
                b64_image = base64.b64encode(buffered.getvalue()).decode("utf-8")
                b64_images.append(b64_image)
        del pil_image
        del b64_image
        return b64_images
    except IOError as e:
        logger.exception(f"Unable to parse document to image: {e}")
        raise Exception(f"Unable to parse document to image: {e}")


def load_pdf_images_from_file(file_path: str) -> List[str]:
    folder = dataiku_api.folder_handle
    b64_images = []
    try:
        with folder.get_download_stream(file_path) as f:
            pdf_bytes = f.read()
            pdf_document = pdfium.PdfDocument(pdf_bytes)
        for page in pdf_document:
            pil_image = page.render().to_pil()
            with BytesIO() as buffered:
                pil_image.save(buffered, format="PNG")
                b64_image = base64.b64encode(buffered.getvalue()).decode("utf-8")
                b64_images.append(b64_image)
        del pil_image
        del b64_image
        return b64_images
    except IOError as e:
        logger.exception(f"Unable to parse document to image: {e}")
        raise Exception(f"Unable to parse document to image: {e}")


def file_path_to_image_parts(
    summary: MediaSummary, msg: DSSLLMCompletionQueryMultipartMessage
) -> DSSLLMCompletionQueryMultipartMessage:
    file_path: Union[str, None] = summary.get("file_path")
    original_file_name: Union[str, None] = summary.get("original_file_name")
    if file_path is None or original_file_name is None:
        raise Exception("No file path or original file name provided")
    try:
        # currently only pdf can can be classed as DOCUMENT_AS_IMAGE
        if (
            "." in file_path
            and file_path.rsplit(".", 1)[1].lower() in DOCUMENT_EXTENSIONS
        ):
            b64_images: List[str] = load_pdf_images_from_file(file_path)
            n_page: int = len(b64_images)
            for page, img_b64 in enumerate(b64_images):
                msg.with_text(
                    f"{original_file_name}: Page {page+1} of {n_page}"
                ).with_inline_image(img_b64)
            logger.debug(f"PDF File {original_file_name} converted to image and inlined in completion")
        elif (
            "." in file_path and file_path.rsplit(".", 1)[1].lower() in IMAGE_EXTENSIONS
        ):
            img_b64 = b64encode_image_from_path(file_path)
            msg.with_text(f"Image: {original_file_name}").with_inline_image(img_b64)
            logger.debug(f"Image {original_file_name} inlined in completion")
        else:
            raise Exception(f"Unknown file extension type for file {file_path}")
    except DataikuException as e:
        logger.exception(f"Dataiku API Error: {e}")
        raise Exception(f"Dataiku API Error: {e}")
    except FileNotFoundError:
        logger.exception("File not found in the managed folder.")
        raise Exception("File not found in the managed folder.")
    except IOError as e:
        logger.exception(f"I/O Error: {e}")
        raise Exception(f"I/O Error: {e}")
    except Exception as e:
        logger.exception(f"An unexpected error occurred: {e}")
        raise Exception(f"An unexpected error occurred: {e}")
    logger.debug(f"File {original_file_name} converted to image")
    return msg


def file_path_text_parts(
    summary: MediaSummary, msg: DSSLLMCompletionQueryMultipartMessage
) -> DSSLLMCompletionQueryMultipartMessage:
    original_file_name: Union[str, None] = summary.get("original_file_name")

    folder = dataiku_api.folder_handle
    try:
        metadata_path = summary.get("metadata_path")  # type: ignore
        if not metadata_path:
            logger.error(f"metadata_path is not provided for document")
            raise Exception("metadata_path is not provided for document")
        extract_summary = folder.read_json(metadata_path)
        logger.debug(f"Extracting text from {metadata_path}")
        msg.with_text(f"""{'-'*PROMPT_SEPARATOR_LENGTH} START OF DOCUMENT: {original_file_name} {'-'*PROMPT_SEPARATOR_LENGTH}
        Document Name: {original_file_name}
        {'Main Topics: '+str(extract_summary.get("topics"))if extract_summary.get("topics") else ''}
        Full Extracted Text:
        {extract_summary.get("full_extracted_text", "No text extracted")}
        {'-'*PROMPT_SEPARATOR_LENGTH} END OF DOCUMENT: {original_file_name}{'-'*PROMPT_SEPARATOR_LENGTH}
        """)
        logger.debug(f"Text extracted from {original_file_name}")
    except DataikuException as e:
        logger.exception(f"Dataiku API Error: {e}")
        raise Exception(f"Dataiku API Error: {e}")
    except FileNotFoundError:
        logger.exception("File not found in the managed folder.")
        raise Exception("File not found in the managed folder.")
    except IOError as e:
        logger.exception(f"I/O Error: {e}")
        raise Exception(f"I/O Error: {e}")
    except Exception as e:
        logger.exception(f"An unexpected error occurred: {e}")
        raise Exception(f"An unexpected error occurred: {e}")
    logger.debug(f"Text extracted from {original_file_name}")
    return msg


def allowed_file(file: FileStorage, multi_modal: bool) -> str:
    filename = str(file.filename)
    mimetype = file.mimetype
    logger.debug(f"File name: {filename}, MIME type: {mimetype}")

    allowed_extensions = DOCUMENT_EXTENSIONS
    allowed_mimetypes = CHAIN_MIME_TYPES["DOCUMENT"]
    if multi_modal:
        allowed_extensions = allowed_extensions.union(IMAGE_EXTENSIONS)
        allowed_mimetypes = allowed_mimetypes.union(CHAIN_MIME_TYPES["IMAGE"])
    if "." not in filename:
        raise Exception(UploadFileError.INVALID_FILE_TYPE.value)
    extension = filename.rsplit(".", 1)[1].lower()

    extension_permitted = extension in allowed_extensions
    mimetype_permitted = mimetype in allowed_mimetypes
    not_blacklisted_mimetype = mimetype not in BLACKLISTED_MIME_TYPES
    if not all ((extension_permitted, mimetype_permitted, not_blacklisted_mimetype)):
        raise Exception(UploadFileError.INVALID_FILE_TYPE.value)
    return extension


def get_file_data(file: FileStorage) -> bytes:
    file_data: bytes
    max_size_mb = int(get_checked_config("max_upload_size_mb"))
    max_content_length = max_size_mb * 1024 * 1024
    file_data = file.read()
    if len(file_data) == 0:
        raise Exception(UploadFileError.NO_SELECTED_FILE.value)
    if len(file_data) > max_content_length:
        raise Exception(UploadFileError.FILE_TOO_LARGE.value)
    file.seek(0)
    return file_data


def delete_files(file_paths: List[str]) -> None:
    folder = dataiku_api.folder_handle
    for path in file_paths:
        try:
            folder.delete_path(path)
        except Exception as e:
            logger.exception(f"Error occurred while deleting file: {e}")