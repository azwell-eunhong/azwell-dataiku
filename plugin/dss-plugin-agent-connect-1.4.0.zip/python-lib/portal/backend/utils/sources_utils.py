from typing import Any, Dict, List

from common.backend.utils.json_utils import coerce_to_dict


def convert_to_rows_and_columns(columns: List[str], data: List[Any]):
    rows = [dict(zip(columns, row)) for row in data]

    columns_formatted = [{"name": col, "label": col, "field": col, "align": "left"} for col in columns]

    return {"rows": rows, "columns": columns_formatted}


def process_agents_sources(sources):
    for source in sources:
        for item in source.get("items", []):
            if item.get("type") == "RECORDS" and "records" in item:
                item["records"] = convert_to_rows_and_columns(item["records"]["columns"], item["records"]["data"])
    return sources


def clean_images(images: List) -> List:
    return [coerce_to_dict(image) for image in images] if images else []


def _sources_are_old_format(sources: List[Dict]) -> bool:
    keys_to_check = ["toolCallDescription", "items"]
    for source in sources:
        if any(key in source for key in keys_to_check):
            return False
    return True


def process_answers_sources(sources, used_tool):
    if not _sources_are_old_format(sources):
        return sources

    tool_name = ""
    tool_type = ""
    if used_tool:
        tool_name = used_tool.get("alias", "") or used_tool.get("name", "")
        tool_type = used_tool.get("type", "")
        if tool_type == "kb":
            tool_name = f"Knowledge Bank: {tool_name}"
        elif tool_type == "db":
            tool_name = f"Database: {tool_name}"
    items = [
        {
            "toolCallDescription": "Used " + tool_name,
            "items": [
                dict(
                    type="SIMPLE_DOCUMENT",
                    metadata=source.get("metadata", {}),
                    title=source.get("metadata", {}).get("source_title", ""),
                    url=source.get("metadata", {}).get("source_url", ""),
                    textSnippet=source.get("excerpt"),
                    images=clean_images((source.get("images"))),
                )
                if tool_type == "kb"
                else dict(
                    type="RECORDS",
                    records=source.get("sample"),
                    generatedSqlQuery=used_tool.get("generatedSqlQuery", ""),
                    usedTables=used_tool.get("usedTables", []),
                )
                for source in sources
            ],
        }
    ]
    return items
