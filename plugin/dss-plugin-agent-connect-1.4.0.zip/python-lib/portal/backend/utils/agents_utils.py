from typing import Dict, List

import dataiku
from common.backend.models.base import (
    MediaSummary,
)
from common.llm_assist.logging import logger
from dataikuapi.dss.project import DSSProject
from portal.backend.utils.permissions_utils import user_has_access_to_project


def get_project_agent_mapping(current_project: DSSProject):
    return {
        llm.get("id"): llm.get("friendlyName")
        for llm in current_project.list_llms()
        if llm.get("id").startswith("agent")
    }


def get_project_agents(current_project: DSSProject) -> List[Dict[str, str]]:
    agents_map = get_project_agent_mapping(current_project)
    return [
        {
            "value": current_project.project_key + ":" + agent_id,
            "label": agent_name,
            "description": "",  # description will be filled manually by admin
        }
        for agent_id, agent_name in agents_map.items()
    ]


def list_selected_agents(payload):
    selected_agents = payload["rootModel"].get("agents_ids", [])
    selected_projects = payload["rootModel"].get("projects_keys", [])
    agents_map = map_agents_id_name(selected_projects, with_project_key=True)
    return [{"value": agent, "label": agents_map.get(agent)} for agent in selected_agents]


def list_agents_by_project(selected_projects) -> Dict[str, List[Dict[str, str]]]:
    client = dataiku.api_client()
    agents_by_project: Dict[str, List[Dict[str, str]]] = {}
    if not selected_projects:
        return agents_by_project
    for project_key in selected_projects:
        project_ob: DSSProject = client.get_project(project_key)
        agents = get_project_agents(project_ob)
        if agents:
            agents_by_project[project_key] = agents
    return agents_by_project


def map_agents_id_name(selected_projects, with_project_key: bool = False) -> Dict[str, str]:
    agents_by_project = list_agents_by_project(selected_projects)
    agents_map = {}
    for project_key, agents in agents_by_project.items():
        for agent in agents:
            agents_map[agent["value"]] = agent["label"] if not with_project_key else f"[{project_key}] {agent['label']}"
    return agents_map


def filter_agents_per_user(user: str, agents: List[str]) -> List[str]:
    accessible_agents = []
    projects_permissions: Dict[str, bool] = {}
    for agent in agents:
        project_key = agent.split(":")[0]
        if project_key in projects_permissions:
            if projects_permissions[project_key]:
                accessible_agents.append(agent)
            continue
        if user_has_access_to_project(user, project_key):
            accessible_agents.append(agent)
            projects_permissions[project_key] = True
        else:
            projects_permissions[project_key] = False
    return accessible_agents


def add_agent_uploads(
    previous_agents_uploads: Dict[str, Dict[str, MediaSummary]],
    agent_uploads: List[MediaSummary],
    agent_id: str,
):
    logger.debug(f"Adding agent uploads to previous uploads")
    # TODO should we keep preview + extracted_text or remove
    for upload in agent_uploads:
        file_name = upload.get("original_file_name", "")
        if file_name in previous_agents_uploads:
            previous_agents_uploads[file_name][agent_id] = upload
        else:
            previous_agents_uploads[file_name] = {agent_id: upload}
    return previous_agents_uploads
