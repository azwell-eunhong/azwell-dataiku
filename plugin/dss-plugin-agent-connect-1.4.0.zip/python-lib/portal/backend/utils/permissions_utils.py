from typing import Any, Dict, List

import dataiku
from common.llm_assist.logging import logger


def project_permissions(project_key: str) -> Dict[str, Any]:
    client = dataiku.api_client()
    project = client.get_project(project_key)
    permissions: Dict[str, Any] = project.get_permissions()
    return permissions

def get_user_groups(user: str) -> List[str]:
    client = dataiku.api_client()
    user_groups = client.get_user(user).get_settings().get_raw().get("groups", []) or [] #Needs admin rights
    logger.debug(f"User [{user}] groups: {user_groups}")
    return user_groups

def user_has_access_to_project(user: str, project_key: str) -> bool:
    permissions = project_permissions(project_key)
    client = dataiku.api_client()
    user_groups = get_user_groups(user) #Needs admin rights
    logger.debug(f"User [{user}] groups: {user_groups}")
    logger.debug(f"Project [{project_key}] permissions: {permissions}")
    if user in permissions.get("owner", ""):
        logger.debug("User is the admin to the project")
        return True
    elif any(
        group
        in {
            permission.get("group")
            for permission in permissions.get("permissions", [])
            if permission.get("readProjectContent", False)
        }
        or client.get_group(group).get_definition().get("admin", False)
        for group in user_groups
    ):
        logger.debug("User is part of the group that has access to the project")
        # check if user is part of the groups that have access to the project
        return True
    elif user in {
        permission.get("user")
        for permission in permissions.get("permissions", [])
        if permission.get("readProjectContent", False) or permission.get("admin", False)
    }:
        logger.debug("User is part of the users that have access to the project")
        return True
    else:
        logger.debug("User does not have access to the project")
        return False
