from portal.backend.routes import api
from portal.backend.utils.launch_utils import setup_app

setup_app(app)

app.register_blueprint(blueprint=api)

