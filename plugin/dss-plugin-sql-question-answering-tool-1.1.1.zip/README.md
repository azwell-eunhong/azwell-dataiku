# SQL Question Answering Tool

## Dev Environment Setup
Create an env in your preferred way. The example here uses pyenv and virtualenv.  

```
pyenv virtualenv 3.9.21 sql_tool_testing
pyenv local sql_tool_testing
pip install --upgrade pip

pip install -r code-env/python/spec/requirements.github.txt
pip install -r tests/python/unit/requirements.txt

```

## Basic Testing
Ensure that the sql_tool_testing env is activated.  
Run mypy tests using `make mypy`  
Run linting tests with ruff using `make lint`  
Run unit tests with `make unit`  
Run all the previously mentioned tests together with `make tests`  




## Basic Manual Testing Setup 
Install the plugin from github on the instance where you want to test manually. Once you’ve installed from github, if you don’t have any data to test on you can generate some with a python recipe  

```
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import pandas as pd
import numpy as np

np.random.seed(42)

n_rows = 20
n_cols = 4

data = {
    'Category': np.random.choice(['A', 'B', 'C', 'D'], size=n_rows),  # Categorical data
    'Value': np.random.randint(1, 100, size=n_rows),  # Numerical data
    'Score': np.random.uniform(0, 1, size=n_rows),  # Numerical data (float)
    'Group': np.random.choice(['X', 'Y'], size=n_rows)  # Categorical data
}

df = pd.DataFrame(data)

# Write recipe outputs
some_data = dataiku.Dataset("some_data")
some_data.write_with_schema(df)
```
Otherwise feel free to use your own SQL data to test on.
In your testing project, navigate to the agent tools and create a “SQL query” tool. If you don’t see it on the list at first, try a hard refresh of the page and next a restart of the dataiku instance.
After this, select a SQL connection matching the SQL dataset(s) you want to query and select an LLM connection to use.
Select the dataset or datasets that you would like to include and give a detailed description of the data under “Data context information”. For now, dataset descriptions and column descriptions are not included in the prompt so you have to add everything in “Data context information”. This means column descriptions and data types as well as how to understand the data.
If you chose to use the code snippet above to make the data then you can use the following text: 

> Answer the questions by leveraging the usage of the following dataset.
> This dataset is the results of a test done one a group of people, they had to answer different questions to a test and got a raw value between 1 and 100 + a score. Each user is part of a group.
> The table have the following columns :
> - Category : correspond to the user category inside its group, it can be A, B, C or D
> - Value: It's the raw value that the user got at the end of it's test (between 1 and 100)
> - Score: it's the evaluated score, between 0 and 1
> - Group: It's the original group to which belong the user.



Finally navigate to quick test. You can add your question in the format below
```
{
   "input": {
      "question": "how many D in the category column "
   },
   "context": {}
}
```
Once executed you can check the traces and logs to see what has been executed.
