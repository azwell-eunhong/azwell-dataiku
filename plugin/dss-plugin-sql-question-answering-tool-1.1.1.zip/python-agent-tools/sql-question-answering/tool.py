import logging
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import dataiku
import sql_tool_prompts  # type: ignore[import]
from dataiku.llm.agent_tools import BaseAgentTool
from dataiku.sql import toSQL
from dataikuapi.dss.llm import DSSLLM, DSSLLMCompletionQuery, DSSLLMCompletionResponse
from json_utils import extract_json  # type: ignore[import]
from sql_management import SQlManager  # type: ignore[import]
from sql_query_utils import (  # type: ignore[import]
    replace_tables_in_select_query,
    to_select_query,
)

PROMPT_DATE_FORMAT = "%Y-%m-%d %H:%M"


class SQLQueryTool(BaseAgentTool):
    def set_config(self, config, plugin_config) -> None:
        self.config = config
        self.max_query_attempts = 3
        self.config = config
        self.hard_sql_limit = self.config.get("hardSqlLimit", 200)
        datasets = self.config.get("datasets", [])
        api_client = dataiku.api_client()
        self.llm: DSSLLM = api_client.get_default_project().get_llm(self.config["llmId"])
        if not datasets:
            raise ValueError("No datasets provided for SQL query tool.")
        connection = self.config.get("connection", None)
        if not connection:
            raise ValueError("No connection provided for SQL query tool.")
        self.sql_manager = SQlManager(api_client, datasets, connection)

    def get_descriptor(self, tool) -> Dict[str, Any]:
        all_descriptions =  self.sql_manager.format_all_descriptions()

        return {
            "description": """Given a text query explaining the question to respond, this tool will:

1. Determine whether the datasets are likely to be able to respond the question
2. Generate a SQL query 
3. Execute the SQL query
4. Return the results

The question must be responded to with a single SQL query.

If the tool determines that the question cannot be responded to, it will return {"status": "cant_respond"}.

Here are the datasets and columns that the tool has access to:

%s""" % all_descriptions, # Cannot use f-string here as it is not supported in the tool descriptor
            "inputSchema" : {
                "$id": "https://dataiku.com/agents/tools/scrape/input",
                "title": "Input for the SQL querying tool",
                "type": "object",
                "properties" : {
                    "question" : {
                        "type": "string",
                        "description": "The question to respond"
                    }
                },
                "required": ["question"]
            }
        }


    def is_query_required(self, question: str) -> Optional[Dict[str, Any]]:
        with self.trace.subspan("Deciding whether SQL tool can answer the question") as subspan:
            decision_completion = self.llm.new_completion()
            decision_completion.with_message(sql_tool_prompts.DECISION_TO_USE_SYSTEM_PROMPT, "system")
            decision_completion.with_message(
                sql_tool_prompts.DECISION_TO_USE_USER_PROMPT_FMT.format(
                    todays_datetime=datetime.now().strftime(PROMPT_DATE_FORMAT),
                    datasets_descriptions=self.sql_manager.format_all_descriptions(),
                ),
                "user",
            )
            try:
                decision_completion.with_message(message=question, role="user")
                decision_response = decision_completion.execute()
                subspan.append_trace(decision_response.trace)
                if not decision_response.text and decision_response.errorMessage:
                    logging.exception(decision_response.errorMessage)
                    raise Exception(
                        f"Error while trying to decide whether to use SQL tool: {decision_response.errorMessage}"
                    )
                logging.info(f"Decision result: {decision_response.text}")
                decision_result: Dict[str, Any] = extract_json(decision_response.text)

                if "tables_and_columns" not in decision_result:
                    subspan.outputs["decision"] = "no"
                    self.source["items"].append({"type": "INFO", "textSnippet": "Declined to answer"})
                    return None

                subspan.outputs["decision"] = "yes"

                self.source["items"].append(
                    {"type": "INFO", "textSnippet": f"Decided to use {decision_result['tables_and_columns']}" }
                )
                return decision_result
            except Exception as e:
                msg = f"Error while trying to decide whether to use SQL tool: {e}"
                # TODO: is this required?
                self.source["items"].append( {"type": "ERROR", "textSnippet": msg})
                raise Exception(msg) 


    @staticmethod
    def format_previous_sql_errors(
        previous_sql_errors: str, json_query: Dict[str, Any], sql_query: str, error: str
    ) -> str:
        previous_sql_errors += sql_tool_prompts.QUERY_ERROR_FORMAT.format(
            json_query=json_query, sql_query=sql_query, error=error
        )
        return previous_sql_errors

    def get_query_completion(self, initial_user_prompt: str) -> DSSLLMCompletionQuery:
        completion: DSSLLMCompletionQuery = self.llm.new_completion()
        completion.with_message(sql_tool_prompts.QUERY_BUILDING_SYSTEM_PROMPT, "system")
        completion.with_message(initial_user_prompt, "user")
        return completion

    def get_query_fix_completion(self, initial_user_prompt: str, previous_sql_errors: str) -> DSSLLMCompletionQuery:
        completion: DSSLLMCompletionQuery = self.llm.new_completion()
        completion.with_message(sql_tool_prompts.QUERY_REPAIR_SYSTEM_PROMPT, role="system")
        completion.with_message(
            sql_tool_prompts.QUERY_REPAIR_USER_PROMPT.format(
                previous_user_prompt=initial_user_prompt, formatted_errors=previous_sql_errors
            ),
            role="system",
        )
        return completion

    def get_initial_prompt(self, decision_result: Dict[str, Any]) -> str:
        tables_and_columns = decision_result["tables_and_columns"]
        chosen_tables_and_columns = self.sql_manager.format_subset_descriptions(tables_and_columns)
        return str(sql_tool_prompts.QUERY_BUILDING_USER_PROMPT_FMT.format(
                todays_datetime=datetime.now().strftime(PROMPT_DATE_FORMAT),
                chosen_tables_and_columns=chosen_tables_and_columns,
                decision_to_use_justification=decision_result["justification"],
            ))

    def generate_query(
        self, question: str, decision_result: Dict[str, Any], previous_sql_errors: str = ""
    ) -> Tuple[Optional[Dict[str, Any]], str]:
        completion: DSSLLMCompletionQuery
        text = ""
        subspan_identifier = "Generating SQL query " if not previous_sql_errors else "Retrying SQL query generation"
        with self.trace.subspan(subspan_identifier) as subspan:
            initial_system_prompt = self.get_initial_prompt(decision_result)
            if not previous_sql_errors:
                completion = self.get_query_completion(initial_system_prompt)
            else:
                completion = self.get_query_fix_completion(initial_system_prompt, previous_sql_errors)
            if "additionalInformation" in self.config: # TODO: the name additionalInformation is too vague
                completion.with_message(self.config["additionalInformation"], "system")
            completion.with_message(question, role="user")
            try:
                resp: DSSLLMCompletionResponse = completion.execute()
                subspan.append_trace(resp.trace)
                if not resp.text and resp.errorMessage:
                    logging.exception(resp.errorMessage)
                    previous_sql_errors = self.format_previous_sql_errors(
                        previous_sql_errors, {}, "", resp.errorMessage
                    )
                    return None, previous_sql_errors
                text = str(resp.text)
                logging.info(f"Query building result: {text}")
                query_building_result: Dict[str, Any] = extract_json(text)
                return query_building_result, previous_sql_errors
            except Exception as e:
                msg = f"Error while trying to generate SQL query: {e}. Response: {text}"
                logging.exception(msg)
                previous_sql_errors = self.format_previous_sql_errors(
                    previous_sql_errors, {}, "", msg
                )
                self.source["items"].append(
                    {"type": "ERROR", "textSnippet": msg})
                return None, previous_sql_errors


    def run_sql_query(
        self, query_build_result: Dict[str, Any], previous_sql_errors: str
    ) -> Tuple[str, Optional[List[Dict[str, Any]]], str]:
        # TODO: max_records_per_trace is not used yet but can implemented if needed
        # max_records_per_trace = int(self.config.get("max_records_per_trace", -1))
        max_records_per_trace = -1
        with self.trace.subspan("Executing SQL query") as subspan:
            select_query = to_select_query(query_build_result, hard_sql_limit=self.hard_sql_limit)
            logging.debug(f"Initial AST: {select_query}")
            replace_tables_in_select_query(select_query, self.config["datasets"])
            logging.debug(f"AST with tables replaced: {select_query}")
            sql_query: str = ""
            try:
                # Execution can fail in 2 ways:
                # 1. The AST cannot be parse and cause an error
                sql_query = str(toSQL(select_query, dialect=self.sql_manager.conn.dialect))
                logging.debug(f"SQL query: {sql_query}")
                query_source_item = {"type": "GENERATED_SQL_QUERY", "performedQuery": sql_query}
                # 2. The SQL query can be executed and returns an error
                df = self.sql_manager.conn.executor.query_to_df(query=sql_query)
                df.fillna("", inplace=True)
                records: List[Dict[str, Any]] = df.to_dict("records")
                logging.info(f"Data retrieved: {records}")

                records_source_item = {
                    "type": "RECORDS",
                    "records": {
                        "columns": df.columns.to_list(),
                        "data": df[:max_records_per_trace].values.tolist() if max_records_per_trace != -1 else df.values.tolist()
                    },
                }
                subspan.attributes["sqlQuery"] = sql_query
                self.source["items"].extend([query_source_item, records_source_item])
                return sql_query, records, previous_sql_errors
            except Exception as e:
                logging.exception(f"Exception when attempting to execute SQL query: {e}")
                previous_sql_errors = self.format_previous_sql_errors(previous_sql_errors, query_build_result, sql_query, str(e))
                self.source["items"].append(
                    {"type": "ERROR", "textSnippet": f"Error executing SQL query: {e}"}
                )
                return sql_query, None, previous_sql_errors

    def synthesize_final_answer(
        self, question: str, decision_result: Dict[str, Any], sql_query: str, records: List[Dict[str, Any]]
    ) -> str:
        with self.trace.subspan("Synthesizing final answer") as subspan:
            final_completion = self.llm.new_completion()
            final_completion.with_message(sql_tool_prompts.FINAL_ANSWER_SYSTEM_PROMPT, "system")
            if "additionalInformation" in self.config: # TODO: this name is too vague
                final_completion.with_message(self.config["additionalInformation"], "system")
            user_prompt = sql_tool_prompts.FINAL_ANSWER_USER_PROMPT_FMT.format(
                user_question=question,
                chosen_tables_and_columns=decision_result["tables_and_columns"],
                sql_query=sql_query,
                records=records,
            )
            final_completion.with_message(user_prompt, "user")
            try:
                resp = final_completion.execute()
                if not resp.text and resp.errorMessage:
                    logging.exception(resp.errorMessage)
                    raise Exception(f"Error while trying to synthesize final answer: {resp.errorMessage}")
                subspan.append_trace(resp.trace)
                text = str(resp.text)
                logging.info(f"Final response: {text}")
                return text
            except Exception as e:
                msg = f"Error while trying to synthesize final answer: {e}"
                logging.exception(msg)
                self.source["items"].append({"type": "ERROR", "textSnippet": msg})
                raise Exception(msg)

    def invoke(self, input: Dict[str, Any], trace) -> Dict[str, Any]:
        if not (question := input.get("input", {}).get("question")):
            raise ValueError("Input must contain a 'question' field and the value must not be empty.")
        self.source: Dict[str, Any] = {"toolCallDescription": f"Tried to answer question: {question} using SQL datasets", "items": []}
        self.trace = trace

        decision_result = self.is_query_required(question)
        if not decision_result:
            return {"output": {"status": "cant_respond"}, "sources": [self.source]}

        previous_sql_errors = ""
        for attempt in range(1, self.max_query_attempts + 1):
            logging.info(f"Attempt {attempt} to generate SQL query")
            query_build_result, previous_sql_errors = self.generate_query(question, decision_result, previous_sql_errors)
            if query_build_result is None:
                logging.error(f"Failed to generate a valid SQL query on attempt {attempt}. Previous errors: {previous_sql_errors}")
                continue
            sql_query, records, previous_sql_errors = self.run_sql_query(query_build_result, previous_sql_errors)
            if records is not None:
                break
            if attempt >= self.max_query_attempts:
                raise Exception(f"Failed to generate a valid SQL query after {self.max_query_attempts} attempts.")
        final_response = self.synthesize_final_answer(
            question, decision_result, sql_query, records if records is not None else []
        )
        return {"output": final_response, "sources": [self.source]}

