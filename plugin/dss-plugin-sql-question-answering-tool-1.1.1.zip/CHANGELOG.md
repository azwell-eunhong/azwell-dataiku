# Changelog

## [Version 1.1.1] - Fix release - 2025-07-02
- Fix SQL dataset fail check due to missing location info

## [Version 1.1.0] - Feature release - 2025-06-05
- Categorical column descriptions now automatically include all unique values for low cardinality columns
- Make command to make version releases with release notes
- Fix bug with get_descriptor being None

## [Version 1.0.0] - Feature release - 2025-06-02
- Add make commands to increase versions
- Reduced complexity of retry mechanism
- Add more detailed column and dataset descriptions
- Add pull request template

## [Version 0.0.5] - Fix release - 2025-05-30
- remove max on upper limit of SQl queries
- error messages no longer class attribute

## [Version 0.0.4] - Fix release - 2025-05-23
- add testing workflow
- add unit tests
- add linting checks
- add add ruff check

## [Version 0.0.3] - Fix release - 2025-05-21

- json parsing of response with regex
- sql hard limit: adds a LIMIT statement to each query run to avoid excessive quires
- retry mechanism for SQL query repair on error

## [Version 0.0.2] - Fix release - 2025-04-24

- Update agent tool description

## [Version 0.0.1] - Initial release 2025-02-09

- The agent tool "SQL Query" is able to answer questions related to the data contained in one or several SQL datasets. 
