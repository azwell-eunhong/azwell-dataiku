import logging
from typing import Dict, List, Optional

import dataiku
import pandas as pd
from dataiku import SQLExecutor2
from dataiku.core.dataset import Dataset
from dataiku.sql import Column, Constant, Expression, SelectQuery, Table, toSQL
from dataikuapi.dss.dataset import DSSDataset, SQLDatasetSettings
from dataikuapi.dssclient import DSSClient
from models import DsDescribe  # type: ignore[import]


class DatasetParameters:
    def __init__(self, dataset_name: str, api_client: DSSClient):
        self.name: str = dataset_name
        self.dss_dataset: DSSDataset = api_client.get_default_project().get_dataset(dataset_name)
        self.settings = self.dss_dataset.get_settings()
        if not isinstance(self.settings, SQLDatasetSettings):
            raise ValueError(f"Dataset {dataset_name} is not a SQL dataset.")
        
        self.core_dataset: Dataset = self.dss_dataset.get_as_core_dataset()
        self.schema_columns: List[Dict[str, str]] = self.settings.schema_columns
        self.to_unique: List[str] = ["string"]  # Only working for string columns at the moment


class Connection:
    def __init__(self, connection: str) -> None:
        self.name: str = connection
        self.executor: SQLExecutor2 = SQLExecutor2(connection=connection)
        conn_details = dataiku.get_connection(connection).conn_details
        if not (dialect := conn_details.get("type")):
            raise ValueError("Unable to determine dialect from connection.")
        self.dialect: str = dialect


class SQlManager:
    def __init__(self, api_client: DSSClient, datasets: List[str], connection: str):
        self.cardinality_cutoff = 30
        self.api_client = api_client
        self.datasets = datasets
        self._conn = Connection(connection)
        self.__datasets_descriptions = self.collect_all_descriptions()

    @property
    def conn(self) -> Connection:
        return self._conn

    @property
    def _datasets_descriptions(self):
        return self.__datasets_descriptions

    def collect_all_descriptions(self) -> Dict[str, DsDescribe]:
        descriptions: Dict[str, DsDescribe] = {}
        for dataset_name in self.datasets:
            descriptions[dataset_name] = self.get_dataset_description(dataset_name)
        return descriptions

    def format_all_descriptions(self) -> str:
        full_description = ""
        for describe in self._datasets_descriptions.values():
            full_description += (
                describe["main_description"]
                + "\n".join(describe["columns"].values())
                + "\n"
                + "__ End of Description __\n"
            )
        return full_description

    def format_subset_descriptions(self, tables_and_columns) -> str:  # TODO tc type later
        subset_descriptions = ""
        for tc in tables_and_columns:
            table_name, selected_columns = tc.get("table_name", ""), tc.get("columns", [])
            ds_info = self._datasets_descriptions[table_name]
            columns_description = ds_info["columns"]

            subset_descriptions += ds_info["main_description"]
            for col in selected_columns:
                if not (col_description := columns_description.get(col, "")):
                    raise ValueError(f"Column description not found for: '{col}' in table '{table_name}'.")
                subset_descriptions += col_description
                subset_descriptions += "__ End of Description __\n"
        return subset_descriptions

    def columns_in_uppercase(self, core_ds: Dataset) -> bool:
        try:
            q = SelectQuery().select_from(core_ds).select(Column("*")).limit(1)
            query = toSQL(q, dataset=core_ds)
            df = self.conn.executor.query_to_df(query)
            return bool(all([c.isupper() for c in df.columns]))
        except Exception as e:
            logging.exception(f"Error when trying to determine case of table columns: {e}")
            return False

    def get_col_data_types(self, schema_columns: List[Dict[str, str]]) -> Dict[str, List[str]]:
        col_d_types: Dict[str, List[str]] = {}
        for item in schema_columns:
            d_type = str(item.get("type"))
            if d_type not in col_d_types:
                col_d_types[d_type] = []
            col_d_types[d_type].append(str(item.get("name")))
        return col_d_types

    def get_table_ast(self, core_dataset: Dataset, alias=None) -> Table:
        if not (info := core_dataset.get_location_info().get("info")):
            raise ValueError("No 'info' for dataiku dataset")
        if not (table := info.get("table")):
            raise ValueError("No table name found in dataiku dataset location info")
        return Table(name=table, alias=alias, catalog=info.get("catalog"), schema=info.get("schema"))

    def get_distinct_df(self, ds: DatasetParameters) -> Optional[pd.DataFrame]:
        col_data_types = self.get_col_data_types(ds.schema_columns)
        # TODO: only working for 1 data type at the moment
        data_type = ds.to_unique[0]
        cat_cols = col_data_types.get(data_type, [])
        if not cat_cols:
            return None
        query = ""
        for idx, col in enumerate(cat_cols):
            if idx != 0:
                query += " UNION ALL "
            select_query = SelectQuery()
            select_query.select(Expression({"type": "COLUMN", "name": col}).distinct(), alias="value")
            select_query.select(Constant(col), alias="Column_Name")
            select_query.select_from(self.get_table_ast(ds.core_dataset))
            q = toSQL(select_query, dialect=self.conn.dialect)
            query += f" {q} "
        df: pd.DataFrame = self.conn.executor.query_to_df(query)
        return df

    def get_low_cardinality_cats(
        self,
        ds: DatasetParameters,
    ) -> Dict[str, str]:
        df: Optional[pd.DataFrame] = self.get_distinct_df(ds)
        if df is None or df.empty:
            return {}
        if "value" not in df.columns:
            raise ValueError("DataFrame must contain a 'value' column.")

        agg_df = df.groupby("Column_Name").agg(
            count=("value", "count"), values_concat=("value", lambda x: ", ".join(x.astype(str)))
        )
        col_cats: Dict[str, str] = agg_df[
            (agg_df["count"] > 0) & (agg_df["count"] < self.cardinality_cutoff)
        ].to_dict()["values_concat"]
        return col_cats

    def get_dataset_description(self, dataset_name: str) -> DsDescribe:
        ds = DatasetParameters(dataset_name, self.api_client)
        description = ds.settings.description or ds.settings.short_description
        if not description:
            logging.warning(
                "Dataset must have description. Add one under details > short description / details > Long description"
            )
        cols_uppercase = self.columns_in_uppercase(ds.core_dataset)
        low_cardinality_cats = self.get_low_cardinality_cats(ds)
        describe = DsDescribe(
            main_description=(
                f"Name: {dataset_name}\n"
                f"SQL Database type: {self.conn.dialect}\n"
                f"Datasource description: {description}\n\n"
                "## Columns description\n"
            ),
            columns={},
        )

        missing_description = False
        for col in ds.schema_columns:
            col_name = col.get("name", "")
            description = col.get("comment", "")
            if not description:
                missing_description = True
            missing_description
            cat_values: Optional[str] = low_cardinality_cats.get(col_name)
            # col_name = col_name.upper() if cols_uppercase else col_name
            describe["columns"][col_name] = f"""
            - Name: '{col_name}' | Type: '{col["type"]}' | Description: '{description}' {f"| Unique Values: {cat_values}" if cat_values else ""}
            """
        if missing_description:
            logging.warning(
                "It is recommended that all columns have a description. Click dataset > settings > schema then click on a column and edit the DESCRIPTION on the right hand side"
            )
        return describe
