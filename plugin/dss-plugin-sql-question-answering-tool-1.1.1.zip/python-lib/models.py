from typing import Dict, TypedDict


class DsDescribe(TypedDict, total=False):
    main_description: str
    columns: Dict[str, str]
