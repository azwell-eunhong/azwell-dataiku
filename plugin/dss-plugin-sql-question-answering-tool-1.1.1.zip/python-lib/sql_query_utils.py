import logging
from typing import Any, Dict, List

import dataiku
from dataiku.sql import SelectQuery


def replace_tables_in_select_query(ast: SelectQuery, datasets: List[str]) -> None:
    valid_aliases = set()

    def _collect_valid_aliases(node: Dict) -> None:
        assert(node["type"] == "TABLE")

        if "alias" in node:
            valid_aliases.add(node["alias"])

    def _collect_aliases_rec_list(node: List) -> None:
        for item in node:
            if isinstance(item, dict):
                _collect_aliases_rec_dict(item)
            elif isinstance(item, list):
                _collect_aliases_rec_list(item)

    def _collect_aliases_rec_dict(node: Dict) -> None:
        for key in node.keys():
            if (key == "table" or key == "tableLike" or key == "from") and isinstance(node[key], dict) and "type" in node[key] and node[key]["type"] == "TABLE":  # noqa: PLR0916
                _collect_valid_aliases(node[key])
            else:
                if isinstance(node[key], dict):
                    _collect_aliases_rec_dict(node[key])
                elif isinstance(node[key], list):
                    _collect_aliases_rec_list(node[key])

    def _expand_table_node(node: Dict) -> None:
        assert(node["type"] == "TABLE")
        table_name = node["name"]

        if table_name not in datasets:
            if table_name not in valid_aliases:
                raise Exception(f"Illegal table access: {table_name}")
            else:
                # Leave the alias alone
                return

        location_info = dataiku.Dataset(table_name).get_location_info()
        if location_info.get("locationInfoType") != "SQL":
            raise ValueError("Cannot only execute query on an SQL dataset")

        catalog_name = location_info.get("info").get("catalog")
        schema_name = location_info.get("info").get("schema")
        table_name = location_info.get("info").get("table")

        if catalog_name is not None:
            node["catalog"] = catalog_name
        if schema_name is not None:
            node["schema"] = schema_name
        if table_name is not None:
            node["name"] = table_name
        
    def _replace_tables_rec_list(node: List) -> None:
        for item in node:
            if isinstance(item, dict):
                _replace_tables_rec_dict(item)
            elif isinstance(item, list):
                _replace_tables_rec_list(item)

    def _replace_tables_rec_dict(node: Dict) -> None:
        for key in node.keys():
            if (key == "table" or key == "tableLike" or key == "from") and isinstance(node[key], dict) and "type" in node[key] and node[key]["type"] == "TABLE":  # noqa: PLR0916
                _expand_table_node(node[key])
            else:
                if isinstance(node[key], dict):
                    _replace_tables_rec_dict(node[key])
                elif isinstance(node[key], list):
                    _replace_tables_rec_list(node[key])
    _collect_aliases_rec_dict(ast._query)
    logging.info(f"Collected valid aliases: {valid_aliases}")
    _replace_tables_rec_dict(ast._query)


def to_select_query(db_query: Dict[str, Any], hard_sql_limit: int = 200) -> SelectQuery:
    select_query = SelectQuery()
    select_list = db_query["selectList"]

    if isinstance(select_list, List):
        select_query._query["selectList"] = select_list
    else:
        select_query._query["selectList"] = [{"expr": {"type": "COLUMN", "name": "*"}}]

    from_ = db_query["from"]
    if isinstance(from_, dict):
        select_query._query["from"] = from_
    else:
        raise Exception("A query must have 'from' statement")

    for key in ["with", "join", "where", "groupBy", "having", "orderBy"]:
        val = db_query[key]
        if isinstance(val, List):
            select_query._query[key] = val

    records = []
    limit = db_query["limit"]
    if isinstance(limit, int):
        if limit < hard_sql_limit:
            select_query._query["limit"] = limit
        else:
            records.append(
                [
                    {
                        "WARNING!": f"The query exceeded the query limit of {hard_sql_limit}. Some information may be missing. Warn the user!"
                    }
                ]
            )
            select_query._query["limit"] = hard_sql_limit
    else:
        select_query._query["limit"] = hard_sql_limit
    return select_query


